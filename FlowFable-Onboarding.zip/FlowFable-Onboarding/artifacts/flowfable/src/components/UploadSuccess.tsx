"use client";

type UploadSuccessProps = {
  onViewInsight: () => void;
  onUploadAnother: () => void;
};

export default function UploadSuccess({
  onViewInsight,
  onUploadAnother
}: UploadSuccessProps) {
  return (
    <div className="max-w-xl mx-auto p-6 bg-white text-black">
      <h1 className="text-3xl ff-heading-serif-rainy mb-6">
        Your document is ready
      </h1>

      <p className="leading-relaxed mb-8">
        FlowFable has processed your financial document. You can now view your
        first learning insight and continue building your financial knowledge.
      </p>

      <button
        type="button"
        onClick={onViewInsight}
        className="
          w-full py-3 rounded-lg
          bg-[var(--ff-seafoam)] text-black
          font-medium
          mb-4
        "
      >
        View Insight
      </button>

      <button
        type="button"
        onClick={onUploadAnother}
        className="
          w-full py-3 rounded-lg
          border border-black
          text-black
          font-medium
        "
      >
        Upload another document
      </button>
    </div>
  );
}