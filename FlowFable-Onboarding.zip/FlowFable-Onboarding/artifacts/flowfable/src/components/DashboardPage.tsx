"use client";

import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import {
  explainInsight,
  generateInsights,
  generateWeightedInsights
} from "@/lib/insightEngine";
import type { MinimalInsight } from "@/lib/insightEngine";
import InsightExplanationTooltip from "@/components/InsightExplanationTooltip";
import InsightExplanationWrapper from "@/components/InsightExplanationWrapper";
import ProjectionScenarioOverlay from "@/components/ProjectionScenarioOverlay";
import GoalDependencyOverlay from "@/components/GoalDependencyOverlay";
import type { FinancialSignal } from "@/lib/extraction";
import {
  getInsightIndex,
  getInsights,
  getTotalInsights,
  getProcessedData,
  getProcessedGoals,
  nextInsight,
  previousInsight,
  resetInsights,
  setInsights
} from "@/lib/dataStore";
import type { FlowResult } from "@/types/FlowResult";

type DashboardPageProps = {
  flow?: FlowResult;
  onUploadComplete?: (filePath: string) => void;
};

export default function DashboardPage({ flow }: DashboardPageProps = {}) {
  const [, setLocation] = useLocation();
  const [insight, setInsight] = useState<MinimalInsight | null>(null);
  const [index, setIndex] = useState(0);
  const [total, setTotal] = useState(0);
  const [showSummary, setShowSummary] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [loading, setLoading] = useState(true);
  const loadingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    loadingTimer.current = setTimeout(() => {
      const storedInsights = getInsights();
      if (storedInsights.length > 0) {
        if (getInsightIndex() >= getTotalInsights()) {
          setShowSummary(true);
          setLoading(false);
          return;
        }

        updateCurrentInsight();
        setLoading(false);
        return;
      }

      const data = getProcessedData();
      if (!data) {
        setLocation("/");
        return;
      }

      const generatedInsights = generateInsights(data);
      setInsights(generatedInsights);
      updateCurrentInsight();
      setLoading(false);
    }, 300);

    return () => {
      if (loadingTimer.current) {
        clearTimeout(loadingTimer.current);
      }
    };
  }, []);

  function updateCurrentInsight() {
    const list = getInsights();
    const currentIndex = getInsightIndex();
    setInsight(list[currentIndex] ?? null);
    setIndex(currentIndex + 1);
    setTotal(getTotalInsights());
  }

  function handleContinueLearning() {
    if (total === 0 || loading) return;

    setLoading(true);
    loadingTimer.current = setTimeout(() => {
      const currentIndex = getInsightIndex();
      const totalCount = getTotalInsights();

      if (totalCount === 0 || currentIndex >= totalCount - 1) {
        setShowSummary(true);
        setLoading(false);
        return;
      }

      nextInsight();
      updateCurrentInsight();
      setLoading(false);
    }, 300);
  }

  function handleBack() {
    if (loading || getInsightIndex() === 0) return;

    setLoading(true);
    loadingTimer.current = setTimeout(() => {
      previousInsight();
      updateCurrentInsight();
      setLoading(false);
    }, 300);
  }

  function handleRestart() {
    if (loading) return;

    setLoading(true);
    loadingTimer.current = setTimeout(() => {
      resetInsights();
      setShowSummary(false);
      updateCurrentInsight();
      setLoading(false);
    }, 300);
  }

  if (loading) {
    return (
      <div className="max-w-xl mx-auto p-6 bg-white text-black">
        <p className="leading-relaxed">Loading your insight…</p>
      </div>
    );
  }

  if (showSummary && !isComplete) {
    const insights = getInsights();
    const processedData = getProcessedData();
    const signals = Array.isArray(processedData) ? processedData : [];
    const groupedSignals = groupSignalsByCategory(signals);
    const weightedInsights =
      signals.length > 0
        ? generateWeightedInsights(signals)
        : insights.map((insight) => ({ insight, weight: 20 }));

    return (
      <div className="max-w-xl mx-auto p-6 bg-white text-black">
        <h1 className="text-3xl ff-heading-serif-rainy mb-6">
          Insight Summary
        </h1>

        <p className="leading-relaxed mb-6">
          Here’s a quick summary of everything you learned.
        </p>

        <InsightExplanationWrapper
          insights={weightedInsights.map((weighted) => weighted.insight)}
          signalsByCategory={groupedSignals}
        />

        <div className="flex flex-col gap-6 mb-8">
          {insights.map((item, insightNumber) => (
            <div
              key={insightNumber}
              className="border border-black p-4 rounded-lg"
            >
              <p className="text-sm mb-2">
                Insight {insightNumber + 1}
              </p>

              <p className="font-medium mb-2">What’s happening</p>
              <p className="leading-relaxed mb-4">{item.what}</p>

              <p className="font-medium mb-2">Why it matters</p>
              <p className="leading-relaxed mb-4">{item.why}</p>

              <p className="font-medium mb-2">What to do next</p>
              <p className="leading-relaxed">{item.next}</p>
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={() => setIsComplete(true)}
          className="
            w-full py-3 rounded-lg
            bg-[var(--ff-seafoam)] text-black
            font-medium
          "
        >
          Finish Learning
        </button>
      </div>
    );
  }

  if (isComplete) {
    return (
      <div className="max-w-xl mx-auto p-6 bg-white text-black">
        <h1 className="text-3xl ff-heading-serif-rainy mb-6">
          Learning Complete
        </h1>

        <p className="leading-relaxed mb-6">
          You’ve completed all your financial insights. Each step helped you
          understand your financial situation with clarity and confidence.
        </p>

        <button
          type="button"
          onClick={() => {
            resetInsights();
            setLocation("/upload");
          }}
          className="
            w-full py-3 rounded-lg
            bg-[var(--ff-seafoam)] text-black
            font-medium
          "
        >
          Upload another document
        </button>
      </div>
    );
  }

  if (!insight) return null;

  const processedData = getProcessedData();
  const signals = Array.isArray(processedData) ? processedData : [];
  const userGoals = flow?.goals ?? getProcessedGoals();
  const explanationReasons = explainInsight(insight, signals);

  return (
    <div className="max-w-xl mx-auto p-6 bg-white text-black">
      {total > 0 && (
        <p className="text-sm text-black mb-4" aria-live="polite">
          Insight {index} of {total}
        </p>
      )}

      <h1 className="text-3xl ff-heading-serif-rainy mb-8">
        Your Financial Insight
      </h1>

      <section className="mb-8">
        <h2 className="text-xl ff-heading-serif-rainy mb-2">
          What’s happening
        </h2>
        <p className="leading-relaxed">
          {insight.what}
        </p>
      </section>

      <section className="relative mb-8">
        <div className="flex items-start justify-between gap-4">
          <h2 className="text-xl ff-heading-serif-rainy mb-2">
            Why it matters
          </h2>
          <div className="relative shrink-0">
            <button
              type="button"
              onClick={() => setShowExplanation((visible) => !visible)}
              aria-expanded={showExplanation}
              aria-label="Explain this insight"
              className="border border-black rounded px-2 py-1 text-xs font-medium"
            >
              Why?
            </button>
            {showExplanation && (
              <InsightExplanationTooltip reasons={explanationReasons} />
            )}
          </div>
        </div>
        <p className="leading-relaxed">
          {insight.why}
        </p>
      </section>

      <section className="mb-8">
        <h2 className="text-xl ff-heading-serif-rainy mb-2">
          What to do next
        </h2>
        <p className="leading-relaxed mb-4">
          {insight.next}
        </p>

        <div className="flex flex-col gap-4">
          {index === 1 && (
            <button
              type="button"
              onClick={handleRestart}
              className="
                w-full py-3 rounded-lg
                border border-black
                text-black
                font-medium
              "
            >
              Restart Learning
            </button>
          )}

          {index > 1 && (
            <button
              type="button"
              onClick={handleBack}
              className="
                w-1/2 py-3 rounded-lg
                border border-black
                text-black
                font-medium
              "
            >
              Back
            </button>
          )}

          <button
            type="button"
            onClick={handleContinueLearning}
            disabled={total === 0}
            className="
              w-full py-3 rounded-lg
              bg-[var(--ff-seafoam)] text-black
              font-medium
              disabled:cursor-not-allowed disabled:opacity-50
            "
          >
            Continue Learning
          </button>
        </div>
      </section>

      {signals.length > 0 && (
        <ProjectionScenarioOverlay signals={signals} />
      )}

      {userGoals.length > 0 && signals.length > 0 && (
        <GoalDependencyOverlay goals={userGoals} signals={signals} />
      )}
    </div>
  );
}

function groupSignalsByCategory(
  signals: FinancialSignal[]
): Record<string, FinancialSignal[]> {
  return {
    income: signals.filter((signal) => signal.category === "income"),
    expense: signals.filter((signal) => signal.category === "expense"),
    savings: signals.filter((signal) => signal.category === "savings"),
    debt: signals.filter((signal) => signal.category === "debt"),
    recurring_bill: signals.filter(
      (signal) => signal.category === "recurring_bill"
    )
  };
}