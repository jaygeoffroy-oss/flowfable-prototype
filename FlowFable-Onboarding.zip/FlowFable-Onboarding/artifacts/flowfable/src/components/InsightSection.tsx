"use client";

import React from "react";
import type { InsightsResult } from "@/types/FlowResult";

export default function InsightSection({ insights }: { insights: InsightsResult }) {
  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-xl font-semibold ff-heading-serif-rainy">
        Insights
      </h2>

      {insights.items.map((item) => (
        <div
          key={item.id}
          className="ff-card border-[var(--ff-rain-blue)]"
        >
          <h3 className="text-lg font-[var(--ff-font-serif)] text-[var(--ff-sand)]">
            {item.title}
          </h3>
          <p className="mt-1 text-[var(--ff-fog-gray)]">{item.detail}</p>
        </div>
      ))}
    </div>
  );
}
