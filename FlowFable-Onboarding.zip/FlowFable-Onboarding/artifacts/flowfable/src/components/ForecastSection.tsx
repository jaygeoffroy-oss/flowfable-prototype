"use client";

import type { ForecastResult } from "@/types/FlowResult";

export default function ForecastSection({
  forecast
}: {
  forecast?: ForecastResult;
}) {
  if (!forecast) return null;

  return (
    <div className="flex flex-col gap-6">
      <h2 className="text-xl font-semibold ff-heading-serif-rainy">
        Forecast
      </h2>

      <div>
        <h3 className="mb-2 text-lg font-semibold ff-heading-serif-rainy">
          Conservative
        </h3>
        <div className="flex flex-col gap-4">
          {forecast.conservative.map((item) => (
            <div
              key={item.label}
              className="ff-card border-[var(--ff-coral)]"
            >
              <h4 className="text-md font-medium ff-heading-serif-rainy">
                {item.label}
              </h4>
              <p className="mt-2 text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
                Projected income:{" "}
                <span className="text-[var(--ff-coral)]">
                  {Math.round(item.projectedIncome)}
                </span>
              </p>
              <p className="text-[var(--ff-fog-gray)]">
                Bills:{" "}
                <span className="text-[var(--ff-coral)]">
                  {Math.round(item.projectedBills)}
                </span>
              </p>
              <p className="text-[var(--ff-fog-gray)]">
                Budget:{" "}
                <span className="text-[var(--ff-coral)]">
                  {Math.round(item.projectedBudget)}
                </span>
              </p>
              <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
                Pressure:{" "}
                <span className="text-[var(--ff-coral)]">
                  {item.projectedPressure.toFixed(2)}
                </span>
              </p>
              <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-seafoam)]">
                Stability:{" "}
                <span>{item.projectedStability.toFixed(2)}</span>
              </p>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h3 className="mb-2 text-lg font-semibold ff-heading-serif-rainy">
          Optimistic
        </h3>
        <div className="flex flex-col gap-4">
          {forecast.optimistic.map((item) => (
            <div
              key={item.label}
              className="ff-card border-[var(--ff-coral)]"
            >
              <h4 className="text-md font-medium ff-heading-serif-rainy">
                {item.label}
              </h4>
              <p className="mt-2 text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
                Projected income:{" "}
                <span className="text-[var(--ff-coral)]">
                  {Math.round(item.projectedIncome)}
                </span>
              </p>
              <p className="text-[var(--ff-fog-gray)]">
                Bills:{" "}
                <span className="text-[var(--ff-coral)]">
                  {Math.round(item.projectedBills)}
                </span>
              </p>
              <p className="text-[var(--ff-fog-gray)]">
                Budget:{" "}
                <span className="text-[var(--ff-coral)]">
                  {Math.round(item.projectedBudget)}
                </span>
              </p>
              <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
                Pressure:{" "}
                <span className="text-[var(--ff-coral)]">
                  {item.projectedPressure.toFixed(2)}
                </span>
              </p>
              <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-seafoam)]">
                Stability:{" "}
                <span>{item.projectedStability.toFixed(2)}</span>
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}