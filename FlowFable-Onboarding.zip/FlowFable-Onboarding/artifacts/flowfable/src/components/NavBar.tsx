"use client";

import { go } from "@/lib/redirect";

export default function NavBar() {
  return (
    <nav className="w-full border-b border-black mb-8">
      <div className="max-w-xl mx-auto p-4 flex flex-wrap gap-4 text-black">
        <button
          type="button"
          onClick={() => go("/")}
          className="font-medium ff-heading-serif-rainy"
        >
          FlowFable
        </button>

        <button type="button" onClick={() => go("/")}>
          Home
        </button>
        <button type="button" onClick={() => go("/upload")}>
          Upload
        </button>
        <button type="button" onClick={() => go("/dashboard")}>
          Dashboard
        </button>
        <button type="button" onClick={() => go("/settings")}>
          Settings
        </button>
        <button type="button" onClick={() => go("/about")}>
          About
        </button>
        <button type="button" onClick={() => go("/help")}>
          Help
        </button>
        <button type="button" onClick={() => go("/contact")}>
          Contact
        </button>
      </div>
    </nav>
  );
}