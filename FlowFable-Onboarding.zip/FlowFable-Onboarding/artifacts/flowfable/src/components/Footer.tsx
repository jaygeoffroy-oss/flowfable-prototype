"use client";

export default function Footer() {
  return (
    <footer className="w-full border-t border-black mt-12">
      <div className="max-w-xl mx-auto p-4 text-black text-sm leading-relaxed">
        <p className="ff-heading-serif-rainy mb-1">FlowFable</p>
        <p>Clarity through structured learning.</p>
      </div>
    </footer>
  );
}