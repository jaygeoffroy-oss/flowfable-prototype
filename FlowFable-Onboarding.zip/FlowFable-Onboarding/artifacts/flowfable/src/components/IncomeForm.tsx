"use client";

import { useState } from "react";

interface IncomeFormProps {
  onSubmit: (payload: { amount: number; cadence: string }) => void;
}

export default function IncomeForm({ onSubmit }: IncomeFormProps) {
  const [amount, setAmount] = useState("");
  const [cadence, setCadence] = useState("monthly");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const value = Number(amount);
    if (isNaN(value) || value <= 0) return;

    onSubmit({ amount: value, cadence });
    setAmount("");
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="p-4 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4"
    >
      <h3 className="text-lg font-semibold text-[#FFD400]">Add Income</h3>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white">Amount</label>
        <input
          type="number"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter amount"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white">Cadence</label>
        <select
          value={cadence}
          onChange={e => setCadence(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
        >
          <option value="weekly">Weekly</option>
          <option value="biweekly">Biweekly</option>
          <option value="monthly">Monthly</option>
          <option value="annually">Annually</option>
        </select>
      </div>

      <button
        type="submit"
        className="p-2 bg-[#FF7A00] text-black font-semibold rounded hover:bg-[#FF8F33] transition-colors"
      >
        Add Income
      </button>
    </form>
  );
}