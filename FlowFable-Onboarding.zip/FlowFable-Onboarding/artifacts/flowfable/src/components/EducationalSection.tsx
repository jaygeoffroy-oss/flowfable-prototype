"use client";

import React from "react";
import type { EducationalResult } from "@/types/FlowResult";

export default function EducationalSection({
  education
}: {
  education: EducationalResult;
}) {
  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-xl font-semibold ff-heading-serif-rainy">
        Education
      </h2>

      {education.items.map((item) => (
        <div
          key={item.id}
          className="p-4 rounded-xl bg-black/40 border border-[#FF6A00]/40 shadow-md"
        >
          <h3 className="text-lg font-medium text-white">{item.title}</h3>
          <p className="text-gray-300 mt-1">{item.explanation}</p>
        </div>
      ))}
    </div>
  );
}
