"use client";

import React, { useState } from "react";
import type { Insight } from "@/lib/insightEngine";
import type { FinancialSignal } from "@/lib/extraction";
import { explainInsight } from "@/lib/insightExplanationEngine";
import InsightExplanationTooltip from "./InsightExplanationTooltip";

export default function InsightExplanationWrapper({
  insights,
  signalsByCategory
}: {
  insights: Insight[];
  signalsByCategory: Record<string, FinancialSignal[]>;
}) {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <div className="relative flex flex-col gap-4">
      {insights.map((insight, index) => {
        const relatedSignals = findSignals(insight, signalsByCategory);
        const reasons = explainInsight(insight, relatedSignals);

        return (
          <div
            key={index}
            className="relative"
            onMouseEnter={() => setHovered(index)}
            onMouseLeave={() => setHovered(null)}
          >
            <p className="text-sm text-black leading-relaxed">
              • {insight.what}
            </p>

            {hovered === index && (
              <InsightExplanationTooltip reasons={reasons} />
            )}
          </div>
        );
      })}
    </div>
  );
}

function findSignals(
  insight: Insight,
  grouped: Record<string, FinancialSignal[]>
): FinancialSignal[] {
  if (insight.what.includes("income")) return grouped.income ?? [];
  if (insight.what.includes("expenses")) {
    return [
      ...(grouped.expense ?? []),
      ...(grouped.recurring_bill ?? [])
    ];
  }
  if (insight.what.includes("savings")) return grouped.savings ?? [];
  if (insight.what.includes("debt")) return grouped.debt ?? [];
  if (insight.what.includes("recurring")) {
    return grouped.recurring_bill ?? [];
  }
  return [];
}