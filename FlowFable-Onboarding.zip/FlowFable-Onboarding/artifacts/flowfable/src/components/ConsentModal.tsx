"use client";

import { useState } from "react";

type ConsentModalProps = {
  onAccept: () => void;
};

export default function ConsentModal({ onAccept }: ConsentModalProps) {
  const [visible, setVisible] = useState(true);

  if (!visible) return null;

  function handleAccept() {
    onAccept();
    setVisible(false);
  }

  return (
    <div
      className="
        fixed inset-0 bg-black/40
        flex items-center justify-center
        p-4
        z-50
      "
      role="presentation"
    >
      <div
        className="
          max-w-xl w-full
          bg-white text-black
          p-6 rounded-lg
        "
        role="dialog"
        aria-modal="true"
        aria-labelledby="consent-modal-title"
      >
        <h2
          id="consent-modal-title"
          className="text-3xl ff-heading-serif-rainy mb-6"
        >
          Before you continue
        </h2>

        <p className="leading-relaxed mb-4">
          FlowFable processes your financial documents securely. FlowFable does
          not store your raw documents. Your information is used only to generate
          learning insights for you.
        </p>

        <p className="leading-relaxed mb-6">
          By continuing, you agree to the Terms and Conditions, Privacy Policy,
          and Cookie Policy.
        </p>

        <div className="mb-6 flex flex-col space-y-2">
          <a href="/terms" className="text-[var(--ff-seafoam)] underline">
            Terms and Conditions
          </a>
          <a href="/privacy" className="text-[var(--ff-seafoam)] underline">
            Privacy Policy
          </a>
          <a href="/cookies" className="text-[var(--ff-seafoam)] underline">
            Cookie Policy
          </a>
        </div>

        <button
          type="button"
          onClick={handleAccept}
          className="
            w-full py-3 rounded-lg
            bg-[var(--ff-seafoam)] text-black
            font-medium
          "
        >
          I Agree and Continue
        </button>
      </div>
    </div>
  );
}