"use client";

import React from "react";
import GuidanceFeedPanel from "@/components/visuals/GuidanceFeedPanel";
import { buildFeedEntries } from "@/lib/coaching/guidanceFeedEngine";
import type { GuidanceResult } from "@/types/FlowResult";

export default function GuidanceSection({
  guidance,
  profile = {}
}: {
  guidance: GuidanceResult;
  profile?: Record<string, unknown>;
}) {
  const feed = buildFeedEntries(
    profile,
    guidance.items.map((item) => ({
      text: `${item.title}: ${item.action}`,
      context: {
        category: "Guidance"
      }
    }))
  );

  return (
    <div className="flex flex-col gap-4">
      <h2 className="text-xl font-semibold ff-heading-serif-rainy">
        Guidance
      </h2>

      {guidance.items.map((item) => (
        <div
          key={item.id}
          className="ff-card border-[var(--ff-seafoam)]"
        >
          <h3 className="text-lg font-[var(--ff-font-serif)] text-[var(--ff-sand)]">
            {item.title}
          </h3>
          <p className="mt-1 text-[var(--ff-fog-gray)]">{item.action}</p>
        </div>
      ))}

      <GuidanceFeedPanel feed={feed} />
    </div>
  );
}
