"use client";

import React from "react";
import type { FinancialSignal } from "@/lib/extraction";
import {
  forecastGoalDependencies,
  type UserGoal
} from "@/lib/goalDependencyEngine";

export default function GoalDependencyOverlay({
  goals,
  signals
}: {
  goals: UserGoal[];
  signals: FinancialSignal[];
}) {
  const dependencies = forecastGoalDependencies(goals, signals);

  return (
    <div className="mt-8 p-4 border border-black rounded-lg bg-white">
      <h2 className="ff-heading-serif-rainy text-xl mb-4">
        Goal Dependency Forecaster
      </h2>

      <div className="flex flex-col gap-4">
        {dependencies.map((dependency) => (
          <div
            key={dependency.goal.id}
            className="border border-black p-3 rounded"
          >
            <p className="font-medium">{dependency.goal.label}</p>
            <p className="text-sm">
              Feasibility: {dependency.feasibility}/100
            </p>

            {dependency.blockers.length > 0 && (
              <div className="mt-2">
                <p className="text-sm font-semibold">Blockers:</p>
                {dependency.blockers.map((blocker, index) => (
                  <p key={index} className="text-xs text-red-700">
                    • {blocker}
                  </p>
                ))}
              </div>
            )}

            {dependency.accelerators.length > 0 && (
              <div className="mt-2">
                <p className="text-sm font-semibold">Accelerators:</p>
                {dependency.accelerators.map((accelerator, index) => (
                  <p key={index} className="text-xs text-green-700">
                    • {accelerator}
                  </p>
                ))}
              </div>
            )}

            {dependency.dependentGoals.length > 0 && (
              <div className="mt-2">
                <p className="text-sm font-semibold">Dependent on:</p>
                {dependency.dependentGoals.map((dependentGoal, index) => (
                  <p key={index} className="text-xs text-gray-700">
                    • {dependentGoal}
                  </p>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}