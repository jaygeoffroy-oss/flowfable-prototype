"use client";

import type { EducationalItem } from "@/types/EducationalTypes";

interface EducationalCardProps {
  education: EducationalItem;
}

export default function EducationalCard({ education }: EducationalCardProps) {
  return (
    <div className="p-4 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col gap-3">
      <h3 className="text-lg font-semibold text-gray-800">{education.title}</h3>
      <p className="text-sm text-gray-700">{education.explanation}</p>
    </div>
  );
}
