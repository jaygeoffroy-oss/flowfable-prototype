"use client";

import type { Insight } from "@/lib/insightTypes";

interface InsightCardProps {
  insight: Insight;
}

export default function InsightCard({ insight }: InsightCardProps) {
  const {
    severity,
    what,
    why,
    options,
    consequences,
    returnToGoal,
    timestamp
  } = insight;

  return (
    <div className="p-4 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col gap-3">
      {/* Header */}
      <div className="flex justify-between items-start">
        <h3 className="text-lg font-semibold text-gray-800">{what}</h3>
        {timestamp && (
          <span className="text-xs text-gray-500">
            {new Date(timestamp).toLocaleDateString()}
          </span>
        )}
      </div>

      {/* Severity */}
      <span
        className={
          severity === "warning"
            ? "text-sm font-medium text-red-600"
            : "text-sm font-medium text-blue-600"
        }
      >
        {severity.toUpperCase()}
      </span>

      {/* Why */}
      <p className="text-sm text-gray-700">{why}</p>

      {/* Options */}
      {options && options.length > 0 && (
        <div className="flex flex-col gap-1">
          <p className="text-sm font-medium text-gray-800">Options</p>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {options.map((opt, idx) => (
              <li key={idx}>{opt}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Consequences */}
      {consequences && consequences.length > 0 && (
        <div className="flex flex-col gap-1">
          <p className="text-sm font-medium text-gray-800">Consequences</p>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {consequences.map((c, idx) => (
              <li key={idx}>{c}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Return to goal */}
      {returnToGoal && (
        <p className="text-sm text-gray-700 italic">{returnToGoal}</p>
      )}
    </div>
  );
}
