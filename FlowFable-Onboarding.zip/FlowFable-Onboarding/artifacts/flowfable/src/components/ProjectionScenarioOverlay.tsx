"use client";

import React, { useState } from "react";
import type { FinancialSignal } from "@/lib/extraction";
import {
  runProjection,
  type ProjectionResult
} from "@/lib/projectionEngine";

export default function ProjectionScenarioOverlay({
  signals
}: {
  signals: FinancialSignal[];
}) {
  const [incomeDelta, setIncomeDelta] = useState(0);
  const [expenseDelta, setExpenseDelta] = useState(0);
  const [savingsDelta, setSavingsDelta] = useState(0);
  const [debtDelta, setDebtDelta] = useState(0);
  const [projection, setProjection] = useState<ProjectionResult | null>(null);

  function applyProjection() {
    const result = runProjection(signals, {
      incomeDelta,
      expenseDelta,
      savingsDelta,
      debtDelta
    });
    setProjection(result);
  }

  return (
    <div className="mt-8 p-4 border border-black rounded-lg bg-white">
      <h2 className="ff-heading-serif-rainy text-xl mb-4">
        Projection Scenario Overlay
      </h2>

      <div className="flex flex-col gap-3 mb-4">
        <label className="text-sm" htmlFor="projection-income-delta">
          Income change:
          <input
            id="projection-income-delta"
            type="number"
            value={incomeDelta}
            onChange={(event) => setIncomeDelta(Number(event.target.value))}
            className="border border-black ml-2 p-1 w-24"
          />
        </label>

        <label className="text-sm" htmlFor="projection-expense-delta">
          Expense change:
          <input
            id="projection-expense-delta"
            type="number"
            value={expenseDelta}
            onChange={(event) => setExpenseDelta(Number(event.target.value))}
            className="border border-black ml-2 p-1 w-24"
          />
        </label>

        <label className="text-sm" htmlFor="projection-savings-delta">
          Savings change:
          <input
            id="projection-savings-delta"
            type="number"
            value={savingsDelta}
            onChange={(event) => setSavingsDelta(Number(event.target.value))}
            className="border border-black ml-2 p-1 w-24"
          />
        </label>

        <label className="text-sm" htmlFor="projection-debt-delta">
          Debt change:
          <input
            id="projection-debt-delta"
            type="number"
            value={debtDelta}
            onChange={(event) => setDebtDelta(Number(event.target.value))}
            className="border border-black ml-2 p-1 w-24"
          />
        </label>
      </div>

      <button
        type="button"
        onClick={applyProjection}
        className="py-2 px-4 border border-black rounded bg-[var(--ff-seafoam)]"
      >
        Apply Projection
      </button>

      {projection && (
        <div className="mt-6">
          <h3 className="ff-heading-serif-rainy text-lg mb-2">
            Projected Insights
          </h3>

          <div className="flex flex-col gap-3">
            {projection.projectedInsights.map((projectedInsight, index) => (
              <div
                key={`${projectedInsight.insight.what}-${index}`}
                className="border border-black p-3 rounded"
              >
                <p className="font-medium">
                  {projectedInsight.insight.what}
                </p>
                <p className="text-sm text-gray-700">
                  {projectedInsight.insight.why}
                </p>
                <p className="text-sm text-gray-700 italic">
                  {projectedInsight.insight.next}
                </p>
                <p className="text-xs mt-2 text-gray-500">
                  Confidence weight: {projectedInsight.weight}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}