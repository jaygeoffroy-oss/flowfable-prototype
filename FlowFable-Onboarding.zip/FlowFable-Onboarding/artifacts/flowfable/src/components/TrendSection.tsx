"use client";

import React from "react";
import type { TrendsResult } from "@/types/FlowResult";

export default function TrendSection({ trends }: { trends: TrendsResult }) {
  return (
    <div
      className="
        bg-[var(--ff-base-dark)]/40
        border border-[var(--ff-rain-blue)]/30
        rounded-xl
        p-4
        shadow-[0_0_20px_rgba(0,0,0,0.25)]
        backdrop-blur-md
      "
    >
      <h2 className="text-xl font-semibold ff-heading-serif-rainy">Trends</h2>

      <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-rain-blue)]">
        Direction: <span className="text-[var(--ff-seafoam)]">{trends.direction}</span>
      </p>
      <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-rain-blue)]">
        Momentum: <span className="text-[var(--ff-coral)]">{trends.momentum}</span>
      </p>
      <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-rain-blue)]">
        Volatility: <span className="text-[var(--ff-fog-gray)]">{trends.volatility}</span>
      </p>
      <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-rain-blue)]">
        Pressure: <span className="text-[var(--ff-coral)]">{trends.pressure}</span>
      </p>
      <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-rain-blue)]">
        Stability: <span className="text-[var(--ff-seafoam)]">{trends.stability}</span>
      </p>

      <div className="mt-3">
        {trends.signals.map((sig) => (
          <div key={sig.label} className="text-[var(--ff-fog-gray)]">
            • {sig.label}: {sig.value}
          </div>
        ))}
      </div>
    </div>
  );
}
