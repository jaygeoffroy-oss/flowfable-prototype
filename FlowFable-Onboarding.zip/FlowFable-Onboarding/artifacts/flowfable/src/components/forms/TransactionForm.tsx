"use client";

import { useState } from "react";

interface TransactionFormProps {
  onSubmit: (payload: {
    name: string;
    amount: number;
    category: string;
    date: string;
  }) => void;
}

export default function TransactionForm({ onSubmit }: TransactionFormProps) {
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [category, setCategory] = useState("");
  const [date, setDate] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const value = Number(amount);
    if (!name || !category || !date || isNaN(value) || value <= 0) return;

    onSubmit({ name, amount: value, category, date });

    setName("");
    setAmount("");
    setCategory("");
    setDate("");
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="p-4 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4"
    >
      <h3 className="text-lg font-semibold text-[#FFD400]">
        Add Transaction
      </h3>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="transaction-name">
          Name
        </label>
        <input
          id="transaction-name"
          type="text"
          value={name}
          onChange={e => setName(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter transaction name"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="transaction-amount">
          Amount
        </label>
        <input
          id="transaction-amount"
          type="number"
          min="0"
          step="0.01"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter amount"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="transaction-category">
          Category
        </label>
        <input
          id="transaction-category"
          type="text"
          value={category}
          onChange={e => setCategory(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter category"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="transaction-date">
          Date
        </label>
        <input
          id="transaction-date"
          type="date"
          value={date}
          onChange={e => setDate(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
        />
      </div>

      <button
        type="submit"
        className="p-2 bg-[#FF7A00] text-black font-semibold rounded hover:bg-[#FF8F33] transition-colors"
      >
        Add Transaction
      </button>
    </form>
  );
}