"use client";

import { useState } from "react";

interface BudgetFormProps {
  onSubmit: (payload: { category: string; amount: number }) => void;
}

export default function BudgetForm({ onSubmit }: BudgetFormProps) {
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const value = Number(amount);
    if (!category || isNaN(value) || value <= 0) return;

    onSubmit({ category, amount: value });

    setCategory("");
    setAmount("");
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="p-4 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4"
    >
      <h3 className="text-lg font-semibold text-[#FFD400]">Add Budget</h3>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="budget-category">
          Category
        </label>
        <input
          id="budget-category"
          type="text"
          value={category}
          onChange={e => setCategory(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter category"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="budget-amount">
          Amount
        </label>
        <input
          id="budget-amount"
          type="number"
          min="0"
          step="0.01"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter amount"
        />
      </div>

      <button
        type="submit"
        className="p-2 bg-[#FF7A00] text-black font-semibold rounded hover:bg-[#FF8F33] transition-colors"
      >
        Add Budget
      </button>
    </form>
  );
}