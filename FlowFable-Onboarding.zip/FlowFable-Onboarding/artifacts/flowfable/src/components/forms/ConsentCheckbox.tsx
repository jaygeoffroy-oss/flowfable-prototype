"use client";

interface ConsentCheckboxProps {
  accepted: boolean;
  setAccepted: (accepted: boolean) => void;
}

export function ConsentCheckbox({
  accepted,
  setAccepted
}: ConsentCheckboxProps) {
  return (
    <label className="flex items-center gap-3 mt-4">
      <input
        type="checkbox"
        checked={accepted}
        onChange={(e) => setAccepted(e.target.checked)}
        className="h-5 w-5 accent-[var(--ff-seafoam)]"
      />
      <span className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-rain-blue)]">
        I agree to the Terms and Conditions
      </span>
    </label>
  );
}

export default ConsentCheckbox;