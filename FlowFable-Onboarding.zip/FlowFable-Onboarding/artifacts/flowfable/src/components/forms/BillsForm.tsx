"use client";

import { useState } from "react";

interface BillsFormProps {
  onSubmit: (payload: { name: string; amount: number; cadence: string }) => void;
}

export default function BillsForm({ onSubmit }: BillsFormProps) {
  const [name, setName] = useState("");
  const [amount, setAmount] = useState("");
  const [cadence, setCadence] = useState("monthly");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const value = Number(amount);
    if (!name || isNaN(value) || value <= 0) return;

    onSubmit({ name, amount: value, cadence });

    setName("");
    setAmount("");
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="p-4 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4"
    >
      <h3 className="text-lg font-semibold text-[#FFD400]">Add Bill</h3>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="bill-name">
          Bill name
        </label>
        <input
          id="bill-name"
          type="text"
          value={name}
          onChange={e => setName(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter bill name"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="bill-amount">
          Amount
        </label>
        <input
          id="bill-amount"
          type="number"
          min="0"
          step="0.01"
          value={amount}
          onChange={e => setAmount(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
          placeholder="Enter amount"
        />
      </div>

      <div className="flex flex-col gap-2">
        <label className="text-sm text-white" htmlFor="bill-cadence">
          Cadence
        </label>
        <select
          id="bill-cadence"
          value={cadence}
          onChange={e => setCadence(e.target.value)}
          className="p-2 rounded bg-[#0A1A2F] text-white border border-[#3A4F7A]"
        >
          <option value="weekly">Weekly</option>
          <option value="biweekly">Biweekly</option>
          <option value="monthly">Monthly</option>
          <option value="annually">Annually</option>
        </select>
      </div>

      <button
        type="submit"
        className="p-2 bg-[#FF7A00] text-black font-semibold rounded hover:bg-[#FF8F33] transition-colors"
      >
        Add Bill
      </button>
    </form>
  );
}