import React from "react";
import type { IncomeResult } from "@/types/FlowResult";
import { getUpcomingIncome } from "@/lib/income/getUpcomingIncome";

export default function IncomeCard({ data }: { data: IncomeResult }) {
  return (
    <div className="rounded-xl border border-[#FF6A00]/40 bg-black/40 p-6 shadow-lg backdrop-blur-md">
      <h2 className="mb-4 text-xl font-semibold ff-heading-serif-rainy">
        Income
      </h2>

      <div className="space-y-2">
        <p className="text-lg">
          Monthly total: <span className="font-bold">{data.total}</span>
        </p>
        <p className="text-sm text-gray-300">
          Sources: {data.sources.length}
        </p>
      </div>

      <div className="mt-4 space-y-2">
        {data.sources.map((src, index) => {
          const isRecurring = Boolean(src.recurring);
          const upcomingIncome = getUpcomingIncome(src);

          return (
            <div
              key={`${src.name}-${index}`}
              data-recurring={isRecurring}
              data-upcoming={upcomingIncome?.amount}
              data-next-date={upcomingIncome?.date}
              className="rounded-lg border border-gray-700 bg-black/30 p-3"
            >
              <h3 className="text-lg font-semibold ff-heading-serif-rainy">
                {src.name}
              </h3>
              <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
                Total: <span className="text-[var(--ff-seafoam)]">{src.amount}</span>
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}