import type { SavingsOpportunity } from "@/lib/savingsOpportunities";

export function SavingsOpportunitiesCard({ opportunities }: { opportunities: SavingsOpportunity[] }) {
  if (!opportunities || opportunities.length === 0) {
    return (
      <div className="card">
        <h2>Savings Opportunities</h2>
        <p>No savings opportunities detected yet.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>Savings Opportunities</h2>

      {opportunities.map((op, i) => (
        <div key={i} className="opportunity">
          <strong>{op.title}</strong>
          <p>{op.detail}</p>
          <p>Estimated monthly impact: ${op.estimatedMonthlyImpact.toFixed(2)}</p>
        </div>
      ))}
    </div>
  );
}
