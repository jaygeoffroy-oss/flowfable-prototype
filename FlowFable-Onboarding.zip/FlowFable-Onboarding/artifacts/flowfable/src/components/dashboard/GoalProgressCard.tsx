import type { GoalProgress } from "@/lib/goalProgress";

export function GoalProgressCard({ progress }: { progress: GoalProgress | null }) {
  if (!progress) {
    return (
      <div className="card">
        <h2>Goal Progress</h2>
        <p>No goal data available yet.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>{progress.goalName}</h2>

      <p>
        <strong>Monthly target:</strong> ${progress.monthlyTarget.toFixed(2)}
      </p>

      <p>
        <strong>Current progress:</strong> ${progress.currentProgress.toFixed(2)}
      </p>

      <p>
        <strong>Completion:</strong> {progress.percentage.toFixed(0)}%
      </p>
    </div>
  );
}
