import type { SubscriptionBreakdown } from "@/lib/subscriptionBreakdown";

export function SubscriptionBreakdownCard({ breakdown }: { breakdown: SubscriptionBreakdown | null }) {
  if (!breakdown) return null;

  return (
    <div className="card">
      <h2>Subscriptions</h2>

      <p>
        <strong>Total monthly cost:</strong> ${breakdown.total.toFixed(2)}
      </p>

      <h3>Merchants</h3>
      <ul>
        {breakdown.merchants.map((m) => (
          <li key={m}>{m}</li>
        ))}
      </ul>
    </div>
  );
}
