interface DashboardCardProps {
  title: string;
  eyebrow?: string;
  children: React.ReactNode;
  className?: string;
}

export default function DashboardCard({
  title,
  eyebrow,
  children,
  className = ""
}: DashboardCardProps) {
  return (
    <section
      className={`rounded-2xl border border-white/10 bg-white/[0.04] p-6 shadow-xl shadow-black/10 ${className}`}
    >
      {eyebrow && (
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.18em] text-[#FF6A00]">
          {eyebrow}
        </p>
      )}
      <h2 className="mb-5 text-xl font-semibold ff-heading-serif-rainy">
        {title}
      </h2>
      {children}
    </section>
  );
}