import React from "react";
import type { BudgetResult } from "@/types/FlowResult";

export default function BudgetCard({ data }: { data: BudgetResult }) {
  return (
    <div className="rounded-xl border border-yellow-400/40 bg-black/40 p-6 shadow-lg backdrop-blur-md">
      <h2 className="mb-4 text-xl font-semibold ff-heading-serif-rainy">
        Budget Categories
      </h2>

      <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-seafoam)]">
        Remaining: {data.remaining}
      </p>
      <p className="text-sm text-gray-300">
        Categories: {data.categories.length}
      </p>

      <div className="mt-4 space-y-2">
        {data.categories.map((category, index) => (
          <div
            key={`${category.name}-${index}`}
            className="rounded-lg border border-yellow-600/40 bg-black/30 p-3"
          >
            <h3 className="text-lg font-semibold ff-heading-serif-rainy">
              {category.name}
            </h3>
            <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
              Total: <span className="text-[var(--ff-coral)]">{category.amount}</span>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}