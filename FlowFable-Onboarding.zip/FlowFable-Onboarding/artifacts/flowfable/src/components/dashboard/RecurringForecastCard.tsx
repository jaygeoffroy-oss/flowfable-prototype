import type { RecurringForecast } from "@/lib/recurringForecast";

export function RecurringForecastCard({ forecasts }: { forecasts: RecurringForecast[] }) {
  if (!forecasts || forecasts.length === 0) {
    return (
      <div className="card">
        <h2>Upcoming Charges</h2>
        <p>No predicted upcoming charges yet.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>Upcoming Charges</h2>

      {forecasts.map((fc) => (
        <div key={fc.merchant} className="forecast-row">
          <strong>{fc.merchant}</strong>
          <p>Next charge: {fc.nextChargeDate}</p>
          <p>Amount: ${fc.averageAmount.toFixed(2)}</p>
          <p>Confidence: {(fc.confidence * 100).toFixed(0)}%</p>
        </div>
      ))}
    </div>
  );
}
