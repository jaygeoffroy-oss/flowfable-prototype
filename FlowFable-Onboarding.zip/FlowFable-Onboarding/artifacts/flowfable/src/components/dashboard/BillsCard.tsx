import React from "react";
import type { BillsResult } from "@/types/FlowResult";

export default function BillsCard({ data }: { data: BillsResult }) {
  return (
    <div className="rounded-xl border border-red-500/40 bg-black/40 p-6 shadow-lg backdrop-blur-md">
      <h2 className="mb-4 text-xl font-semibold ff-heading-serif-rainy">
        Bills
      </h2>

      <p className="mb-2 text-lg">
        Monthly total: <span className="font-bold">{data.total}</span>
      </p>
      <p className="text-sm text-gray-300">
        Bills tracked: {data.items.length}
      </p>

      <div className="mt-4 space-y-2">
        {data.items.map((bill, index) => (
          <div
            key={`${bill.name}-${index}`}
            className="rounded-lg border border-red-700/40 bg-black/30 p-3"
          >
            <h3 className="text-lg font-semibold ff-heading-serif-rainy">
              {bill.name}
            </h3>
            <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
              Total: <span className="text-[var(--ff-coral)]">{bill.amount}</span>
            </p>
            {bill.dueDate && (
              <p className="text-sm font-[var(--ff-font-serif)] text-[var(--ff-seafoam)]">
                Upcoming: {bill.dueDate}
              </p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}