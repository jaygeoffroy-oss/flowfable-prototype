import type { CashFlowProjection } from "@/lib/cashFlowProjection";

export function CashFlowProjectionCard({
  projection,
}: {
  projection: CashFlowProjection[];
}) {
  if (!projection || projection.length === 0) {
    return (
      <div className="card">
        <h2>30‑Day Cash Flow Projection</h2>
        <p>No projection data available.</p>
      </div>
    );
  }

  return (
    <div className="card">
      <h2>30‑Day Cash Flow Projection</h2>

      {projection.map((day) => (
        <div key={day.date} className="projection-row">
          <strong>{day.date}</strong>
          <p>Projected Balance: ${day.projectedBalance.toFixed(2)}</p>

          {day.upcomingCharges.length > 0 ? (
            <ul>
              {day.upcomingCharges.map((c) => (
                <li key={c.merchant}>
                  {c.merchant}: ${c.amount.toFixed(2)}
                </li>
              ))}
            </ul>
          ) : (
            <p>No charges.</p>
          )}
        </div>
      ))}
    </div>
  );
}
