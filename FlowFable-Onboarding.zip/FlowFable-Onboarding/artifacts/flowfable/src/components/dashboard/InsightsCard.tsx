import React from "react";
import type { InsightsResult } from "@/types/FlowResult";

export default function InsightsCard({ data }: { data: InsightsResult }) {
  return (
    <div className="rounded-xl border border-orange-400/40 bg-black/40 p-6 shadow-lg backdrop-blur-md">
      <h2 className="mb-4 text-2xl font-semibold text-orange-400">
        Insights
      </h2>

      <p className="mb-4 text-sm text-gray-300">
        Generated insights: {data.items.length}
      </p>

      <div className="space-y-3">
        {data.items.map((insight, index) => (
          <div
            key={`${insight.title}-${index}`}
            className="rounded-lg border border-orange-600/40 bg-black/30 p-3"
          >
            <p className="font-medium">{insight.title}</p>
            <p className="text-sm text-gray-300">{insight.detail}</p>
          </div>
        ))}
      </div>
    </div>
  );
}