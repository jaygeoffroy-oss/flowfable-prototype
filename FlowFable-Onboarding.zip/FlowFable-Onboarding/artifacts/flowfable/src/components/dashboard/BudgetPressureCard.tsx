import type { BudgetPressureIndex } from "@/lib/budgetPressureIndex";

export function BudgetPressureCard({
  pressure,
}: {
  pressure: BudgetPressureIndex | null;
}) {
  if (!pressure) {
    return (
      <div className="card">
        <h2>Budget Pressure Index</h2>
        <p>No pressure data available.</p>
      </div>
    );
  }

  const severityColor =
    pressure.severity === "high"
      ? "var(--danger)"
      : pressure.severity === "medium"
      ? "var(--warning)"
      : "var(--success)";

  return (
    <div className="card">
      <h2>Budget Pressure Index</h2>

      <div className="pressure-row">
        <strong style={{ color: severityColor }}>
          {pressure.score}/100 — {pressure.severity.toUpperCase()}
        </strong>
        <p>{pressure.message}</p>
      </div>
    </div>
  );
}
