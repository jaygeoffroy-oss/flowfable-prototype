import type { Insight } from "@/lib/insightTypes";

export function RecurringExpensesCard({ insights }: { insights: Insight[] }) {
  return (
    <div className="card recurring-expenses-card">
      <h2>Recurring Expense Insights</h2>

      {insights.length === 0 && (
        <p>No recurring expense insights detected.</p>
      )}

      {insights.map((insight, idx) => (
        <div key={idx} className={`recurring-expense-block severity-${insight.severity}`}>
          <p><strong>What:</strong> {insight.what}</p>
          <p><strong>Why:</strong> {insight.why}</p>

          <p><strong>Options:</strong></p>
          <ul>
            {insight.options.map((opt, i) => (
              <li key={i}>{opt}</li>
            ))}
          </ul>

          <p><strong>Consequences:</strong></p>
          <ul>
            {insight.consequences.map((c, i) => (
              <li key={i}>{c}</li>
            ))}
          </ul>

          <p><strong>Return to goal:</strong> {insight.returnToGoal}</p>
        </div>
      ))}
    </div>
  );
}
