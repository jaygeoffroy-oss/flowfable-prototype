"use client";

import type { Insight } from "@/lib/insightTypes";

interface InsightCardProps {
  insight: Insight;
}

export default function InsightCard({ insight }: InsightCardProps) {
  const severityColor =
    insight.severity === "critical"
      ? "border-red-500"
      : insight.severity === "warning"
      ? "border-yellow-500"
      : "border-blue-500";

  return (
    <div
      className={`border ${severityColor} rounded-lg p-4 bg-white shadow-sm flex flex-col gap-3`}
    >
      <div className="flex flex-col">
        <h2 className="text-lg font-semibold">{insight.what}</h2>
        <p className="text-sm text-gray-600">{insight.why}</p>
      </div>

      {insight.options.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-gray-800">Options</h3>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {insight.options.map((opt, idx) => (
              <li key={idx}>{opt}</li>
            ))}
          </ul>
        </div>
      )}

      {insight.consequences.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-gray-800">Consequences</h3>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {insight.consequences.map((c, idx) => (
              <li key={idx}>{c}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="pt-2 border-t border-gray-200">
        <p className="text-sm text-gray-600 italic">{insight.returnToGoal}</p>
      </div>
    </div>
  );
}
