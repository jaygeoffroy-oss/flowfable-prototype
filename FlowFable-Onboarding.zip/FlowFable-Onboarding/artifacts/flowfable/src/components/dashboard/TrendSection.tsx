"use client";

import type { Insight } from "@/lib/insightTypes";
import TrendCard from "./TrendCard";

interface TrendSectionProps {
  trends: Insight[];
}

export default function TrendSection({ trends }: TrendSectionProps) {
  if (!trends || trends.length === 0) {
    return (
      <div className="p-4 border border-gray-200 rounded-lg bg-white shadow-sm">
        <p className="text-sm text-gray-600">
          No trend insights available yet. As FlowFable gathers more history,
          your trend section will come alive.
        </p>
      </div>
    );
  }

  return (
    <section className="flex flex-col gap-4">
      <h2 className="text-xl font-semibold text-gray-800">Trend Insights</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {trends.map((trend, idx) => (
          <TrendCard key={idx} trend={trend} />
        ))}
      </div>
    </section>
  );
}
