import type { Decision } from "@/lib/decisionTypes";

export function DecisionCard({ decision }: { decision: Decision | null }) {
  if (!decision) return null;

  return (
    <div className="card">
      <h2>{decision.title}</h2>
      <p>{decision.reason}</p>
      {decision.recommendation && (
        <p>
          <strong>Recommended action:</strong> {decision.recommendation}
        </p>
      )}
    </div>
  );
}
