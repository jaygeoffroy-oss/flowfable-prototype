"use client";

import type { Insight } from "@/lib/insightTypes";

interface EducationalCardProps {
  education: Insight;
}

export default function EducationalCard({ education }: EducationalCardProps) {
  const severityColor =
    education.severity === "critical"
      ? "border-red-500"
      : education.severity === "warning"
      ? "border-yellow-500"
      : "border-blue-500";

  return (
    <div
      className={`border ${severityColor} rounded-lg p-4 bg-white shadow-sm flex flex-col gap-3`}
    >
      <div className="flex flex-col">
        <h2 className="text-lg font-semibold">{education.what}</h2>
        <p className="text-sm text-gray-600">{education.why}</p>
      </div>

      {education.options.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-gray-800">What this teaches</h3>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {education.options.map((opt, idx) => (
              <li key={idx}>{opt}</li>
            ))}
          </ul>
        </div>
      )}

      {education.consequences.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-gray-800">Why it matters</h3>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {education.consequences.map((c, idx) => (
              <li key={idx}>{c}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="pt-2 border-t border-gray-200">
        <p className="text-sm text-gray-600 italic">{education.returnToGoal}</p>
      </div>
    </div>
  );
}
