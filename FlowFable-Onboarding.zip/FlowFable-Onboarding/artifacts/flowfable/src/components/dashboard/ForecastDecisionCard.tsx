import type { Decision } from "@/lib/decisionTypes";

export function ForecastDecisionCard({ decision }: { decision: Decision | null }) {
  if (!decision) {
    return (
      <div className="card forecast-decision">
        <h2>Forecast Decision</h2>
        <p>No decision generated yet.</p>
      </div>
    );
  }

  return (
    <div className="card forecast-decision">
      <h2>{decision.title}</h2>

      <p><strong>Reason:</strong> {decision.reason}</p>

      {decision.recommendation ? (
        <p><strong>Recommendation:</strong> {decision.recommendation}</p>
      ) : (
        <p>No specific recommendation required.</p>
      )}
    </div>
  );
}
