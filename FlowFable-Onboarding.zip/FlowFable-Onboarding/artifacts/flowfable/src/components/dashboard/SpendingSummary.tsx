import type { SpendingPatterns } from "@/lib/spendingPatterns";

export function SpendingSummary({ events }: { events: { patterns: SpendingPatterns }[] }) {
  if (!events || events.length === 0) {
    return (
      <div className="card">
        <h2>Spending Summary</h2>
        <p>No spending data available yet.</p>
      </div>
    );
  }

  const latest = events[0].patterns;

  return (
    <div className="card">
      <h2>Spending Summary</h2>

      <p>
        <strong>Subscriptions:</strong>{" "}
        ${latest.subscriptions.monthlyTotal.toFixed(2)}
      </p>

      {latest.lifestyleCreep.detected && (
        <p className="warning">
          <strong>Warning:</strong> {latest.lifestyleCreep.reason}
        </p>
      )}

      <p>
        <strong>Emergency expenses:</strong> {latest.emergencyExpenses.count}
      </p>

      <p>
        <strong>Monthly income:</strong>{" "}
        ${latest.incomeStability.monthlyIncome.toFixed(2)}
      </p>
    </div>
  );
}
