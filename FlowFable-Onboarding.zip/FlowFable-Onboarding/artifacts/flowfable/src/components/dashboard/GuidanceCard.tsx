import React from "react";
import type { GuidanceResult } from "@/types/FlowResult";

export default function GuidanceCard({ data }: { data: GuidanceResult }) {
  return (
    <div className="rounded-xl border border-green-400/40 bg-black/40 p-6 shadow-lg backdrop-blur-md">
      <h2 className="mb-4 text-2xl font-semibold text-green-400">
        Guidance
      </h2>

      <p className="mb-4 text-sm text-gray-300">
        Recommendations: {data.items.length}
      </p>

      <div className="space-y-3">
        {data.items.map((guidance, index) => (
          <div
            key={`${guidance.title}-${index}`}
            className="rounded-lg border border-green-700/40 bg-black/30 p-3"
          >
            <p className="font-medium">{guidance.title}</p>
            <p className="text-sm text-gray-300">{guidance.action}</p>
          </div>
        ))}
      </div>
    </div>
  );
}