import React from "react";
import type { TrendsResult } from "@/types/FlowResult";

export default function TrendsCard({ data }: { data: TrendsResult }) {
  return (
    <div className="rounded-xl border border-blue-500/40 bg-black/40 p-6 shadow-lg backdrop-blur-md">
      <h2 className="mb-4 text-2xl font-semibold text-blue-400">Trends</h2>

      <p className="mb-2 text-lg">
        Direction: <span className="font-bold">{data.direction}</span>
      </p>
      <p className="text-sm text-gray-300">Signals: {data.signals.length}</p>

      <div className="mt-4 space-y-2">
        {data.signals.map((signal, index) => (
          <div
            key={`${signal.label}-${index}`}
            className="rounded-lg border border-blue-700/40 bg-black/30 p-3"
          >
            <p className="font-medium">{signal.label}</p>
            <p className="text-sm text-gray-300">{signal.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}