"use client";

import type { Insight } from "@/lib/insightTypes";

interface TrendCardProps {
  trend: Insight;
}

export default function TrendCard({ trend }: TrendCardProps) {
  const severityColor =
    trend.severity === "critical"
      ? "border-red-500"
      : trend.severity === "warning"
      ? "border-yellow-500"
      : "border-blue-500";

  return (
    <div
      className={`border ${severityColor} rounded-lg p-4 bg-white shadow-sm flex flex-col gap-3`}
    >
      <div className="flex flex-col">
        <h2 className="text-lg font-semibold">{trend.what}</h2>
        <p className="text-sm text-gray-600">{trend.why}</p>
      </div>

      {trend.options.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-gray-800">What this trend suggests</h3>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {trend.options.map((opt, idx) => (
              <li key={idx}>{opt}</li>
            ))}
          </ul>
        </div>
      )}

      {trend.consequences.length > 0 && (
        <div className="flex flex-col gap-2">
          <h3 className="text-sm font-medium text-gray-800">If this trend continues</h3>
          <ul className="list-disc list-inside text-sm text-gray-700">
            {trend.consequences.map((c, idx) => (
              <li key={idx}>{c}</li>
            ))}
          </ul>
        </div>
      )}

      <div className="pt-2 border-t border-gray-200">
        <p className="text-sm text-gray-600 italic">{trend.returnToGoal}</p>
      </div>
    </div>
  );
}
