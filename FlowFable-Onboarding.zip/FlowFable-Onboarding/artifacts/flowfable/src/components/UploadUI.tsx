"use client";

import React, { useState } from "react";
import ConsentCheckbox from "@/components/forms/ConsentCheckbox";
import { ingestBrowserFile } from "@/lib/upload/ingestBrowserFile";
import { useConsentStore } from "@/store/consent";

type UploadUIProps = {
  onUploadComplete: (filePath: string) => void;
};

type UploadStatus = "idle" | "uploading" | "success" | "error";

export default function UploadUI({
  onUploadComplete
}: UploadUIProps) {
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<UploadStatus>("idle");
  const { accepted, setAccepted } = useConsentStore();
  const canUpload = accepted && Boolean(file) && status !== "uploading";

  function handleSelect(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files?.[0] ?? null;
    setFile(selected);
    setStatus("idle");
  }

  async function handleUpload() {
    if (!file || !accepted) return;

    setStatus("uploading");

    try {
      const flow = await ingestBrowserFile(file);
      const filePath = flow.meta?.filePath;

      if (!filePath) {
        throw new Error("Upload succeeded but no file path was returned.");
      }

      onUploadComplete(filePath);
      setStatus("success");
    } catch (err) {
      console.error("Upload error", err);
      setStatus("error");
    }
  }

  return (
    <div className="p-6 bg-[var(--ff-base-dark)]/40 border border-[var(--ff-rain-blue)]/30 rounded-xl backdrop-blur-md">
      <h2 className="text-xl ff-heading-serif-rainy mb-4">
        Upload Financial Document
      </h2>

      <div className="mb-4 rounded-lg border border-gray-700 bg-black/30 p-6 text-center">
        <p className="mb-3 text-gray-300">
          Drag and drop a file or select one
        </p>

        <input
          type="file"
          onChange={handleSelect}
          className="block w-full text-sm text-gray-300"
        />

        {file && (
          <p className="mt-3 text-sm text-gray-400">
            Selected: {file.name}
          </p>
        )}
      </div>

      <ConsentCheckbox accepted={accepted} setAccepted={setAccepted} />
      <a
        href="/terms"
        className="text-sm text-[var(--ff-seafoam)] underline block mt-2"
      >
        View Terms and Conditions
      </a>
      <a
        href="/privacy"
        className="text-sm text-[var(--ff-seafoam)] underline block mt-2"
      >
        Privacy Policy
      </a>
      <a
        href="/cookies"
        className="text-sm text-[var(--ff-seafoam)] underline block mt-2"
      >
        Cookie Policy
      </a>

      <button
        type="button"
        onClick={handleUpload}
        disabled={!canUpload}
        className={`mt-4 px-4 py-2 rounded-lg ${
          canUpload
            ? "bg-[var(--ff-seafoam)] text-black"
            : "bg-gray-600 text-gray-400 cursor-not-allowed"
        }`}
      >
        {status === "uploading" ? "Uploading…" : "Upload"}
      </button>

      {status === "success" && (
        <p className="mt-4 text-center text-sm text-green-400">
          Upload successful
        </p>
      )}

      {status === "error" && (
        <p className="mt-4 text-center text-sm text-red-400">
          Upload failed. Try again.
        </p>
      )}
    </div>
  );
}