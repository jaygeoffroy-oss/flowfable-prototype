"use client";

import React, { useState } from "react";
import { forecastDependencies } from "@/lib/goals/dependencyForecaster";
import ProjectionScenarioOverlayChart from "./ProjectionScenarioOverlayChart";

interface GoalDependencyForecasterProps {
  goals: any[];
  profile: any;
  history: any[];
}

export default function GoalDependencyForecaster({
  goals,
  profile,
  history
}: GoalDependencyForecasterProps) {
  const [selectedScenarioId, setSelectedScenarioId] = useState<number | null>(
    null
  );

  const scenario = history.find(historyItem => {
    return historyItem.id === selectedScenarioId;
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Dependency Forecaster
      </h3>

      {history.length === 0 ? (
        <p className="text-sm text-white">
          Save a scenario to forecast dependencies.
        </p>
      ) : (
        <>
          <label className="flex flex-col gap-1 text-white text-sm">
            Select Scenario
            <select
              className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
              value={selectedScenarioId ?? ""}
              onChange={event => {
                setSelectedScenarioId(
                  event.target.value === ""
                    ? null
                    : Number(event.target.value)
                );
              }}
            >
              <option value="">Choose a scenario</option>
              {history.map(historyItem => (
                <option key={historyItem.id} value={historyItem.id}>
                  {historyItem.goalName} —{" "}
                  {new Date(historyItem.timestamp).toLocaleString()}
                </option>
              ))}
            </select>
          </label>

          {scenario &&
            goals
              .filter(goal => goal.id === scenario.goalId)
              .map(changedGoal => {
                const forecast = forecastDependencies(
                  goals,
                  changedGoal,
                  scenario,
                  profile
                );

                return (
                  <div key={changedGoal.id} className="flex flex-col gap-6">
                    <ProjectionScenarioOverlayChart
                      baseline={forecast.changedGoal.changedProjection}
                      scenario={forecast.changedGoal.changedProjection}
                      goalName={changedGoal.name}
                    />

                    <div className="overflow-x-auto">
                      <table className="min-w-full text-sm text-white border-collapse">
                        <thead>
                          <tr className="bg-[#0A1A2F]">
                            <th className="p-3 border border-[#3A4F7A]">
                              Goal
                            </th>
                            <th className="p-3 border border-[#3A4F7A]">
                              Baseline Completion
                            </th>
                            <th className="p-3 border border-[#3A4F7A]">
                              New Completion
                            </th>
                            <th className="p-3 border border-[#3A4F7A]">
                              Impact
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          {forecast.rippleEffects.length === 0 ? (
                            <tr>
                              <td
                                className="p-3 border border-[#3A4F7A]"
                                colSpan={4}
                              >
                                No other goals available for ripple analysis.
                              </td>
                            </tr>
                          ) : (
                            forecast.rippleEffects.map(ripple => (
                              <tr key={ripple.goalId}>
                                <td className="p-3 border border-[#3A4F7A]">
                                  {ripple.goalName}
                                </td>
                                <td className="p-3 border border-[#3A4F7A]">
                                  {ripple.baselineCompletion ?? "N/A"}
                                </td>
                                <td className="p-3 border border-[#3A4F7A]">
                                  {ripple.newCompletion ?? "N/A"}
                                </td>
                                <td className="p-3 border border-[#3A4F7A] text-[#FFD400]">
                                  {ripple.impact === null
                                    ? "N/A"
                                    : ripple.impact > 0
                                      ? `Slows by ${ripple.impact} months`
                                      : ripple.impact < 0
                                        ? `Accelerates by ${Math.abs(
                                            ripple.impact
                                          )} months`
                                        : "No change"}
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  </div>
                );
              })}
        </>
      )}
    </div>
  );
}