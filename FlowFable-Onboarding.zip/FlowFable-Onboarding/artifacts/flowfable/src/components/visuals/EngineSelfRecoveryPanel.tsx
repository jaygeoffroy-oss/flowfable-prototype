"use client";

import React from "react";
import { runEngineSelfRecovery } from "@/lib/coaching/engineSelfRecoveryEngine";

interface EngineSelfRecoveryPanelProps {
  flow: any;
}

export default function EngineSelfRecoveryPanel({
  flow
}: EngineSelfRecoveryPanelProps) {
  const recovered = runEngineSelfRecovery(flow);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Engine Self‑Recovery
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">Recovery Log</p>

        {recovered.recoveryLog.length === 0 ? (
          <p className="text-sm text-[#27AE60]">
            • No recovery actions needed.
          </p>
        ) : (
          recovered.recoveryLog.map((fix: string, index: number) => (
            <p key={`${fix}-${index}`} className="text-sm text-[#FFD400]">
              • {fix}
            </p>
          ))
        )}
      </div>
    </div>
  );
}