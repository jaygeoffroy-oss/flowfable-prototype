"use client";

import React, { useState } from "react";
import { buildProjectionMatrix } from "@/lib/goals/projectionMatrix";
import ProjectionChart from "@/components/visuals/ProjectionChart";

interface MultiGoalProjectionMatrixProps {
  goals: any[];
  profile: any;
}

export default function MultiGoalProjectionMatrix({
  goals,
  profile
}: MultiGoalProjectionMatrixProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to view multi-goal projections.
        </p>
      </div>
    );
  }

  const matrix = buildProjectionMatrix(goals, profile, months);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Multi-Goal Projection Matrix
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min="0"
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => setMonths(Math.max(0, Number(event.target.value)))}
        />
      </label>

      <div className="overflow-x-auto">
        <table className="min-w-full text-sm text-white border-collapse">
          <thead>
            <tr className="bg-[#0A1A2F]">
              <th scope="col" className="p-3 border border-[#3A4F7A] text-left">
                Goal
              </th>
              <th scope="col" className="p-3 border border-[#3A4F7A] text-left">
                Final Balance
              </th>
              <th scope="col" className="p-3 border border-[#3A4F7A] text-left">
                Completion Month
              </th>
              <th scope="col" className="p-3 border border-[#3A4F7A] text-left">
                Growth Rate
              </th>
              <th scope="col" className="p-3 border border-[#3A4F7A] text-left">
                Cadence
              </th>
            </tr>
          </thead>

          <tbody>
            {matrix.map(row => (
              <tr key={row.id}>
                <td className="p-3 border border-[#3A4F7A]">{row.name}</td>
                <td className="p-3 border border-[#3A4F7A]">
                  ${row.finalBalance.toFixed(2)}
                </td>
                <td className="p-3 border border-[#3A4F7A]">
                  {row.completionMonth ?? "N/A"}
                </td>
                <td className="p-3 border border-[#3A4F7A]">
                  {row.growthRate}%
                </td>
                <td className="p-3 border border-[#3A4F7A]">{row.cadence}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex flex-col gap-6">
        {matrix.map(row => (
          <ProjectionChart key={row.id} data={row.curve} goalName={row.name} />
        ))}
      </div>
    </div>
  );
}