"use client";

import React from "react";
import { buildGuidanceMetaAnalysis } from "@/lib/coaching/guidanceMetaAnalysisEngine";
import type { GuidanceFeedEntry } from "@/lib/guidanceTypes";
import type { GuidanceTrendAnalysis } from "@/lib/guidanceTrendAnalyzer";
import type { GuidanceEvolutionReport } from "@/lib/guidanceEvolutionReport";
import type { GoalStrategy } from "@/lib/goals/goalStrategyEngine";
import type { GoalPlaybookEntry } from "@/lib/goals/goalPlaybookEngine";

interface GuidanceMetaAnalysisPanelProps {
  feed?: GuidanceFeedEntry[] | null;
  trends?: GuidanceTrendAnalysis | null;
  evolutionReport?: GuidanceEvolutionReport | null;
  strategies?: GoalStrategy[] | null;
  playbooks?: GoalPlaybookEntry[] | null;
}

export default function GuidanceMetaAnalysisPanel({
  feed,
  trends,
  evolutionReport,
  strategies,
  playbooks
}: GuidanceMetaAnalysisPanelProps) {
  const meta = buildGuidanceMetaAnalysis({
    feed,
    trends,
    evolutionReport,
    strategies,
    playbooks
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Meta Analysis
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2">
        <p className="text-sm text-white">
          • Dominant Category:{" "}
          <span className="text-[#FFD400]">
            {meta.dominantCategory ?? "Unknown"}
          </span>
        </p>
        <p className="text-sm text-white">
          • Confidence Trend:{" "}
          <span className="text-[#FFD400]">
            {meta.risingConfidence ?? "Unknown"}
          </span>
        </p>
        <p className="text-sm text-white">
          • Risk Direction:{" "}
          <span className="text-[#FFD400]">
            {meta.riskDirection ?? "Unknown"}
          </span>
        </p>
        <p className="text-sm text-white">
          • Synergy Environment:{" "}
          <span className="text-[#FFD400]">
            {meta.synergyDirection ?? "Unknown"}
          </span>
        </p>
        <p className="text-sm text-white">
          • System Bias:{" "}
          <span className="text-[#FFD400]">
            {meta.systemBias ?? "Unknown"}
          </span>
        </p>
        <p className="text-sm text-white">
          • Volatility Level:{" "}
          <span className="text-[#FFD400]">
            {meta.volatilityLevel ?? "Unknown"}
          </span>
        </p>
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">Meta Summary</p>
        {meta.metaSummary.map((line, index) => (
          <p
            key={`${line}-${index}`}
            className="text-sm text-[#FFD400] leading-relaxed"
          >
            • {line}
          </p>
        ))}
      </div>
    </div>
  );
}