"use client";

import React from "react";

interface CategoryBreakdownProps {
  transactions: Array<{
    name: string;
    amount: number;
    category: string;
    date: string;
  }>;
}

export default function CategoryBreakdown({
  transactions
}: CategoryBreakdownProps) {
  if (!transactions || transactions.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">No transactions yet.</p>
      </div>
    );
  }

  const categoryTotals: Record<string, number> = {};
  let totalSpent = 0;

  transactions.forEach(t => {
    categoryTotals[t.category] =
      (categoryTotals[t.category] ?? 0) + t.amount;
    totalSpent += t.amount;
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Category Breakdown
      </h3>

      <div className="flex flex-col gap-4">
        {Object.entries(categoryTotals).map(([category, total]) => {
          const pct = totalSpent > 0 ? (total / totalSpent) * 100 : 0;

          return (
            <div key={category} className="flex flex-col gap-1">
              <div className="flex justify-between text-white text-sm">
                <span>{category}</span>
                <span>
                  ${total.toFixed(2)} • {pct.toFixed(1)}%
                </span>
              </div>

              <div className="h-3 bg-[#0A1A2F] rounded">
                <div
                  className="h-full bg-[#FF7A00] rounded"
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}