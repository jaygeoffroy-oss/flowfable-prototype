"use client";

import React from "react";
import { applyPersonalizationRules } from "@/lib/coaching/personalizationRules";
import { applyCoachingVoice } from "@/lib/coaching/voiceEngine";

interface GuidancePersonalizationWrapperProps {
  profile: any;
  style: string;
  lines: string[];
}

export default function GuidancePersonalizationWrapper({
  profile,
  style,
  lines
}: GuidancePersonalizationWrapperProps) {
  return (
    <div className="flex flex-col gap-3">
      {lines.map((line, index) => {
        const personalized = applyPersonalizationRules(profile, line);
        const voiced = applyCoachingVoice(style, personalized);

        return (
          <p
            key={`${line}-${index}`}
            className="text-sm text-white leading-relaxed"
          >
            • {voiced}
          </p>
        );
      })}
    </div>
  );
}