"use client";

import React from "react";
import { runGuidanceSystemAutopilot } from "@/lib/coaching/guidanceSystemAutopilotEngine";
import type { GuidanceSystemTuning } from "@/lib/coaching/guidanceSystemTuning";

interface GuidanceSystemAutopilotPanelProps {
  tuning?: Partial<GuidanceSystemTuning> | null;
}

export default function GuidanceSystemAutopilotPanel({
  tuning
}: GuidanceSystemAutopilotPanelProps) {
  const autopilot = runGuidanceSystemAutopilot(tuning);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance System Autopilot
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2">
        <p className="text-sm text-white">
          • Autopilot Status:{" "}
          <span className="text-[#27AE60]">
            {autopilot.status}
          </span>
        </p>
        <p className="text-sm text-white">
          • Risk Weight:{" "}
          <span className="text-[#FFD400]">
            {autopilot.applied.riskWeight}
          </span>
        </p>
        <p className="text-sm text-white">
          • Synergy Weight:{" "}
          <span className="text-[#FFD400]">
            {autopilot.applied.synergyWeight}
          </span>
        </p>
        <p className="text-sm text-white">
          • Confidence Smoothing:{" "}
          <span className="text-[#FFD400]">
            {autopilot.applied.confidenceSmoothing}
          </span>
        </p>
        <p className="text-sm text-white">
          • Category Bias:{" "}
          <span className="text-[#FFD400]">
            {autopilot.applied.categoryBias}
          </span>
        </p>
        <p className="text-sm text-white">
          • Scenario Aggression:{" "}
          <span className="text-[#FFD400]">
            {autopilot.applied.scenarioAggression}
          </span>
        </p>
        <p className="text-sm text-white">
          • Tone:{" "}
          <span className="text-[#FFD400]">
            {autopilot.applied.tone}
          </span>
        </p>
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Autopilot Change Log
        </p>
        {autopilot.changes.length === 0 ? (
          <p className="text-sm text-[#FFD400]">
            • No changes applied.
          </p>
        ) : (
          autopilot.changes.map((change, index) => (
            <p
              key={`${change}-${index}`}
              className="text-sm text-[#FFD400] leading-relaxed"
            >
              • {change}
            </p>
          ))
        )}
      </div>
    </div>
  );
}