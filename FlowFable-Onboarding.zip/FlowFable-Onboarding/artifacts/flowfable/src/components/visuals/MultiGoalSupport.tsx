"use client";

import React from "react";

interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentSavings: number;
  monthlyNet: number;
}

interface MultiGoalSupportProps {
  goals: Goal[];
}

export default function MultiGoalSupport({ goals }: MultiGoalSupportProps) {
  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">No goals added yet.</p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Multi-Goal Overview
      </h3>

      <div className="flex flex-col gap-6">
        {goals.map(goal => {
          const remaining = Math.max(
            0,
            goal.targetAmount - goal.currentSavings
          );
          const monthsToGoal =
            goal.monthlyNet > 0
              ? Math.ceil(remaining / goal.monthlyNet)
              : null;

          const status =
            goal.monthlyNet <= 0
              ? "Off Track"
              : monthsToGoal !== null && monthsToGoal <= 6
                ? "On Track"
                : monthsToGoal !== null && monthsToGoal <= 18
                  ? "Moderate Progress"
                  : "Long-Term Horizon";

          const statusColor =
            status === "On Track"
              ? "#27AE60"
              : status === "Moderate Progress"
                ? "#FF7A00"
                : status === "Long-Term Horizon"
                  ? "#2F80ED"
                  : "#EB5757";

          const progressPercent =
            goal.targetAmount > 0
              ? Math.min(
                  100,
                  Math.max(
                    0,
                    (goal.currentSavings / goal.targetAmount) * 100
                  )
                )
              : 0;

          return (
            <div
              key={goal.id}
              className="flex flex-col gap-4 p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]"
            >
              <p className="text-sm text-white font-semibold">{goal.name}</p>

              <div className="flex justify-between text-white text-sm">
                <span>Progress</span>
                <span style={{ color: statusColor }} className="font-semibold">
                  {progressPercent.toFixed(0)}%
                </span>
              </div>

              <div
                className="h-2 bg-[#0F0F0F] rounded"
                role="progressbar"
                aria-label={`${goal.name} progress`}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Number(progressPercent.toFixed(0))}
              >
                <div
                  className="h-full rounded transition-all"
                  style={{
                    width: `${progressPercent}%`,
                    backgroundColor: statusColor
                  }}
                />
              </div>

              <div className="flex justify-between text-white text-sm">
                <span>Estimated Time</span>
                <span style={{ color: statusColor }} className="font-semibold">
                  {goal.monthlyNet <= 0
                    ? "Not Achievable"
                    : monthsToGoal === 0
                      ? "Goal Reached"
                      : `${monthsToGoal} months`}
                </span>
              </div>

              <p className="text-xs text-[#E5E5E5] leading-relaxed">
                {status === "On Track" &&
                  "Your current pattern supports achieving this goal soon."}
                {status === "Moderate Progress" &&
                  "You’re progressing steadily. Increasing net flow will accelerate this goal."}
                {status === "Long-Term Horizon" &&
                  "This goal is achievable, but it will take time. Improving monthly net flow will shorten the horizon."}
                {status === "Off Track" &&
                  "Your current pattern cannot achieve this goal. Adjusting spending or increasing income will make progress possible."}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
}