"use client";

import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import type { GuidanceTrendAnalysis } from "@/lib/guidanceTrendAnalyzer";

interface GuidanceTrendAnalysisPanelProps {
  trends: GuidanceTrendAnalysis | null;
}

export default function GuidanceTrendAnalysisPanel({
  trends
}: GuidanceTrendAnalysisPanelProps) {
  if (!trends) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-sm text-white">
          Not enough data to analyze trends.
        </p>
      </div>
    );
  }

  const confidenceTrend = Array.isArray(trends.confidenceTrend)
    ? trends.confidenceTrend
    : [];
  const scoreTrend = Array.isArray(trends.scoreTrend) ? trends.scoreTrend : [];
  const categoryTrends = Array.isArray(trends.categoryTrends)
    ? trends.categoryTrends
    : [];
  const avgConfidence =
    typeof trends.avgConfidence === "number" ? trends.avgConfidence : 0;
  const avgScore = typeof trends.avgScore === "number" ? trends.avgScore : 0;

  const confidenceData = confidenceTrend.map((confidence, index) => ({
    index: index + 1,
    confidence
  }));

  const scoreData = scoreTrend.map((score, index) => ({
    index: index + 1,
    score
  }));

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Trend Analysis
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white">
          • Average Confidence:{" "}
          <span className="text-[#FFD400]">
            {avgConfidence.toFixed(1)}%
          </span>
        </p>
        <p className="text-sm text-white">
          • Average Score:{" "}
          <span className="text-[#FFD400]">
            {avgScore.toFixed(1)}
          </span>
        </p>
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Category Frequency
        </p>
        {categoryTrends.map(categoryTrend => (
          <p
            key={categoryTrend.category}
            className="text-sm text-white"
          >
            • {categoryTrend.category}:{" "}
            <span className="text-[#FFD400]">{categoryTrend.count}</span>
          </p>
        ))}
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Confidence Trend
        </p>
        <div style={{ width: "100%", height: 200 }}>
          <ResponsiveContainer>
            <LineChart data={confidenceData}>
              <XAxis
                dataKey="index"
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <YAxis
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0F0F0F",
                  border: "1px solid #3A4F7A",
                  color: "#FFD400"
                }}
              />
              <Line
                type="monotone"
                dataKey="confidence"
                stroke="#27AE60"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Score Trend
        </p>
        <div style={{ width: "100%", height: 200 }}>
          <ResponsiveContainer>
            <LineChart data={scoreData}>
              <XAxis
                dataKey="index"
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <YAxis
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0F0F0F",
                  border: "1px solid #3A4F7A",
                  color: "#FFD400"
                }}
              />
              <Line
                type="monotone"
                dataKey="score"
                stroke="#EB5757"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}