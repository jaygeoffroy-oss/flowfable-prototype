"use client";

import React from "react";
import type { RiskPoint } from "@/lib/projectionRiskEngine";

type ProjectionRiskHeatmapProps =
  | {
      riskPoints: RiskPoint[];
    }
  | {
      data: { month: number; balance: number; risk: number }[];
      goalName: string;
    };

export default function ProjectionRiskHeatmap(
  props: ProjectionRiskHeatmapProps
) {
  if ("riskPoints" in props) {
    return (
      <div className="mt-4 grid grid-cols-12 gap-1">
        {props.riskPoints.map((riskPoint) => {
          const color =
            riskPoint.score > 70
              ? "bg-red-600"
              : riskPoint.score > 40
                ? "bg-yellow-500"
                : "bg-green-600";

          return (
            <div
              key={riskPoint.month}
              className={`${color} h-4 rounded`}
              title={`${riskPoint.label} — ${riskPoint.score}/100`}
              aria-label={`Month ${riskPoint.month}: ${riskPoint.label} — ${riskPoint.score}/100`}
            />
          );
        })}
      </div>
    );
  }

  const { data, goalName } = props;

  const getColor = (risk: number) => {
    if (risk < 30) return "#27AE60";
    if (risk < 60) return "#F2C94C";
    return "#EB5757";
  };

  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Risk Heatmap
      </p>

      {data.length === 0 ? (
        <p className="text-xs text-white opacity-70">
          No projection risk data available.
        </p>
      ) : (
        <div className="grid grid-cols-12 gap-1">
          {data.map(point => (
            <div
              key={point.month}
              className="h-6 rounded"
              style={{ backgroundColor: getColor(point.risk) }}
              title={`Month ${point.month}: Risk ${point.risk}%`}
              aria-label={`Month ${point.month}: Risk ${point.risk}%`}
            />
          ))}
        </div>
      )}

      <p className="text-xs text-white opacity-70 mt-2">
        Green = Low Risk, Yellow = Moderate Risk, Red = High Risk
      </p>
    </div>
  );
}