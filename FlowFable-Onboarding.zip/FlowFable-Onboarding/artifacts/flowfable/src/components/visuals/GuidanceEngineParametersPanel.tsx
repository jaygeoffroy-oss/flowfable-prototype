"use client";

import React from "react";
import { resolveGuidanceEngineParameters } from "@/lib/coaching/guidanceEngineParametersEngine";
import type { GuidanceSystemTuning } from "@/lib/coaching/guidanceSystemTuning";
import type { GuidanceSystemAutopilotInput } from "@/lib/coaching/guidanceSystemGovernorEngine";
import type { GuidanceSystemGovernorResult } from "@/lib/coaching/guidanceSystemGovernorEngine";

interface GuidanceEngineParametersPanelProps {
  tuning?: Partial<GuidanceSystemTuning> | null;
  autopilot?: GuidanceSystemAutopilotInput | null;
  governor?: Partial<GuidanceSystemGovernorResult> | null;
}

export default function GuidanceEngineParametersPanel({
  tuning,
  autopilot,
  governor
}: GuidanceEngineParametersPanelProps) {
  const params = resolveGuidanceEngineParameters({
    tuning,
    autopilot,
    governor
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Engine Parameters
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2">
        <Parameter label="Risk Weight" value={params.riskWeight} />
        <Parameter label="Synergy Weight" value={params.synergyWeight} />
        <Parameter
          label="Confidence Smoothing"
          value={params.confidenceSmoothing}
        />
        <Parameter label="Category Bias" value={params.categoryBias} />
        <Parameter
          label="Scenario Aggression"
          value={params.scenarioAggression}
        />
        <Parameter label="Tone" value={params.tone} />
      </div>
    </div>
  );
}

function Parameter({
  label,
  value
}: {
  label: string;
  value: number | string;
}) {
  return (
    <p className="text-sm text-white">
      • {label}: <span className="text-[#FFD400]">{value}</span>
    </p>
  );
}