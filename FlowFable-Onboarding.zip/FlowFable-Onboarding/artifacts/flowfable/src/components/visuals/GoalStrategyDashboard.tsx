"use client";

import React from "react";

import GoalStrategyRecommenderPanel from "@/components/visuals/GoalStrategyRecommenderPanel";
import GoalStrategyPlaybookPanel from "@/components/visuals/GoalStrategyPlaybookPanel";

import GuidanceImpactForecasterPanel from "@/components/visuals/GuidanceImpactForecasterPanel";
import GuidanceSystemExplainerPanel from "@/components/visuals/GuidanceSystemExplainerPanel";

import ProjectionConfidenceBandPanel from "@/components/visuals/ProjectionConfidenceBandPanel";
import ProjectionDistributionSimulatorPanel from "@/components/visuals/ProjectionDistributionSimulatorPanel";
import ProjectionScenarioOptimizerPanel from "@/components/visuals/ProjectionScenarioOptimizerPanel";
import MultiScenarioComparisonPanel from "@/components/visuals/MultiScenarioComparisonPanel";

import GoalSynergyVisualMapPanel from "@/components/visuals/GoalSynergyVisualMapPanel";
import GoalSynergyOptimizerPanel from "@/components/visuals/GoalSynergyOptimizerPanel";
import ProjectionRiskHeatmapPanel from "@/components/visuals/ProjectionRiskHeatmapPanel";

import GuidanceTrendAnalysisPanel from "@/components/visuals/GuidanceTrendAnalysisPanel";
import GuidanceTrendPanel from "@/components/visuals/GuidanceTrendPanel";
import GuidanceEvolutionReportPanel from "@/components/visuals/GuidanceEvolutionReportPanel";
import { analyzeGuidanceTrends } from "@/lib/guidanceTrendEngine";
import { compareScenarios } from "@/lib/scenarios/multiScenarioComparisonEngine";

interface GoalStrategyDashboardProps {
  flow: any;
  prioritizedGuidance: any[];
}

export default function GoalStrategyDashboard({
  flow,
  prioritizedGuidance
}: GoalStrategyDashboardProps) {
  const goals = flow?.goals ?? [];
  const profile = flow?.userProfile ?? {};
  const feed = Array.isArray(flow?.feed)
    ? flow.feed
    : [];
  const trends = analyzeGuidanceTrends(feed);
  const savedScenarios = Array.isArray(flow?.savedScenarios)
    ? flow.savedScenarios.filter(
        (scenario: any) =>
          Array.isArray(scenario?.curve) &&
          Array.isArray(scenario?.curveSignals)
      )
    : [];
  const signals = Array.isArray(flow?.extraction?.signals)
    ? flow.extraction.signals
    : [];
  const comparisons = compareScenarios(savedScenarios, signals);

  return (
    <div className="flex flex-col gap-10 p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
      <h2 className="text-2xl font-bold text-[#FFD400]">
        Goal Strategy Dashboard
      </h2>

      <GoalStrategyRecommenderPanel goals={goals} profile={profile} />

      <GoalStrategyPlaybookPanel
        goals={goals}
        profile={profile}
        guidance={prioritizedGuidance}
      />

      <GuidanceImpactForecasterPanel
        guidance={prioritizedGuidance}
        goals={goals}
        profile={profile}
      />

      <ProjectionConfidenceBandPanel goals={goals} profile={profile} />

      <ProjectionDistributionSimulatorPanel
        goals={goals}
        profile={profile}
      />

      <ProjectionScenarioOptimizerPanel goals={goals} profile={profile} />

      <MultiScenarioComparisonPanel comparisons={comparisons} />

      <GoalSynergyVisualMapPanel goals={goals} profile={profile} />

      <GoalSynergyOptimizerPanel
        goals={flow.goals ?? []}
        profile={flow.userProfile ?? {}}
      />

      <ProjectionRiskHeatmapPanel goals={goals} profile={profile} />

      <GuidanceTrendAnalysisPanel trends={flow?.trends} />

      <GuidanceTrendPanel trends={trends} />

      <GuidanceEvolutionReportPanel report={flow?.evolutionReport} />

      <GuidanceSystemExplainerPanel />
    </div>
  );
}