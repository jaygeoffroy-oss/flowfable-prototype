"use client";

import React from "react";
import { buildGuidanceSystemTuning } from "@/lib/coaching/guidanceSystemTunerEngine";
import type { GuidanceMetaAnalysis } from "@/lib/coaching/guidanceMetaAnalysis";
import type { GuidanceTrendAnalysis } from "@/lib/guidanceTrendAnalyzer";
import type { GuidanceEvolutionReport } from "@/lib/guidanceEvolutionReport";
import type { GoalStrategy } from "@/lib/goals/goalStrategyEngine";
import type { GoalPlaybookEntry } from "@/lib/goals/goalPlaybookEngine";

interface GuidanceSystemTunerPanelProps {
  meta?: GuidanceMetaAnalysis | null;
  trends?: GuidanceTrendAnalysis | null;
  evolution?: GuidanceEvolutionReport | null;
  strategies?: GoalStrategy[] | null;
  playbooks?: GoalPlaybookEntry[] | null;
}

export default function GuidanceSystemTunerPanel({
  meta,
  trends,
  evolution,
  strategies,
  playbooks
}: GuidanceSystemTunerPanelProps) {
  const tuning = buildGuidanceSystemTuning({
    meta,
    trends,
    evolution,
    strategies,
    playbooks
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance System Tuner
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2">
        <TuningValue label="Risk Sensitivity" value={tuning.riskSensitivity} />
        <TuningValue
          label="Synergy Amplification"
          value={tuning.synergyAmplification}
        />
        <TuningValue
          label="Confidence Smoothing"
          value={tuning.confidenceSmoothing}
        />
        <TuningValue
          label="Category Bias Adjustment"
          value={tuning.categoryBiasAdjustment}
        />
        <TuningValue
          label="Scenario Search Aggression"
          value={tuning.scenarioSearchAggression}
        />
        <TuningValue label="Tone Adjustment" value={tuning.toneAdjustment} />
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Tuning Recommendations
        </p>
        {tuning.recommendations.map((line, index) => (
          <p
            key={`${line}-${index}`}
            className="text-sm text-[#FFD400] leading-relaxed"
          >
            • {line}
          </p>
        ))}
      </div>
    </div>
  );
}

function TuningValue({ label, value }: { label: string; value: string }) {
  return (
    <p className="text-sm text-white">
      • {label}: <span className="text-[#FFD400]">{value}</span>
    </p>
  );
}