"use client";

import React from "react";

interface GoalAlignmentViewProps {
  goal: string;
  incomeTotal: number;
  billsTotal: number;
  transactionTotal: number;
}

export default function GoalAlignmentView({
  goal,
  incomeTotal,
  billsTotal,
  transactionTotal
}: GoalAlignmentViewProps) {
  const monthlyNet = incomeTotal - billsTotal - transactionTotal;

  // Alignment score: 0–100
  const alignmentScore = (() => {
    if (monthlyNet >= 500) return 90;
    if (monthlyNet >= 200) return 70;
    if (monthlyNet >= 0) return 50;
    if (monthlyNet >= -200) return 30;
    return 10;
  })();

  const status =
    alignmentScore >= 75
      ? "Aligned"
      : alignmentScore >= 45
        ? "Partially Aligned"
        : "Off Track";

  const statusColor =
    status === "Aligned"
      ? "#27AE60"
      : status === "Partially Aligned"
        ? "#FF7A00"
        : "#EB5757";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Alignment
      </h3>

      <p className="text-sm text-white">
        Your goal:{" "}
        <span className="font-semibold text-[#FFD400]">{goal}</span>
      </p>

      <div className="flex flex-col gap-2">
        <div className="flex justify-between text-white text-sm">
          <span>Alignment Score</span>
          <span style={{ color: statusColor }}>{alignmentScore}%</span>
        </div>

        <div className="h-3 bg-[#0A1A2F] rounded">
          <div
            className="h-full rounded"
            style={{
              width: `${alignmentScore}%`,
              backgroundColor: statusColor
            }}
          />
        </div>
      </div>

      <p className="text-sm text-white">
        Status:{" "}
        <span style={{ color: statusColor }} className="font-semibold">
          {status}
        </span>
      </p>

      <p className="text-xs text-[#E5E5E5] leading-relaxed">
        {status === "Aligned" &&
          "Your current financial pattern strongly supports your goal. Keep reinforcing the habits that maintain positive net flow."}

        {status === "Partially Aligned" &&
          "You’re moving toward your goal, but your spending pattern is limiting your progress. Small adjustments will create meaningful improvement."}

        {status === "Off Track" &&
          "Your current financial pattern is pulling you away from your goal. Reducing category drift or improving monthly net flow will help you realign."}
      </p>
    </div>
  );
}