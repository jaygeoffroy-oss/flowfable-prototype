"use client";

import React from "react";

interface GoalSpecificRecommendationsProps {
  goal: string;
  monthlyNet: number;
  overspendingPressure: number;
  volatility: number;
  currentSavings: number;
  targetAmount: number;
}

export default function GoalSpecificRecommendations({
  goal,
  monthlyNet,
  overspendingPressure,
  volatility,
  currentSavings,
  targetAmount
}: GoalSpecificRecommendationsProps) {
  const recs: string[] = [];
  const normalizedGoal = goal.toLowerCase();

  const isEmergencyFund =
    normalizedGoal.includes("emergency") ||
    normalizedGoal.includes("buffer") ||
    normalizedGoal.includes("safety");
  const isDebtPayoff =
    normalizedGoal.includes("debt") ||
    normalizedGoal.includes("loan") ||
    normalizedGoal.includes("credit");
  const progressPercent =
    targetAmount > 0
      ? Math.min(100, Math.max(0, (currentSavings / targetAmount) * 100))
      : 0;

  if (monthlyNet <= 0) {
    recs.push(
      "Prioritize restoring positive monthly net flow before increasing contributions toward this goal."
    );
  } else if (monthlyNet < 200) {
    recs.push(
      "Your available monthly margin is modest. Start with a contribution you can repeat consistently and increase it gradually."
    );
  } else {
    recs.push(
      "Your positive monthly margin gives you room to make steady progress. Automate a contribution on each income cycle."
    );
  }

  if (isEmergencyFund) {
    recs.push(
      "For an emergency fund, keep contributions accessible and prioritize a dependable cash reserve over higher-risk growth."
    );
    if (progressPercent < 50) {
      recs.push(
        "Build the first portion of your safety buffer quickly, then expand it toward the full target as your margin allows."
      );
    }
  } else if (isDebtPayoff) {
    recs.push(
      "Direct additional margin toward the highest-cost debt first while keeping minimum payments current on every account."
    );
    if (overspendingPressure > 40) {
      recs.push(
        "Review discretionary spending for a repeatable debt payment increase rather than relying on one-time cuts."
      );
    }
  } else {
    recs.push(
      "Separate this goal contribution from everyday spending so progress stays visible and protected."
    );
  }

  if (overspendingPressure > 60) {
    recs.push(
      "Your spending pressure is high. Choose one high-impact category to reduce before committing to a larger goal contribution."
    );
  } else if (overspendingPressure > 40) {
    recs.push(
      "Your spending is manageable but elevated. A small recurring reduction can meaningfully improve goal progress."
    );
  }

  if (volatility > 60) {
    recs.push(
      "Because spending varies significantly month to month, set aside part of your surplus as a flexible buffer."
    );
  } else if (volatility > 30) {
    recs.push(
      "Track the months with higher spending so your goal contributions can remain realistic and consistent."
    );
  }

  if (targetAmount <= 0) {
    recs.push(
      "Add a target amount to turn this goal into a measurable milestone forecast."
    );
  } else if (progressPercent >= 100) {
    recs.push(
      "You have reached the target amount. Review whether to preserve the balance or define the next milestone."
    );
  } else if (progressPercent >= 75) {
    recs.push(
      "You are close to the target. Protect the progress you have made and avoid drawing from this balance for routine spending."
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Goal-Specific Recommendations
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Practical guidance for your goal:{" "}
          <span className="font-semibold text-[#FFD400]">
            {goal || "No goal set"}
          </span>
        </p>
      </div>

      <ul className="flex flex-col gap-4">
        {recs.map((recommendation, index) => (
          <li
            key={`${recommendation}-${index}`}
            className="flex gap-3 text-sm text-white leading-relaxed"
          >
            <span className="text-[#FF7A00] shrink-0" aria-hidden="true">
              •
            </span>
            <span>{recommendation}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}