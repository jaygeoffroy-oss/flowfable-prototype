"use client";

import React from "react";
import { assessEngineHealth } from "@/lib/coaching/engineHealthMonitorEngine";

interface EngineHealthMonitorPanelProps {
  flow: any;
}

export default function EngineHealthMonitorPanel({
  flow
}: EngineHealthMonitorPanelProps) {
  const health = assessEngineHealth(flow);

  const color =
    health.status === "healthy"
      ? "#27AE60"
      : health.status === "warning"
        ? "#F2C94C"
        : "#EB5757";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Engine Health Monitor
      </h3>

      <p className="text-sm text-white">
        • Status: <span style={{ color }}>{health.status}</span>
      </p>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">Issues</p>
        {health.issues.length === 0 ? (
          <p className="text-sm text-[#27AE60]">• No issues detected.</p>
        ) : (
          health.issues.map((issue, index) => (
            <p key={`${issue}-${index}`} className="text-sm text-[#FFD400]">
              • {issue}
            </p>
          ))
        )}
      </div>
    </div>
  );
}