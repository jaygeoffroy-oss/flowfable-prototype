"use client";

import React from "react";

interface GoalMilestoneForecastingProps {
  goal: string;
  targetAmount: number;
  currentSavings: number;
  monthlyNet: number;
}

export default function GoalMilestoneForecasting({
  goal,
  targetAmount,
  currentSavings,
  monthlyNet
}: GoalMilestoneForecastingProps) {
  const remaining = Math.max(0, targetAmount - currentSavings);

  let monthsToGoal: number | null = null;

  if (monthlyNet > 0) {
    monthsToGoal = Math.ceil(remaining / monthlyNet);
  }

  const status =
    monthlyNet <= 0
      ? "Off Track"
      : monthsToGoal !== null && monthsToGoal <= 6
        ? "On Track"
        : monthsToGoal !== null && monthsToGoal <= 18
          ? "Moderate Progress"
          : "Long-Term Horizon";

  const statusColor =
    status === "On Track"
      ? "#27AE60"
      : status === "Moderate Progress"
        ? "#FF7A00"
        : status === "Long-Term Horizon"
          ? "#2F80ED"
          : "#EB5757";

  const progress =
    targetAmount > 0
      ? Math.min(100, Math.max(0, (currentSavings / targetAmount) * 100))
      : 0;

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Milestone Forecasting
      </h3>

      <p className="text-sm text-white">
        Goal:{" "}
        <span className="font-semibold text-[#FFD400]">
          {goal || "No goal set"}
        </span>
      </p>

      <p className="text-sm text-white">
        Target Amount:{" "}
        <span className="font-semibold text-[#FFD400]">
          ${targetAmount.toFixed(2)}
        </span>
      </p>

      <p className="text-sm text-white">
        Current Savings:{" "}
        <span className="font-semibold text-[#FFD400]">
          ${currentSavings.toFixed(2)}
        </span>
      </p>

      <p className="text-sm text-white">
        Monthly Net Flow:{" "}
        <span className="font-semibold text-[#FFD400]">
          ${monthlyNet.toFixed(2)}
        </span>
      </p>

      <div className="flex justify-between text-white text-sm">
        <span>Estimated Time to Goal</span>
        <span style={{ color: statusColor }} className="font-semibold">
          {monthlyNet <= 0
            ? "Not Achievable with Current Pattern"
            : monthsToGoal === 0
              ? "Goal Reached"
              : `${monthsToGoal} months`}
        </span>
      </div>

      <div
        className="h-3 bg-[#0A1A2F] rounded"
        role="progressbar"
        aria-label="Goal savings progress"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={Number(progress.toFixed(0))}
      >
        <div
          className="h-full rounded transition-all"
          style={{
            width: `${progress}%`,
            backgroundColor: statusColor
          }}
        />
      </div>

      <p className="text-sm text-white">
        Status:{" "}
        <span style={{ color: statusColor }} className="font-semibold">
          {status}
        </span>
      </p>
    </div>
  );
}