"use client";

import React, { useState } from "react";
import { computeProjectionRisk } from "@/lib/projectionRiskEngine";
import type { FinancialSignal } from "@/lib/extraction";
import { projectGoal } from "@/lib/goals/projectionEngine";
import { scoreProjectionRisk } from "@/lib/goals/projectionRiskEngine";
import ProjectionRiskHeatmap from "./ProjectionRiskHeatmap";

interface ProjectionRiskHeatmapPanelProps {
  goals: any[];
  profile: any;
  signals?: FinancialSignal[];
}

function normalizeCadence(cadence: string | undefined) {
  return cadence === "Weekly" || cadence === "Biweekly" ? cadence : "Monthly";
}

export default function ProjectionRiskHeatmapPanel({
  goals,
  profile,
  signals
}: ProjectionRiskHeatmapPanelProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to view risk heatmaps.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Risk Heatmap
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min={1}
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => {
            const nextMonths = Number(event.target.value);
            setMonths(
              Number.isFinite(nextMonths) ? Math.max(1, nextMonths) : 1
            );
          }}
        />
      </label>

      {goals.map(goal => {
        const curve = projectGoal({
          currentSavings: goal.currentSavings,
          monthlyContribution: goal.monthlyNet,
          annualGrowthRate: goal.annualGrowthRate ?? 0,
          months,
          cadence: normalizeCadence(profile?.incomeCadence)
        });

        if (signals) {
          const riskPoints = computeProjectionRisk(curve, signals);

          return (
            <ProjectionRiskHeatmap
              key={goal.id}
              riskPoints={riskPoints}
            />
          );
        }

        const riskData = scoreProjectionRisk(curve, profile ?? {}, goal);

        return (
          <ProjectionRiskHeatmap
            key={goal.id}
            data={riskData}
            goalName={goal.name}
          />
        );
      })}
    </div>
  );
}