"use client";

import React from "react";
import type { GuidanceTrend } from "@/lib/guidanceHistoryTrendAnalyzer";

interface GuidanceTrendPanelProps {
  trends: GuidanceTrend[];
}

export default function GuidanceTrendPanel({
  trends
}: GuidanceTrendPanelProps) {
  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Trend Analysis
      </h3>

      {trends.length === 0 ? (
        <p className="text-sm text-white">
          No guidance trend data available.
        </p>
      ) : (
        trends.map((trend, index) => (
          <div
            key={`${trend.label}-${index}`}
            className="flex flex-col gap-1 text-white"
          >
            <p className="text-sm">{trend.label}</p>

            <p className="text-sm">
              Direction:{" "}
              <span
                style={{
                  color:
                    trend.direction === "Improving"
                      ? "#27AE60"
                      : trend.direction === "Worsening"
                        ? "#EB5757"
                        : "#FFD400"
                }}
              >
                {trend.direction}
              </span>
            </p>

            <p className="text-xs opacity-80">
              Score change: {trend.scoreDelta} — Confidence change:{" "}
              {trend.confidenceDelta}
            </p>
          </div>
        ))
      )}
    </div>
  );
}