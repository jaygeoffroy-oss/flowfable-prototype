"use client";

import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface ProjectionStressTestPoint {
  month: number;
  baseline: number;
  worst: number;
  best: number;
}

interface ProjectionStressTestChartProps {
  data: ProjectionStressTestPoint[];
  goalName: string;
}

export default function ProjectionStressTestChart({
  data,
  goalName
}: ProjectionStressTestChartProps) {
  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Stress Test
      </p>

      {data.length === 0 ? (
        <p className="text-xs text-white opacity-70">
          No stress-test data available.
        </p>
      ) : (
        <div style={{ width: "100%", height: 250 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <XAxis
                dataKey="month"
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <YAxis
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0F0F0F",
                  border: "1px solid #3A4F7A",
                  color: "#FFD400"
                }}
              />

              <Line
                type="monotone"
                dataKey="baseline"
                stroke="#FFD400"
                strokeWidth={2}
                dot={false}
                name="Baseline"
              />
              <Line
                type="monotone"
                dataKey="worst"
                stroke="#EB5757"
                strokeWidth={2}
                dot={false}
                name="Worst-Case"
              />
              <Line
                type="monotone"
                dataKey="best"
                stroke="#27AE60"
                strokeWidth={2}
                dot={false}
                name="Best-Case"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <p className="text-xs text-white opacity-70 mt-2">
        Gold = Baseline, Red = Worst-Case, Green = Best-Case
      </p>
    </div>
  );
}