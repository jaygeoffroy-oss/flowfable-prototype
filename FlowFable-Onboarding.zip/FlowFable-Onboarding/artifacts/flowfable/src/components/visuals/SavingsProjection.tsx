"use client";

import React from "react";

interface SavingsProjectionProps {
  incomeTotal: number;
  billsTotal: number;
  transactionTotal: number;
}

export default function SavingsProjection({
  incomeTotal,
  billsTotal,
  transactionTotal
}: SavingsProjectionProps) {
  const monthlyNet = incomeTotal - billsTotal - transactionTotal;

  const projections = [
    { label: "3 Months", value: monthlyNet * 3 },
    { label: "6 Months", value: monthlyNet * 6 },
    { label: "12 Months", value: monthlyNet * 12 }
  ];

  const maxValue = Math.max(
    ...projections.map(projection => Math.abs(projection.value)),
    1
  );

  function barWidth(value: number) {
    return `${(Math.abs(value) / maxValue) * 100}%`;
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Savings Projection
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Based on your current monthly net flow of ${monthlyNet.toFixed(2)}.
        </p>
      </div>

      <div className="flex flex-col gap-4">
        {projections.map(projection => {
          const isPositive = projection.value >= 0;

          return (
            <div key={projection.label} className="flex flex-col gap-2">
              <div className="flex justify-between text-sm text-white">
                <span>{projection.label}</span>
                <span className={isPositive ? "text-[#27AE60]" : "text-[#EB5757]"}>
                  {isPositive ? "+" : "-"}$
                  {Math.abs(projection.value).toFixed(2)}
                </span>
              </div>

              <div className="h-3 bg-[#0A1A2F] rounded">
                <div
                  className="h-full rounded transition-all"
                  style={{
                    width: barWidth(projection.value),
                    backgroundColor: isPositive ? "#27AE60" : "#EB5757"
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}