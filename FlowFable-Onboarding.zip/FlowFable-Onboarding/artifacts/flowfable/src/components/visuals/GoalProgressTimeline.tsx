"use client";

import React from "react";

interface GoalProgressTimelineProps {
  goal: string;
  monthlyTotals: Record<string, number>;
  incomeTotal: number;
  billsTotal: number;
}

export default function GoalProgressTimeline({
  goal,
  monthlyTotals,
  incomeTotal,
  billsTotal
}: GoalProgressTimelineProps) {
  const months = Object.keys(monthlyTotals).sort(
    (a, b) => new Date(a).getTime() - new Date(b).getTime()
  );

  if (months.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">No monthly data available.</p>
      </div>
    );
  }

  const monthlyAlignment = months.map(month => {
    const spending = monthlyTotals[month];
    const net = incomeTotal - billsTotal - spending;

    const score =
      net >= 500
        ? 90
        : net >= 200
          ? 70
          : net >= 0
            ? 50
            : net >= -200
              ? 30
              : 10;

    return { month, score };
  });

  const maxScore = 100;

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6 overflow-x-auto">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Progress Timeline
      </h3>

      <p className="text-sm text-white">
        Tracking alignment with your goal:{" "}
        <span className="font-semibold text-[#FFD400]">{goal}</span>
      </p>

      <div className="flex items-end gap-6 h-40">
        {monthlyAlignment.map(({ month, score }) => {
          const color =
            score >= 75 ? "#27AE60" : score >= 45 ? "#FF7A00" : "#EB5757";

          return (
            <div key={month} className="flex flex-col items-center gap-2">
              <div
                className="w-6 rounded"
                style={{
                  height: `${(score / maxScore) * 100}%`,
                  backgroundColor: color
                }}
                title={`${month}: ${score}% alignment`}
              />
              <p className="text-xs text-white">{month}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}