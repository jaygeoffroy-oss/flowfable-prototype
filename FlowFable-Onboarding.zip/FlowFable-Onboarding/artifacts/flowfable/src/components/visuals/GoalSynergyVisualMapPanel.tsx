"use client";

import React from "react";
import { buildSynergyGraph } from "@/lib/goals/synergyGraphEngine";
import GoalSynergyVisualMap from "./GoalSynergyVisualMap";

interface GoalSynergyVisualMapPanelProps {
  goals: any[];
  profile: any;
}

export default function GoalSynergyVisualMapPanel({
  goals,
  profile
}: GoalSynergyVisualMapPanelProps) {
  if (!goals || goals.length < 2) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add at least two goals to visualize synergies.
        </p>
      </div>
    );
  }

  const graph = buildSynergyGraph(goals, profile);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Synergy Visual Map
      </h3>

      <GoalSynergyVisualMap graph={graph} />
    </div>
  );
}