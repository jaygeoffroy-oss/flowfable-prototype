"use client";

import React from "react";
import {
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface ProjectionDistributionPercentile {
  month: number;
  p10: number;
  p50: number;
  p90: number;
}

interface ProjectionDistributionChartProps {
  percentiles: ProjectionDistributionPercentile[];
  goalName: string;
}

export default function ProjectionDistributionChart({
  percentiles,
  goalName
}: ProjectionDistributionChartProps) {
  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Distribution Simulation
      </p>

      {percentiles.length === 0 ? (
        <p className="text-xs text-white opacity-70">
          No distribution data available.
        </p>
      ) : (
        <div style={{ width: "100%", height: 260 }}>
          <ResponsiveContainer>
            <AreaChart data={percentiles}>
              <XAxis
                dataKey="month"
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <YAxis
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0F0F0F",
                  border: "1px solid #3A4F7A",
                  color: "#FFD400"
                }}
              />

              <Area
                type="monotone"
                dataKey="p10"
                stroke="#EB5757"
                fill="#EB5757"
                fillOpacity={0.2}
                name="10th Percentile"
              />
              <Area
                type="monotone"
                dataKey="p90"
                stroke="#27AE60"
                fill="#27AE60"
                fillOpacity={0.2}
                name="90th Percentile"
              />
              <Line
                type="monotone"
                dataKey="p50"
                stroke="#FFD400"
                strokeWidth={2}
                dot={false}
                name="Median"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      <p className="text-xs text-white opacity-70 mt-2">
        Gold = Median, Green = 90th Percentile, Red = 10th Percentile
      </p>
    </div>
  );
}