"use client";

import React from "react";
import type { ScenarioRecord } from "@/lib/goalProgress";

interface ScenarioHistoryPanelProps {
  history: ScenarioRecord[];
}

export default function ScenarioHistoryPanel({
  history
}: ScenarioHistoryPanelProps) {
  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Scenario History
      </h3>

      {history.length === 0 ? (
        <p className="text-sm text-white">No scenarios saved yet.</p>
      ) : (
        history.map(record => (
          <div
            key={record.id}
            className="flex flex-col gap-2 p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]"
          >
            <p className="text-sm text-white font-semibold">
              {record.goalName}
            </p>

            <p className="text-sm text-white">
              • Saved: {new Date(record.timestamp).toLocaleString()}
            </p>

            <p className="text-sm text-white">
              • Contribution Change: ${record.change}
            </p>

            <p className="text-sm text-white">
              • Pause: {record.pause} months
            </p>

            <p className="text-sm text-white">
              • New Monthly Net: ${record.newMonthlyNet}
            </p>

            <p className="text-sm text-white">
              • New Time Horizon:{" "}
              {record.monthsToGoal === null
                ? "Not Achievable"
                : `${record.monthsToGoal} months`}
            </p>
          </div>
        ))
      )}
    </div>
  );
}