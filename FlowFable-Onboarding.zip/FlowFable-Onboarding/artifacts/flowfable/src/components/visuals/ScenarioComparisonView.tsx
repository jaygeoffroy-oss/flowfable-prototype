"use client";

import React, { useState } from "react";
import type { ScenarioRecord } from "@/lib/goalProgress";

interface ScenarioComparisonViewProps {
  history: ScenarioRecord[];
}

export default function ScenarioComparisonView({
  history
}: ScenarioComparisonViewProps) {
  const [leftId, setLeftId] = useState<number | null>(null);
  const [rightId, setRightId] = useState<number | null>(null);

  const left = history.find(record => record.id === leftId);
  const right = history.find(record => record.id === rightId);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Scenario Comparison
      </h3>

      {history.length < 2 ? (
        <p className="text-sm text-white">
          Save at least two scenarios to compare.
        </p>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="flex flex-col gap-1 text-white text-sm">
              Scenario A
              <select
                className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white text-sm"
                value={leftId ?? ""}
                onChange={event =>
                  setLeftId(
                    event.target.value === ""
                      ? null
                      : Number(event.target.value)
                  )
                }
              >
                <option value="">Select Scenario A</option>
                {history.map(record => (
                  <option key={record.id} value={record.id}>
                    {record.goalName} —{" "}
                    {new Date(record.timestamp).toLocaleString()}
                  </option>
                ))}
              </select>
            </label>

            <label className="flex flex-col gap-1 text-white text-sm">
              Scenario B
              <select
                className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white text-sm"
                value={rightId ?? ""}
                onChange={event =>
                  setRightId(
                    event.target.value === ""
                      ? null
                      : Number(event.target.value)
                  )
                }
              >
                <option value="">Select Scenario B</option>
                {history.map(record => (
                  <option key={record.id} value={record.id}>
                    {record.goalName} —{" "}
                    {new Date(record.timestamp).toLocaleString()}
                  </option>
                ))}
              </select>
            </label>
          </div>

          {left && right && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {[{ label: "Scenario A", record: left }, { label: "Scenario B", record: right }].map(
                scenario => (
                  <div
                    key={scenario.label}
                    className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2"
                  >
                    <p className="text-sm text-white font-semibold">
                      {scenario.label}
                    </p>
                    <p className="text-sm text-white">
                      • Goal: {scenario.record.goalName}
                    </p>
                    <p className="text-sm text-white">
                      • Change: ${scenario.record.change}
                    </p>
                    <p className="text-sm text-white">
                      • Pause: {scenario.record.pause} months
                    </p>
                    <p className="text-sm text-white">
                      • New Monthly Net: ${scenario.record.newMonthlyNet}
                    </p>
                    <p className="text-sm text-white">
                      • Time Horizon:{" "}
                      {scenario.record.monthsToGoal === null
                        ? "Not Achievable"
                        : `${scenario.record.monthsToGoal} months`}
                    </p>
                  </div>
                )
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}