"use client";

import React from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

interface SpendingChartsProps {
  transactions: Array<{
    name: string;
    amount: number;
    category: string;
    date: string;
  }>;
}

export default function SpendingCharts({
  transactions
}: SpendingChartsProps) {
  if (!transactions || transactions.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">No transactions yet.</p>
      </div>
    );
  }

  const categoryTotals: Record<string, number> = {};

  transactions.forEach(t => {
    categoryTotals[t.category] =
      (categoryTotals[t.category] ?? 0) + t.amount;
  });

  const categoryData = Object.entries(categoryTotals)
    .map(([category, amount]) => ({ category, amount }))
    .sort((a, b) => b.amount - a.amount);

  const recentTransactions = [...transactions]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 8)
    .reverse()
    .map(transaction => ({
      date: transaction.date,
      amount: transaction.amount,
      name: transaction.name
    }));

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-8">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Spending Overview
      </h3>

      <div className="flex flex-col gap-3">
        <h4 className="text-sm font-medium text-white">
          Spending by Category
        </h4>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={categoryData} margin={{ top: 8, right: 8, left: 0, bottom: 8 }}>
              <CartesianGrid stroke="#3A4F7A" strokeDasharray="3 3" />
              <XAxis
                dataKey="category"
                tick={{ fill: "#E5E5E5", fontSize: 12 }}
                axisLine={{ stroke: "#3A4F7A" }}
              />
              <YAxis
                tick={{ fill: "#E5E5E5", fontSize: 12 }}
                axisLine={{ stroke: "#3A4F7A" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0A1A2F",
                  border: "1px solid #3A4F7A",
                  color: "#FFFFFF"
                }}
                formatter={(value: number) => [value.toFixed(2), "Amount"]}
              />
              <Bar dataKey="amount" fill="#9B51E0" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <h4 className="text-sm font-medium text-white">
          Recent Transactions
        </h4>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={recentTransactions} margin={{ top: 8, right: 8, left: 0, bottom: 8 }}>
              <CartesianGrid stroke="#3A4F7A" strokeDasharray="3 3" />
              <XAxis
                dataKey="date"
                tick={{ fill: "#E5E5E5", fontSize: 11 }}
                axisLine={{ stroke: "#3A4F7A" }}
              />
              <YAxis
                tick={{ fill: "#E5E5E5", fontSize: 12 }}
                axisLine={{ stroke: "#3A4F7A" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0A1A2F",
                  border: "1px solid #3A4F7A",
                  color: "#FFFFFF"
                }}
                formatter={(value: number) => [value.toFixed(2), "Amount"]}
                labelFormatter={(_, payload) =>
                  payload?.[0]?.payload?.name ?? ""
                }
              />
              <Bar dataKey="amount" fill="#FF7A00" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}