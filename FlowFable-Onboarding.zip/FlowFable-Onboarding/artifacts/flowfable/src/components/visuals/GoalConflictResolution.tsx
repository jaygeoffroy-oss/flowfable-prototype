"use client";

import React from "react";

interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentSavings: number;
  monthlyNet: number;
}

interface GoalConflictResolutionProps {
  goals: Goal[];
  interdependencies: string[];
}

export default function GoalConflictResolution({
  goals,
  interdependencies
}: GoalConflictResolutionProps) {
  if (!goals || goals.length < 2) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add at least two goals to unlock conflict resolution.
        </p>
      </div>
    );
  }

  const resolutions: string[] = [];

  for (let i = 0; i < goals.length; i += 1) {
    for (let j = i + 1; j < goals.length; j += 1) {
      const a = goals[i];
      const b = goals[j];
      const aRemaining = Math.max(0, a.targetAmount - a.currentSavings);
      const bRemaining = Math.max(0, b.targetAmount - b.currentSavings);
      const aMonths =
        a.monthlyNet > 0 ? Math.ceil(aRemaining / a.monthlyNet) : null;
      const bMonths =
        b.monthlyNet > 0 ? Math.ceil(bRemaining / b.monthlyNet) : null;

      if (a.monthlyNet > 0 && b.monthlyNet > 0) {
        const firstPriority =
          aMonths === null || (bMonths !== null && bMonths < aMonths) ? b : a;
        resolutions.push(
          `Prioritize ${firstPriority.name} as the next milestone, then redirect that contribution toward the other goal once it is reached.`
        );
      } else if (a.monthlyNet <= 0 || b.monthlyNet <= 0) {
        const stalled = a.monthlyNet <= 0 ? a : b;
        resolutions.push(
          `Stabilize ${stalled.name} before increasing contributions across both goals by restoring positive monthly net flow.`
        );
      }

      if (
        aMonths !== null &&
        bMonths !== null &&
        Math.abs(aMonths - bMonths) > 12
      ) {
        const longTerm = aMonths > bMonths ? a : b;
        resolutions.push(
          `Protect ${longTerm.name} with a minimum recurring contribution so the longer-term goal does not get crowded out by shorter milestones.`
        );
      }
    }
  }

  const uniqueResolutions = Array.from(new Set(resolutions));

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Goal Conflict Resolution
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Practical ways to balance competing goal timelines.
        </p>
      </div>

      <div className="flex flex-col gap-4">
        {uniqueResolutions.length === 0 ? (
          <p className="text-sm text-white">
            No major goal conflicts detected.
          </p>
        ) : (
          uniqueResolutions.map((resolution, index) => (
            <p
              key={`${resolution}-${index}`}
              className="text-sm text-white leading-relaxed"
            >
              <span className="text-[#FF7A00] mr-2" aria-hidden="true">
                •
              </span>
              {resolution}
            </p>
          ))
        )}
      </div>

      {interdependencies.length > 0 && (
        <div className="border-t border-[#3A4F7A] pt-4">
          <p className="text-xs text-[#E5E5E5]">
            These recommendations account for {interdependencies.length}{" "}
            detected interdependenc
            {interdependencies.length === 1 ? "y" : "ies"}.
          </p>
        </div>
      )}
    </div>
  );
}