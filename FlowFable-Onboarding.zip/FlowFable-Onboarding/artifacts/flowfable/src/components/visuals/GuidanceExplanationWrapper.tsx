"use client";

import React, { useState } from "react";
import { explainGuidance } from "@/lib/coaching/guidanceExplanationEngine";
import { confidenceScore } from "@/lib/coaching/guidanceConfidenceEngine";
import { applyPersonalizationRules } from "@/lib/coaching/personalizationRules";
import { applyCoachingVoice } from "@/lib/coaching/voiceEngine";
import GuidanceExplanationTooltip from "./GuidanceExplanationTooltip";

interface GuidanceExplanationWrapperProps {
  profile: any;
  style: string;
  guidance: { text: string; context?: any }[];
}

export default function GuidanceExplanationWrapper({
  profile,
  style,
  guidance
}: GuidanceExplanationWrapperProps) {
  const [hovered, setHovered] = useState<number | null>(null);

  const scored = guidance.map((item, index) => ({
    ...item,
    index,
    confidence: confidenceScore(profile, item.text, item.context),
    reasons: explainGuidance(profile, item.text, item.context)
  }));

  return (
    <div className="flex flex-col gap-4 relative">
      {scored.map(item => {
        const personalized = applyPersonalizationRules(profile, item.text);
        const voiced = applyCoachingVoice(style, personalized);

        return (
          <div
            key={`${item.text}-${item.index}`}
            className="relative"
            onMouseEnter={() => setHovered(item.index)}
            onMouseLeave={() => setHovered(null)}
          >
            <p className="text-sm text-white leading-relaxed">
              • {voiced}{" "}
              <span className="text-[#FFD400]">
                ({item.confidence}% confidence)
              </span>
            </p>

            {hovered === item.index && (
              <GuidanceExplanationTooltip reasons={item.reasons} />
            )}
          </div>
        );
      })}
    </div>
  );
}