"use client";

import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend
} from "recharts";
import type { EngineParameterTimelinePoint } from "@/lib/coaching/engineParameterTimeline";

interface EngineParameterTimelineChartProps {
  data: EngineParameterTimelinePoint[];
}

export default function EngineParameterTimelineChart({
  data
}: EngineParameterTimelineChartProps) {
  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        Engine Parameter Timeline
      </p>

      <div style={{ width: "100%", height: 300 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <XAxis
              dataKey="timestamp"
              stroke="#FFD400"
              tick={{ fill: "#FFD400" }}
            />
            <YAxis stroke="#FFD400" tick={{ fill: "#FFD400" }} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0F0F0F",
                border: "1px solid #3A4F7A",
                color: "#FFD400"
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="riskWeight"
              stroke="#EB5757"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="synergyWeight"
              stroke="#27AE60"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="confidenceSmoothing"
              stroke="#56CCF2"
              strokeWidth={2}
              dot={false}
            />
            <Line
              type="monotone"
              dataKey="scenarioAggression"
              stroke="#F2C94C"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <p className="text-xs text-white opacity-70 mt-2">
        Tracks parameter evolution across system runs.
      </p>
    </div>
  );
}