"use client";

import React from "react";

interface TrendGraphsProps {
  transactions: Array<{
    name: string;
    amount: number;
    category: string;
    date: string;
  }>;
}

export default function TrendGraphs({ transactions }: TrendGraphsProps) {
  if (!transactions || transactions.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">No transactions yet.</p>
      </div>
    );
  }

  const monthlyTotals: Record<string, number> = {};

  transactions.forEach(t => {
    const month = new Date(t.date).toLocaleString("en-CA", {
      month: "short",
      year: "numeric"
    });

    monthlyTotals[month] = (monthlyTotals[month] ?? 0) + t.amount;
  });

  const months = Object.keys(monthlyTotals).sort(
    (a, b) => new Date(a).getTime() - new Date(b).getTime()
  );

  const maxValue = Math.max(...Object.values(monthlyTotals), 1);

  function barHeight(value: number) {
    return `${(value / maxValue) * 100}%`;
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Spending Trends
      </h3>

      <div className="flex items-end gap-4 h-64 overflow-x-auto border-b border-[#3A4F7A] px-2">
        {months.map(month => {
          const total = monthlyTotals[month];

          return (
            <div
              key={month}
              className="min-w-20 h-full flex flex-col items-center justify-end gap-2"
            >
              <span className="text-xs text-white">
                ${total.toFixed(2)}
              </span>
              <div className="w-12 h-48 flex items-end">
                <div
                  className="w-full bg-[#9B51E0] rounded-t"
                  style={{ height: barHeight(total) }}
                  title={`${month}: $${total.toFixed(2)}`}
                />
              </div>
              <span className="text-xs text-[#E5E5E5] whitespace-nowrap">
                {month}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}