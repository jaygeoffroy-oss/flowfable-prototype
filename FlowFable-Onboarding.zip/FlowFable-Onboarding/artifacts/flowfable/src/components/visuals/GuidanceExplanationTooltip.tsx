"use client";

import React from "react";

interface GuidanceExplanationTooltipProps {
  reasons: string[];
}

export default function GuidanceExplanationTooltip({
  reasons
}: GuidanceExplanationTooltipProps) {
  if (!reasons || reasons.length === 0) {
    return null;
  }

  return (
    <div className="absolute right-0 top-0 mt-1 mr-1 p-3 bg-[#0F0F0F] border border-[#3A4F7A] rounded shadow-lg w-64 z-50">
      <p className="text-[#FFD400] text-sm font-semibold mb-2">
        Why this guidance?
      </p>
      {reasons.map((reason, index) => (
        <p
          key={`${reason}-${index}`}
          className="text-white text-xs leading-relaxed"
        >
          • {reason}
        </p>
      ))}
    </div>
  );
}