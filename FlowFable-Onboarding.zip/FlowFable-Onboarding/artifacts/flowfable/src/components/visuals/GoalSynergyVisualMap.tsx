"use client";

import React from "react";
import type {
  SynergyGraph,
  SynergyGraphNode
} from "@/lib/goals/synergyGraph";

interface GoalSynergyVisualMapProps {
  graph: SynergyGraph;
}

interface PositionedNode extends SynergyGraphNode {
  x: number;
  y: number;
}

function getNodeColor(urgency: number) {
  if (urgency < 6) return "#EB5757";
  if (urgency < 18) return "#F2C94C";
  return "#27AE60";
}

function getEdgeColor(synergy: number) {
  if (synergy > 70) return "#27AE60";
  if (synergy > 40) return "#F2C94C";
  return "#EB5757";
}

function getNodeRadius(size: number) {
  return Math.min(28, Math.max(10, size));
}

export default function GoalSynergyVisualMap({
  graph
}: GoalSynergyVisualMapProps) {
  const width = 640;
  const height = 360;
  const centerX = width / 2;
  const centerY = height / 2;
  const radius = Math.min(130, Math.max(70, graph.nodes.length * 18));

  const positionedNodes: PositionedNode[] = graph.nodes.map((node, index) => {
    const angle =
      graph.nodes.length === 1
        ? 0
        : (index / graph.nodes.length) * Math.PI * 2 - Math.PI / 2;

    return {
      ...node,
      x: centerX + Math.cos(angle) * radius,
      y: centerY + Math.sin(angle) * radius
    };
  });

  const nodesById = new Map(
    positionedNodes.map(node => [node.id, node])
  );

  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        Goal Synergy Visual Map
      </p>

      {positionedNodes.length === 0 ? (
        <p className="text-sm text-white">
          Add goals to visualize their synergies.
        </p>
      ) : (
        <div className="w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${width} ${height}`}
            className="w-full min-w-[520px]"
            role="img"
            aria-label="Goal synergy visual map"
          >
            {graph.edges.map(edge => {
              const source = nodesById.get(edge.source);
              const target = nodesById.get(edge.target);
              if (!source || !target) return null;

              return (
                <line
                  key={`${edge.source}-${edge.target}`}
                  x1={source.x}
                  y1={source.y}
                  x2={target.x}
                  y2={target.y}
                  stroke={getEdgeColor(edge.synergy)}
                  strokeWidth={Math.max(1, edge.synergy / 20)}
                  strokeOpacity={0.8}
                />
              );
            })}

            {positionedNodes.map(node => (
              <g key={node.id}>
                <title>
                  {node.name} — Urgency: {node.urgency} months
                </title>
                <circle
                  cx={node.x}
                  cy={node.y}
                  r={getNodeRadius(node.size)}
                  fill={getNodeColor(node.urgency)}
                  stroke="#E5E5E5"
                  strokeWidth={1}
                />
                <text
                  x={node.x}
                  y={node.y + getNodeRadius(node.size) + 16}
                  textAnchor="middle"
                  fill="#FFFFFF"
                  fontSize="12"
                >
                  {node.name}
                </text>
              </g>
            ))}
          </svg>
        </div>
      )}

      <p className="text-xs text-white opacity-70 mt-2">
        Nodes: green = long-term, yellow = medium urgency, red = urgent.
        Edges: green = strong synergy, yellow = moderate, red = weak.
      </p>
    </div>
  );
}