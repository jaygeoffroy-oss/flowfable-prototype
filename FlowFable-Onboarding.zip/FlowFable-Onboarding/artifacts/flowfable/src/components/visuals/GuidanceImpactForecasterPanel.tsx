"use client";

import React from "react";
import { computeGuidanceImpact } from "@/lib/coaching/guidanceImpactEngine";

interface GuidanceImpactItem {
  text: string;
  context?: {
    change?: number;
  };
}

interface GuidanceImpactForecasterPanelProps {
  guidance: GuidanceImpactItem[];
  goals: any[];
  profile: any;
}

export default function GuidanceImpactForecasterPanel({
  guidance,
  goals,
  profile
}: GuidanceImpactForecasterPanelProps) {
  if (!guidance || guidance.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-sm text-white">
          No guidance available to forecast impact.
        </p>
      </div>
    );
  }

  const first = guidance[0];
  const impacts = computeGuidanceImpact(first, goals, profile ?? {});

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Impact Forecaster
      </h3>

      <p className="text-sm text-white">
        Forecasting impact of:{" "}
        <span className="text-[#FFD400]">{first.text}</span>
      </p>

      {impacts.map((impact, index) => (
        <div
          key={`${impact.goalName}-${index}`}
          className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2"
        >
          <p className="text-sm text-white font-semibold">
            {impact.goalName}
          </p>

          <p className="text-sm text-white">
            • Timeline Impact:{" "}
            <span className="text-[#FFD400]">
              {impact.timelineImpact > 0
                ? `+${impact.timelineImpact.toFixed(2)} CAD`
                : `${impact.timelineImpact.toFixed(2)} CAD`}
            </span>
          </p>

          <p className="text-sm text-white">
            • Risk Impact:{" "}
            <span className="text-[#FFD400]">
              {impact.riskImpact.toFixed(2)}%
            </span>
          </p>

          <p className="text-sm text-white font-semibold mt-2">
            Synergy Impact:
          </p>

          {impact.synergyImpact.length === 0 ? (
            <p className="text-sm text-white">No comparison goals.</p>
          ) : (
            impact.synergyImpact.map((synergy, synergyIndex) => {
              const difference = synergy.adjusted - synergy.baseline;

              return (
                <p
                  key={`${synergy.other}-${synergyIndex}`}
                  className="text-sm text-white"
                >
                  • {synergy.other}:{" "}
                  <span className="text-[#FFD400]">
                    {difference > 0
                      ? `+${difference.toFixed(1)}`
                      : difference.toFixed(1)}
                  </span>
                </p>
              );
            })
          )}
        </div>
      ))}
    </div>
  );
}