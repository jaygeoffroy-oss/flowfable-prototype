"use client";

import React from "react";

interface GuidanceTrends {
  netFlow: string;
  overspending: string;
  volatility: string;
  alignment: string;
}

interface GuidanceInsightsProps {
  trends: GuidanceTrends;
}

export default function GuidanceInsights({ trends }: GuidanceInsightsProps) {
  const insights: string[] = [];

  if (trends.netFlow === "Improving") {
    insights.push(
      "Your net flow trend is improving. You’re building a stronger financial foundation month by month."
    );
  } else if (trends.netFlow === "Worsening") {
    insights.push(
      "Your net flow trend is weakening. Review recurring commitments or discretionary spending to regain stability."
    );
  } else {
    insights.push(
      "Your net flow trend is stable. Maintain your current rhythm while watching for category drift."
    );
  }

  if (trends.overspending === "Improving") {
    insights.push(
      "Your overspending trend is improving. Reinforce the habits that helped reduce pressure."
    );
  } else if (trends.overspending === "Worsening") {
    insights.push(
      "Overspending pressure is rising. Focus on one or two high-impact categories to reverse the trend."
    );
  } else {
    insights.push(
      "Overspending is stable. A small adjustment in one category could accelerate progress."
    );
  }

  if (trends.volatility === "Improving") {
    insights.push(
      "Your volatility trend is improving. More predictable spending strengthens your financial stability."
    );
  } else if (trends.volatility === "Worsening") {
    insights.push(
      "Volatility is increasing. Smoothing irregular purchases will help stabilize your financial pattern."
    );
  } else {
    insights.push(
      "Volatility is stable. Continue monitoring irregular purchases to maintain consistency."
    );
  }

  if (trends.alignment === "Improving") {
    insights.push(
      "Your goal alignment trend is improving. Your spending pattern is moving closer to your stated purpose."
    );
  } else if (trends.alignment === "Worsening") {
    insights.push(
      "Goal alignment is slipping. Revisit your spending categories to realign with your long-term direction."
    );
  } else {
    insights.push(
      "Goal alignment is stable. A small improvement in net flow will strengthen alignment."
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Insights
      </h3>

      <div className="flex flex-col gap-4">
        {insights.map((insight, index) => (
          <p
            key={`${insight}-${index}`}
            className="text-sm text-white leading-relaxed"
          >
            <span className="text-[#FF7A00] mr-2" aria-hidden="true">
              •
            </span>
            {insight}
          </p>
        ))}
      </div>
    </div>
  );
}