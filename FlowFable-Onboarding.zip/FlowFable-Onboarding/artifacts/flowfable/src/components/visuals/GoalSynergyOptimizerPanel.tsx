"use client";

import React from "react";
import { optimizeGoalSynergies } from "@/lib/goals/synergyOptimizer";

interface GoalSynergyOptimizerPanelProps {
  goals: any[];
  profile: any;
}

export default function GoalSynergyOptimizerPanel({
  goals,
  profile
}: GoalSynergyOptimizerPanelProps) {
  if (!goals || goals.length < 2) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add at least two goals to compute synergies.
        </p>
      </div>
    );
  }

  const synergies = optimizeGoalSynergies(goals, profile);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Synergy Optimizer
      </h3>

      {synergies.map((synergy, index) => (
        <div
          key={`${synergy.pair}-${index}`}
          className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2"
        >
          <p className="text-sm text-white font-semibold">
            {synergy.pair}
          </p>

          <p className="text-sm text-white">
            • Synergy Score:{" "}
            <span className="text-[#FFD400]">{synergy.synergy}</span>
          </p>

          <p className="text-sm text-white">
            • Suggested Redistribution: ${synergy.redistribution}
          </p>

          <p className="text-sm text-[#FFD400]">
            {synergy.suggestion}
          </p>
        </div>
      ))}
    </div>
  );
}