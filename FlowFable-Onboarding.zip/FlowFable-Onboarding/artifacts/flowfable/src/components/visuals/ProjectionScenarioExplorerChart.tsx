"use client";

import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface ProjectionScenarioExplorerPoint {
  month: number;
  baseline: number;
  scenario: number;
}

interface ProjectionScenarioExplorerChartProps {
  data: ProjectionScenarioExplorerPoint[];
  goalName: string;
}

export default function ProjectionScenarioExplorerChart({
  data,
  goalName
}: ProjectionScenarioExplorerChartProps) {
  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Scenario Explorer
      </p>

      {data.length === 0 ? (
        <p className="text-xs text-white opacity-70">
          No scenario data available.
        </p>
      ) : (
        <div style={{ width: "100%", height: 260 }}>
          <ResponsiveContainer>
            <LineChart data={data}>
              <XAxis
                dataKey="month"
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <YAxis
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0F0F0F",
                  border: "1px solid #3A4F7A",
                  color: "#FFD400"
                }}
              />
              <Line
                type="monotone"
                dataKey="baseline"
                stroke="#FFD400"
                strokeWidth={2}
                dot={false}
                name="Baseline"
              />
              <Line
                type="monotone"
                dataKey="scenario"
                stroke="#27AE60"
                strokeWidth={2}
                dot={false}
                name="Scenario"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      <p className="text-xs text-white opacity-70 mt-2">
        Gold = Baseline, Green = Scenario
      </p>
    </div>
  );
}