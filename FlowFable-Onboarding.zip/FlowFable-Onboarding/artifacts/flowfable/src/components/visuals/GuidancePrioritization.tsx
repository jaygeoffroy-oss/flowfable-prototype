"use client";

import React from "react";

interface GuidancePrioritizationProps {
  netFlow: number;
  overspendingPressure: number;
  volatility: number;
  goalAlignmentScore: number;
}

export interface GuidancePrioritizationResult {
  timestamp: string;
  items: Array<{
    text: string;
    score: number;
    priority: number;
    context?: any;
  }>;
}

export function buildGuidancePrioritization({
  netFlow,
  overspendingPressure,
  volatility,
  goalAlignmentScore
}: GuidancePrioritizationProps): GuidancePrioritizationResult {
  const sorted = [
    {
      text: "Improve monthly net flow by reducing discretionary spending.",
      score:
        netFlow < 0
          ? 100
          : netFlow < 200
            ? 75
            : Math.max(10, 50 - netFlow / 100)
    },
    {
      text: "Review high-impact spending categories to reduce overspending pressure.",
      score: Math.min(100, Math.max(0, overspendingPressure))
    },
    {
      text: "Create a flexible buffer to smooth out month-to-month spending volatility.",
      score: Math.min(100, Math.max(0, volatility))
    },
    {
      text: "Align your next financial decision with the goal you are actively pursuing.",
      score: Math.min(100, Math.max(0, 100 - goalAlignmentScore))
    }
  ]
    .sort((first, second) => second.score - first.score)
    .map((item, index) => ({ ...item, priority: index + 1 }));

  const newHistoryEntry = {
    timestamp: new Date().toISOString(),
    items: sorted.map(item => ({
      text: item.text,
      score: item.score,
      priority: item.priority
    }))
  };

  return newHistoryEntry;
}

export default function GuidancePrioritization({
  netFlow,
  overspendingPressure,
  volatility,
  goalAlignmentScore
}: GuidancePrioritizationProps) {
  const result = buildGuidancePrioritization({
    netFlow,
    overspendingPressure,
    volatility,
    goalAlignmentScore
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Guidance Prioritization
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Focus on the actions with the greatest potential impact first.
        </p>
      </div>

      <ol className="flex flex-col gap-4">
        {result.items.map(item => (
          <li
            key={item.text}
            className="flex items-start gap-3 text-sm text-white leading-relaxed"
          >
            <span
              className="w-7 h-7 rounded-full bg-[#FF7A00] text-black font-semibold flex items-center justify-center shrink-0"
              aria-label={`Priority ${item.priority}`}
            >
              {item.priority}
            </span>
            <div className="flex-1">
              <p>{item.text}</p>
              <div
                className="mt-2 h-2 bg-[#0A1A2F] rounded"
                role="progressbar"
                aria-label={`${item.text} priority`}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Number(item.score.toFixed(0))}
              >
                <div
                  className="h-full bg-[#FFD400] rounded transition-all"
                  style={{ width: `${item.score}%` }}
                />
              </div>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}