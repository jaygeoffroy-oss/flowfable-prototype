"use client";

import React from "react";
import { confidenceScore } from "@/lib/coaching/guidanceConfidenceEngine";
import { applyPersonalizationRules } from "@/lib/coaching/personalizationRules";
import { applyCoachingVoice } from "@/lib/coaching/voiceEngine";

interface GuidanceConfidenceWrapperProps {
  profile: any;
  style: string;
  guidance: { text: string; context?: any }[];
}

export default function GuidanceConfidenceWrapper({
  profile,
  style,
  guidance
}: GuidanceConfidenceWrapperProps) {
  const scored = guidance.map(item => ({
    ...item,
    confidence: confidenceScore(profile, item.text, item.context)
  }));

  return (
    <div className="flex flex-col gap-3">
      {scored.map((item, index) => {
        const personalized = applyPersonalizationRules(profile, item.text);
        const voiced = applyCoachingVoice(style, personalized);

        return (
          <p
            key={`${item.text}-${index}`}
            className="text-sm text-white leading-relaxed"
          >
            • {voiced}{" "}
            <span className="text-[#FFD400]">
              ({item.confidence}% confidence)
            </span>
          </p>
        );
      })}
    </div>
  );
}