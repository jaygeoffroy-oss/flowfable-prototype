"use client";

import React from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";

interface BudgetVsActualChartProps {
  budget: Array<{ category: string; amount: number }>;
  transactions: Array<{
    name: string;
    amount: number;
    category: string;
    date: string;
  }>;
}

export default function BudgetVsActualChart({
  budget,
  transactions
}: BudgetVsActualChartProps) {
  const budgetMap: Record<string, number> = {};
  const actualMap: Record<string, number> = {};

  budget.forEach(b => {
    budgetMap[b.category] = (budgetMap[b.category] ?? 0) + b.amount;
  });

  transactions.forEach(t => {
    actualMap[t.category] = (actualMap[t.category] ?? 0) + t.amount;
  });

  const categories = Array.from(
    new Set([...Object.keys(budgetMap), ...Object.keys(actualMap)])
  );

  if (categories.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          No budget or transaction data yet.
        </p>
      </div>
    );
  }

  const chartData = categories.map(category => ({
    category,
    budget: budgetMap[category] ?? 0,
    actual: actualMap[category] ?? 0
  }));

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Budget vs Actual
      </h3>

      <div className="h-72 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            margin={{ top: 8, right: 8, left: 0, bottom: 8 }}
          >
            <CartesianGrid stroke="#3A4F7A" strokeDasharray="3 3" />
            <XAxis
              dataKey="category"
              tick={{ fill: "#E5E5E5", fontSize: 12 }}
              axisLine={{ stroke: "#3A4F7A" }}
            />
            <YAxis
              tick={{ fill: "#E5E5E5", fontSize: 12 }}
              axisLine={{ stroke: "#3A4F7A" }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "#0A1A2F",
                border: "1px solid #3A4F7A",
                color: "#FFFFFF"
              }}
              formatter={(value: number, name: string) => [
                value.toFixed(2),
                name === "budget" ? "Budget" : "Actual"
              ]}
            />
            <Legend wrapperStyle={{ color: "#E5E5E5" }} />
            <Bar dataKey="budget" name="Budget" fill="#2F80ED" radius={[4, 4, 0, 0]} />
            <Bar dataKey="actual" name="Actual" fill="#FF7A00" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}