"use client";

import React from "react";

interface BehavioralGuidanceEngineProps {
  netFlow: number;
  volatility: number;
  overspendingPressure: number;
  goalAlignmentScore: number;
  healthScore: number;
}

export default function BehavioralGuidanceEngine({
  netFlow,
  volatility,
  overspendingPressure,
  goalAlignmentScore,
  healthScore
}: BehavioralGuidanceEngineProps) {
  const recommendations: string[] = [];

  if (netFlow < 0) {
    recommendations.push(
      "Your monthly net flow is negative. Reduce discretionary spending or adjust recurring commitments to regain stability."
    );
  } else if (netFlow < 200) {
    recommendations.push(
      "Your net flow is positive but modest. A small reduction in category drift will accelerate your savings trajectory."
    );
  } else {
    recommendations.push(
      "Your net flow is strong. Reinforce the habits that maintain this positive momentum."
    );
  }

  if (overspendingPressure > 60) {
    recommendations.push(
      "Your spending is consuming a large portion of your income. Review high-impact categories for quick wins."
    );
  } else if (overspendingPressure > 40) {
    recommendations.push(
      "Your spending is manageable but trending high. A small adjustment in one category will improve your stability."
    );
  } else {
    recommendations.push(
      "Your spending is well-controlled. Maintain your current rhythm and protect your available margin."
    );
  }

  if (volatility > 60) {
    recommendations.push(
      "Your monthly spending varies significantly. Create a flexible buffer to absorb higher-spend months."
    );
  } else if (volatility > 30) {
    recommendations.push(
      "Your spending has some month-to-month variation. Tracking recurring patterns can make your cashflow more predictable."
    );
  } else {
    recommendations.push(
      "Your spending pattern is consistent. Use that predictability to automate savings toward your goal."
    );
  }

  if (goalAlignmentScore < 45) {
    recommendations.push(
      "Your current pattern is not aligned with your goal. Prioritize one focused spending change that improves monthly net flow."
    );
  } else if (goalAlignmentScore < 75) {
    recommendations.push(
      "You are partially aligned with your goal. Continue improving your margin through small, repeatable adjustments."
    );
  } else {
    recommendations.push(
      "Your current pattern supports your goal. Keep reinforcing the behaviors that are producing progress."
    );
  }

  if (healthScore < 50) {
    recommendations.push(
      "Your overall financial health needs attention. Focus first on restoring positive net flow before adding new commitments."
    );
  } else if (healthScore < 75) {
    recommendations.push(
      "Your financial health is developing. Consistent attention to spending and savings will strengthen your position."
    );
  } else {
    recommendations.push(
      "Your financial health is strong. Review your plan periodically to keep it resilient as circumstances change."
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Behavioral Guidance
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Personalized actions based on your current financial patterns.
        </p>
      </div>

      <ul className="flex flex-col gap-4">
        {recommendations.map((recommendation, index) => (
          <li
            key={`${recommendation}-${index}`}
            className="flex gap-3 text-sm text-white leading-relaxed"
          >
            <span className="text-[#FF7A00] shrink-0" aria-hidden="true">
              •
            </span>
            <span>{recommendation}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}