"use client";

import React, { useState } from "react";
import GuidanceExplanationTooltip from "./GuidanceExplanationTooltip";
import type { GuidanceFeedEntry } from "@/lib/guidanceTypes";

interface GuidanceFeedPanelProps {
  feed: GuidanceFeedEntry[];
}

export default function GuidanceFeedPanel({
  feed
}: GuidanceFeedPanelProps) {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Recommendation Feed
      </h3>

      {feed.length === 0 ? (
        <p className="text-sm text-white">No recommendations yet.</p>
      ) : (
        feed.map(entry => (
          <div
            key={entry.id}
            className="relative p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]"
            onMouseEnter={() => setHovered(entry.id)}
            onMouseLeave={() => setHovered(null)}
          >
            <p className="text-sm text-white leading-relaxed">
              • {entry.text}
            </p>

            <p className="text-xs text-[#FFD400] mt-1">
              Score: {entry.score} — Confidence: {entry.confidence}%
            </p>

            <p className="text-xs text-white opacity-70">
              {new Date(entry.timestamp).toLocaleString()} — {entry.category}
            </p>

            {hovered === entry.id && (
              <GuidanceExplanationTooltip reasons={entry.reasons} />
            )}
          </div>
        ))
      )}
    </div>
  );
}