"use client";

import React from "react";
import { applyCoachingVoice } from "@/lib/coaching/voiceEngine";

interface GuidanceVoiceWrapperProps {
  style: string;
  lines: string[];
}

export default function GuidanceVoiceWrapper({
  style,
  lines
}: GuidanceVoiceWrapperProps) {
  return (
    <div className="flex flex-col gap-3">
      {lines.map((line, index) => (
        <p key={`${line}-${index}`} className="text-sm text-white leading-relaxed">
          • {applyCoachingVoice(style, line)}
        </p>
      ))}
    </div>
  );
}