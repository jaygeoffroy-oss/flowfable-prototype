"use client";

import React, { useState } from "react";
import { projectGoal } from "@/lib/goals/projectionEngine";
import ProjectionChart from "@/components/visuals/ProjectionChart";

interface Goal {
  id: string;
  name: string;
  currentSavings: number;
  monthlyNet: number;
  annualGrowthRate?: number;
}

interface GoalProjectionEngineProps {
  goals: Goal[];
  profile: any;
}

export default function GoalProjectionEngine({
  goals,
  profile
}: GoalProjectionEngineProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to view projections.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Projection Engine
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min="0"
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => setMonths(Math.max(0, Number(event.target.value)))}
        />
      </label>

      {goals.map(goal => {
        const cadence = profile?.incomeCadence ?? "Monthly";
        const curve = projectGoal({
          currentSavings: goal.currentSavings,
          monthlyContribution: goal.monthlyNet,
          annualGrowthRate: goal.annualGrowthRate ?? 0,
          months,
          cadence:
            cadence === "Weekly" || cadence === "Biweekly"
              ? cadence
              : "Monthly"
        });
        const finalBalance =
          curve[curve.length - 1]?.balance ?? goal.currentSavings;

        return (
          <div
            key={goal.id}
            className="flex flex-col gap-3 p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]"
          >
            <p className="text-sm text-white font-semibold">{goal.name}</p>

            <p className="text-sm text-white">
              • Final projected balance:{" "}
              <span className="text-[#FFD400]">
                ${finalBalance.toFixed(2)}
              </span>
            </p>

            <p className="text-sm text-white">
              • Growth rate: {goal.annualGrowthRate ?? 0}% annually
            </p>

            <p className="text-sm text-white">• Cadence: {cadence}</p>

            <p className="text-sm text-white">
              • Projection horizon: {months} months
            </p>

            <ProjectionChart data={curve} goalName={goal.name} />
          </div>
        );
      })}
    </div>
  );
}