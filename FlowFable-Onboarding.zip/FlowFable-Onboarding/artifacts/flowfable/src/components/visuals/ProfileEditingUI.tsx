"use client";

import React, { useState } from "react";
import type { CoachingStyle, UserProfile } from "@/lib/userProfileTypes";

type EditableUserProfile = Partial<UserProfile> & {
  coachingStyle?: CoachingStyle;
};

interface ProfileEditingUIProps {
  profile: EditableUserProfile;
  onUpdate: (updated: EditableUserProfile) => void;
}

export default function ProfileEditingUI({
  profile,
  onUpdate
}: ProfileEditingUIProps) {
  const [form, setForm] = useState<EditableUserProfile>(profile);

  function updateField<K extends keyof EditableUserProfile>(
    field: K,
    value: EditableUserProfile[K]
  ) {
    const updated = { ...form, [field]: value };
    setForm(updated);
    onUpdate(updated);
  }

  const inputClass =
    "w-full p-2 bg-[#0A1A2F] text-white border border-[#3A4F7A] rounded focus:outline-none focus:border-[#FFD400]";
  const labelClass = "text-sm text-white";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Edit Profile
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Update your preferences to personalize FlowFable guidance.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label className="flex flex-col gap-2">
          <span className={labelClass}>Name</span>
          <input
            className={inputClass}
            value={form.name ?? ""}
            onChange={event => updateField("name", event.target.value)}
            placeholder="Your name"
          />
        </label>

        <label className="flex flex-col gap-2">
          <span className={labelClass}>Province</span>
          <input
            className={inputClass}
            value={form.province ?? ""}
            onChange={event => updateField("province", event.target.value)}
            placeholder="Your province"
          />
        </label>

        <label className="flex flex-col gap-2">
          <span className={labelClass}>Household Size</span>
          <input
            className={inputClass}
            type="number"
            min="1"
            value={form.householdSize ?? ""}
            onChange={event => {
              const value = event.target.value;
              updateField(
                "householdSize",
                value === "" ? undefined : Number(value)
              );
            }}
          />
        </label>

        <label className="flex flex-col gap-2">
          <span className={labelClass}>Income Cadence</span>
          <select
            className={inputClass}
            value={form.incomeCadence ?? "Monthly"}
            onChange={event => updateField("incomeCadence", event.target.value)}
          >
            <option value="Weekly">Weekly</option>
            <option value="Biweekly">Biweekly</option>
            <option value="Monthly">Monthly</option>
          </select>
        </label>

        <label className="flex flex-col gap-2">
          <span className={labelClass}>Financial Priority</span>
          <input
            className={inputClass}
            value={form.financialPriority ?? ""}
            onChange={event =>
              updateField("financialPriority", event.target.value)
            }
            placeholder="e.g. Build an emergency fund"
          />
        </label>

        <label className="flex flex-col gap-2">
          <span className={labelClass}>Risk Comfort</span>
          <select
            className={inputClass}
            value={form.riskComfort ?? "Moderate"}
            onChange={event => updateField("riskComfort", event.target.value)}
          >
            <option value="Low">Low</option>
            <option value="Moderate">Moderate</option>
            <option value="High">High</option>
          </select>
        </label>

        <label className="flex flex-col gap-2 md:col-span-2">
          <span className={labelClass}>Coaching Style</span>
          <select
            className={inputClass}
            value={form.coachingStyle ?? "Supportive"}
            onChange={event =>
              updateField(
                "coachingStyle",
                event.target.value as CoachingStyle
              )
            }
          >
            <option value="Supportive">Supportive</option>
            <option value="Direct">Direct</option>
            <option value="Analytical">Analytical</option>
            <option value="Motivational">Motivational</option>
          </select>
        </label>
      </div>
    </div>
  );
}