"use client";

import React from "react";
import { buildGoalStrategy } from "@/lib/goals/goalStrategyEngine";
import type { GuidanceEngineParameters } from "@/lib/coaching/guidanceEngineParameters";

interface GoalStrategyRecommenderPanelProps {
  goals: any[];
  profile: any;
  params?: Partial<GuidanceEngineParameters>;
}

export default function GoalStrategyRecommenderPanel({
  goals,
  profile,
  params
}: GoalStrategyRecommenderPanelProps) {
  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to generate strategy plans.
        </p>
      </div>
    );
  }

  const strategies = buildGoalStrategy(goals, profile, params);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Strategy Recommender
      </h3>

      {strategies.map(strategy => (
        <div
          key={strategy.goalId}
          className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-3"
        >
          <p className="text-sm text-white font-semibold">
            {strategy.goalName}
          </p>

          <p className="text-sm text-white">
            • Urgency:{" "}
            <span className="text-[#FFD400]">
              {strategy.urgency} months
            </span>
          </p>

          <p className="text-sm text-white">
            • Average Risk:{" "}
            <span className="text-[#FFD400]">
              {strategy.avgRisk.toFixed(1)}%
            </span>
          </p>

          <p className="text-sm text-white">
            • Top Synergy:{" "}
            <span className="text-[#FFD400]">
              {strategy.topSynergy?.name ?? "N/A"}
            </span>{" "}
            {strategy.topSynergy ? `(${strategy.topSynergy.score})` : ""}
          </p>

          <p className="text-sm text-white">
            • Recommended Boost:{" "}
            <span className="text-[#27AE60]">
              ${strategy.recommendedBoost}
            </span>
          </p>

          <p className="text-sm text-white">
            • Recommended Cut:{" "}
            <span className="text-[#EB5757]">
              ${strategy.recommendedCut}
            </span>
          </p>

          <div className="flex flex-col gap-1">
            {strategy.narrative.map((line, index) => (
              <p
                key={`${line}-${index}`}
                className="text-sm text-[#FFD400] leading-relaxed"
              >
                • {line}
              </p>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}