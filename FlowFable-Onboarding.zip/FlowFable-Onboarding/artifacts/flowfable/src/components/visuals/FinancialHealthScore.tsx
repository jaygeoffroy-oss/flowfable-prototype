"use client";

import React from "react";

interface FinancialHealthScoreProps {
  incomeTotal: number;
  billsTotal: number;
  transactionTotal: number;
  monthlyTotals: Record<string, number>;
  goalAlignmentScore: number;
}

export default function FinancialHealthScore({
  incomeTotal,
  billsTotal,
  transactionTotal,
  monthlyTotals,
  goalAlignmentScore
}: FinancialHealthScoreProps) {
  const netFlow = incomeTotal - billsTotal - transactionTotal;
  const safeIncome = Math.max(incomeTotal, 1);

  const overspendingPressure = Math.min(
    100,
    Math.max(0, (transactionTotal / safeIncome) * 100)
  );

  const monthlyValues = Object.values(monthlyTotals);
  const volatility =
    monthlyValues.length > 1
      ? Math.max(...monthlyValues) - Math.min(...monthlyValues)
      : 0;

  const volatilityPressure = Math.min(
    100,
    Math.max(0, (volatility / safeIncome) * 100)
  );

  const score = (() => {
    const netFlowScore =
      netFlow >= 500
        ? 90
        : netFlow >= 200
          ? 75
          : netFlow >= 0
            ? 60
            : netFlow >= -200
              ? 40
              : 20;

    const overspendingScore = 100 - overspendingPressure;
    const volatilityScore = 100 - volatilityPressure;

    return Math.round(
      netFlowScore * 0.4 +
        overspendingScore * 0.2 +
        volatilityScore * 0.2 +
        goalAlignmentScore * 0.2
    );
  })();

  const healthStatus =
    score >= 75 ? "Healthy" : score >= 50 ? "Needs Attention" : "At Risk";
  const statusColor =
    score >= 75 ? "#27AE60" : score >= 50 ? "#FF7A00" : "#EB5757";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Financial Health Score
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          A combined view of your cashflow, spending, volatility, and goal
          alignment.
        </p>
      </div>

      <div className="flex items-end gap-3">
        <span className="text-5xl font-bold" style={{ color: statusColor }}>
          {score}
        </span>
        <span className="text-sm text-[#E5E5E5] pb-2">out of 100</span>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex justify-between text-sm text-white">
          <span>Overall Health</span>
          <span style={{ color: statusColor }}>{healthStatus}</span>
        </div>
        <div
          className="h-3 bg-[#0A1A2F] rounded"
          role="progressbar"
          aria-label="Financial health score"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={score}
        >
          <div
            className="h-full rounded transition-all"
            style={{ width: `${score}%`, backgroundColor: statusColor }}
          />
        </div>
      </div>

      <p className="text-sm text-white">
        {healthStatus === "Healthy" &&
          "Your current financial pattern is supporting stability and forward progress."}
        {healthStatus === "Needs Attention" &&
          "Your system is holding together, but a few focused adjustments could improve your breathing room."}
        {healthStatus === "At Risk" &&
          "Your current pattern is creating pressure. Prioritize positive net flow and reduce avoidable spending."}
      </p>
    </div>
  );
}