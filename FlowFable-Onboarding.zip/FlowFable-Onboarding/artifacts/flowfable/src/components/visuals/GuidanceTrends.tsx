"use client";

import React from "react";

interface GuidanceItem {
  text: string;
  score: number;
  priority: number;
}

interface GuidanceHistoryEntry {
  timestamp: string;
  items: GuidanceItem[];
}

interface GuidanceTrendsProps {
  history: GuidanceHistoryEntry[];
}

export default function GuidanceTrends({ history }: GuidanceTrendsProps) {
  if (!history || history.length < 2) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Not enough history to calculate trends yet.
        </p>
      </div>
    );
  }

  const recent = history.slice(-5);

  const extractScores = (keyword: string) =>
    recent
      .map(entry =>
        entry.items.find(item =>
          item.text.toLowerCase().includes(keyword)
        )
      )
      .filter((item): item is GuidanceItem => Boolean(item))
      .map(item => item.score);

  const netFlowScores = extractScores("net flow");
  const overspendingScores = extractScores("overspending");
  const volatilityScores = extractScores("volatility");
  const alignmentScores = extractScores("goal");

  const classify = (scores: number[]) => {
    if (scores.length < 2) return "Stable";

    const first = scores[0];
    const last = scores[scores.length - 1];

    if (last < first - 10) return "Improving";
    if (last > first + 10) return "Worsening";
    return "Stable";
  };

  const trends = [
    { label: "Net Flow Trend", value: classify(netFlowScores) },
    { label: "Overspending Trend", value: classify(overspendingScores) },
    { label: "Volatility Trend", value: classify(volatilityScores) },
    { label: "Goal Alignment Trend", value: classify(alignmentScores) }
  ];

  const color = (value: string) =>
    value === "Improving"
      ? "#27AE60"
      : value === "Worsening"
        ? "#EB5757"
        : "#FFD400";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Trends
      </h3>

      <div className="flex flex-col gap-4">
        {trends.map(trend => (
          <div
            key={trend.label}
            className="flex justify-between text-white text-sm"
          >
            <span>{trend.label}</span>
            <span style={{ color: color(trend.value) }} className="font-semibold">
              {trend.value}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}