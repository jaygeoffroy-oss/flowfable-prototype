"use client";

import React, { useState } from "react";
import type { ScenarioRecord } from "@/lib/goalProgress";

interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentSavings: number;
  monthlyNet: number;
}

interface GoalScenarioSimulatorProps {
  goals: Goal[];
  onSave: (record: Omit<ScenarioRecord, "id" | "timestamp">) => Promise<void>;
}

export default function GoalScenarioSimulator({
  goals,
  onSave
}: GoalScenarioSimulatorProps) {
  const [scenario, setScenario] = useState<
    Record<string, { change: number; pause: number }>
  >({});
  const [savingGoalId, setSavingGoalId] = useState<string | null>(null);

  function updateScenario(
    goalId: string,
    field: "change" | "pause",
    value: number
  ) {
    setScenario(prev => ({
      ...prev,
      [goalId]: {
        change: prev[goalId]?.change ?? 0,
        pause: prev[goalId]?.pause ?? 0,
        [field]: value
      }
    }));
  }

  function computeScenario(goal: Goal) {
    const adjustment = scenario[goal.id] ?? { change: 0, pause: 0 };
    const newMonthlyNet = Math.max(0, goal.monthlyNet + adjustment.change);
    const remaining = Math.max(0, goal.targetAmount - goal.currentSavings);
    const monthsToGoal =
      newMonthlyNet > 0
        ? Math.ceil(remaining / newMonthlyNet) + Math.max(0, adjustment.pause)
        : null;
    const progressPercent =
      goal.targetAmount > 0
        ? Math.min(
            100,
            Math.max(0, (goal.currentSavings / goal.targetAmount) * 100)
          )
        : 0;

    return {
      newMonthlyNet,
      monthsToGoal,
      progressPercent
    };
  }

  async function saveGoalScenario(
    goal: Goal,
    result: ReturnType<typeof computeScenario>,
    adjustment: { change: number; pause: number }
  ) {
    setSavingGoalId(goal.id);
    try {
      await onSave({
        goalId: goal.id,
        goalName: goal.name,
        change: adjustment.change,
        pause: Math.max(0, adjustment.pause),
        newMonthlyNet: result.newMonthlyNet,
        monthsToGoal: result.monthsToGoal
      });
    } finally {
      setSavingGoalId(null);
    }
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Goal Scenario Simulator
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Test contribution changes and pauses before changing your plan.
        </p>
      </div>

      {goals.length === 0 ? (
        <p className="text-sm text-white">Add goals to simulate scenarios.</p>
      ) : (
        goals.map(goal => {
          const result = computeScenario(goal);
          const currentScenario = scenario[goal.id] ?? {
            change: 0,
            pause: 0
          };

          return (
            <div
              key={goal.id}
              className="flex flex-col gap-4 p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]"
            >
              <p className="text-sm text-white font-semibold">{goal.name}</p>

              <label className="flex flex-col gap-1 text-white text-sm">
                Adjust Monthly Contribution ($)
                <input
                  type="number"
                  className="p-2 bg-[#0F0F0F] border border-[#3A4F7A] rounded text-white"
                  value={currentScenario.change}
                  onChange={event =>
                    updateScenario(
                      goal.id,
                      "change",
                      Number(event.target.value)
                    )
                  }
                />
              </label>

              <label className="flex flex-col gap-1 text-white text-sm">
                Pause Goal (months)
                <input
                  type="number"
                  min="0"
                  className="p-2 bg-[#0F0F0F] border border-[#3A4F7A] rounded text-white"
                  value={currentScenario.pause}
                  onChange={event =>
                    updateScenario(
                      goal.id,
                      "pause",
                      Number(event.target.value)
                    )
                  }
                />
              </label>

              <div className="flex justify-between text-white text-sm">
                <span>New Monthly Net</span>
                <span className="font-semibold text-[#FFD400]">
                  ${result.newMonthlyNet.toFixed(2)}
                </span>
              </div>

              <div className="flex justify-between text-white text-sm">
                <span>New Time Horizon</span>
                <span className="font-semibold text-[#FFD400]">
                  {result.monthsToGoal === null
                    ? "Not Achievable"
                    : result.monthsToGoal === 0
                      ? "Goal Reached"
                      : `${result.monthsToGoal} months`}
                </span>
              </div>

              <div className="flex flex-col gap-1">
                <div className="flex justify-between text-white text-sm">
                  <span>Current Progress</span>
                  <span className="text-[#FFD400]">
                    {result.progressPercent.toFixed(0)}%
                  </span>
                </div>
                <div
                  className="h-2 bg-[#0F0F0F] rounded"
                  role="progressbar"
                  aria-label={`${goal.name} scenario progress`}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Number(result.progressPercent.toFixed(0))}
                >
                  <div
                    className="h-full bg-[#27AE60] rounded transition-all"
                    style={{ width: `${result.progressPercent}%` }}
                  />
                </div>
              </div>

              <button
                type="button"
                className="p-2 bg-[#FFD400] text-[#0F0F0F] rounded font-semibold hover:bg-[#FF8F33] transition-colors disabled:opacity-50"
                disabled={savingGoalId === goal.id}
                onClick={() =>
                  void saveGoalScenario(goal, result, currentScenario)
                }
              >
                {savingGoalId === goal.id ? "Saving..." : "Save Scenario"}
              </button>
            </div>
          );
        })
      )}
    </div>
  );
}