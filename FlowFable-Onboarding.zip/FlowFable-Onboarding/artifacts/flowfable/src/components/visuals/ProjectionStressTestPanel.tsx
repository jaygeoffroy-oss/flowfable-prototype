"use client";

import React, { useState } from "react";
import { runStressTest } from "@/lib/goals/stressTestEngine";
import ProjectionStressTestChart from "./ProjectionStressTestChart";

interface ProjectionStressTestPanelProps {
  goals: any[];
  profile: any;
}

export default function ProjectionStressTestPanel({
  goals,
  profile
}: ProjectionStressTestPanelProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to run stress tests.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Stress Test Engine
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min={1}
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => {
            const nextMonths = Number(event.target.value);
            setMonths(
              Number.isFinite(nextMonths) ? Math.max(1, nextMonths) : 1
            );
          }}
        />
      </label>

      {goals.map(goal => {
        const stress = runStressTest(goal, profile ?? {}, months);
        const combined = stress.baseline.map((point, index) => ({
          month: point.month,
          baseline: point.balance,
          worst: stress.worst[index]?.balance ?? point.balance,
          best: stress.best[index]?.balance ?? point.balance
        }));

        return (
          <ProjectionStressTestChart
            key={goal.id}
            data={combined}
            goalName={goal.name}
          />
        );
      })}
    </div>
  );
}