"use client";

import React from "react";

interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentSavings: number;
  monthlyNet: number;
}

interface GoalInterdependenciesProps {
  goals: Goal[];
}

export default function GoalInterdependencies({
  goals
}: GoalInterdependenciesProps) {
  if (!goals || goals.length < 2) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add at least two goals to unlock interdependency analysis.
        </p>
      </div>
    );
  }

  const insights: string[] = [];

  for (let i = 0; i < goals.length; i += 1) {
    for (let j = i + 1; j < goals.length; j += 1) {
      const a = goals[i];
      const b = goals[j];

      const aRemaining = Math.max(0, a.targetAmount - a.currentSavings);
      const bRemaining = Math.max(0, b.targetAmount - b.currentSavings);

      const aMonths =
        a.monthlyNet > 0 ? Math.ceil(aRemaining / a.monthlyNet) : null;
      const bMonths =
        b.monthlyNet > 0 ? Math.ceil(bRemaining / b.monthlyNet) : null;

      if (a.monthlyNet > 0 && b.monthlyNet > 0) {
        insights.push(
          `${a.name} and ${b.name} compete for monthly net flow. Increasing surplus will benefit both goals.`
        );
      }

      if (
        a.name.toLowerCase().includes("emergency") &&
        b.monthlyNet > 0
      ) {
        insights.push(
          `${a.name} reinforces ${b.name} by reducing volatility and protecting monthly net flow.`
        );
      }
      if (
        b.name.toLowerCase().includes("emergency") &&
        a.monthlyNet > 0
      ) {
        insights.push(
          `${b.name} reinforces ${a.name} by reducing volatility and protecting monthly net flow.`
        );
      }

      if (
        aMonths !== null &&
        bMonths !== null &&
        Math.abs(aMonths - bMonths) > 12
      ) {
        const short = aMonths < bMonths ? a : b;
        const long = aMonths < bMonths ? b : a;

        insights.push(
          `${short.name} may overshadow ${long.name}. Consider balancing short-term and long-term priorities.`
        );
      }

      if (a.monthlyNet <= 0 && b.monthlyNet <= 0) {
        insights.push(
          `${a.name} and ${b.name} both lack positive net flow. Adjusting spending or increasing income will unlock progress.`
        );
      }
    }
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Interdependencies
      </h3>

      <div className="flex flex-col gap-4">
        {insights.length === 0 ? (
          <p className="text-sm text-white">
            No major interdependencies detected.
          </p>
        ) : (
          insights.map((text, index) => (
            <p
              key={`${text}-${index}`}
              className="text-sm text-white leading-relaxed"
            >
              • {text}
            </p>
          ))
        )}
      </div>
    </div>
  );
}