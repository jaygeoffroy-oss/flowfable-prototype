"use client";

import React from "react";

interface GuidanceItem {
  text: string;
  score: number;
  priority: number;
}

interface GuidanceHistoryEntry {
  timestamp: string;
  items: GuidanceItem[];
}

interface GuidanceHistoryProps {
  history: GuidanceHistoryEntry[];
}

export default function GuidanceHistory({ history }: GuidanceHistoryProps) {
  if (!history || history.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          No guidance history available yet.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance History
      </h3>

      <div className="flex flex-col gap-6">
        {history.map((entry, index) => (
          <div key={`${entry.timestamp}-${index}`} className="flex flex-col gap-3">
            <p className="text-sm text-white font-semibold">
              {new Date(entry.timestamp).toLocaleDateString()}
            </p>

            {entry.items.map((item, itemIndex) => (
              <div
                key={`${item.priority}-${itemIndex}`}
                className="flex flex-col gap-1"
              >
                <p className="text-sm text-white">
                  <span className="text-[#FFD400] font-semibold">
                    Priority {item.priority}
                  </span>{" "}
                  — {item.text}
                </p>

                <div className="h-2 bg-[#0A1A2F] rounded">
                  <div
                    className="h-full rounded bg-[#FFD400]"
                    style={{
                      width: `${Math.min(100, Math.max(0, item.score))}%`
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}