"use client";

import React from "react";
import { buildGoalPlaybook } from "@/lib/goals/goalStrategyPlaybookEngine";

interface GoalStrategyPlaybookPanelProps {
  goals: any[];
  profile: any;
  guidance: any[];
}

function finalBalance(points: { balance: number }[] | undefined) {
  return points?.[points.length - 1]?.balance ?? 0;
}

export default function GoalStrategyPlaybookPanel({
  goals,
  profile,
  guidance
}: GoalStrategyPlaybookPanelProps) {
  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to generate a strategy playbook.
        </p>
      </div>
    );
  }

  const playbooks = buildGoalPlaybook(goals, profile ?? {}, guidance ?? []);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-8">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Goal Strategy Playbook
      </h3>

      {playbooks.map(playbook => {
        const topSynergy = playbook.topSynergy;

        return (
          <div
            key={playbook.goalName}
            className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-4"
          >
            <p className="text-lg text-white font-semibold">
              {playbook.goalName}
            </p>

            <p className="text-sm text-white">
              • Priority Level:{" "}
              <span className="text-[#FFD400]">
                {playbook.urgency} months
              </span>
            </p>

            <p className="text-sm text-white">
              • Average Risk:{" "}
              <span className="text-[#FFD400]">
                {playbook.avgRisk.toFixed(1)}%
              </span>
            </p>

            <p className="text-sm text-white">
              • Top Synergy:{" "}
              <span className="text-[#FFD400]">
                {topSynergy?.name ?? "N/A"}
              </span>{" "}
              {topSynergy ? `(${topSynergy.score})` : ""}
            </p>

            <p className="text-sm text-white">
              • Recommended Boost:{" "}
              <span className="text-[#27AE60]">
                ${playbook.recommendedBoost}
              </span>
            </p>
            <p className="text-sm text-white">
              • Recommended Cut:{" "}
              <span className="text-[#EB5757]">
                ${playbook.recommendedCut}
              </span>
            </p>

            <div className="flex flex-col gap-1">
              {playbook.narrative.map((line, index) => (
                <p
                  key={`${line}-${index}`}
                  className="text-sm text-[#FFD400] leading-relaxed"
                >
                  • {line}
                </p>
              ))}
            </div>

            <p className="text-sm text-white font-semibold mt-2">
              Stress Test Summary:
            </p>
            <p className="text-sm text-white">
              • Worst-Case Final Balance:{" "}
              <span className="text-[#EB5757]">
                {finalBalance(playbook.stress.worst).toFixed(2)}
              </span>
            </p>
            <p className="text-sm text-white">
              • Best-Case Final Balance:{" "}
              <span className="text-[#27AE60]">
                {finalBalance(playbook.stress.best).toFixed(2)}
              </span>
            </p>

            <p className="text-sm text-white font-semibold mt-2">
              Confidence Band Summary:
            </p>
            <p className="text-sm text-white">
              • Baseline:{" "}
              <span className="text-[#FFD400]">
                {finalBalance(playbook.bands.baseline).toFixed(2)}
              </span>
            </p>

            <p className="text-sm text-white font-semibold mt-2">
              Distribution Simulation:
            </p>
            <p className="text-sm text-white">
              • Median Outcome (p50):{" "}
              <span className="text-[#FFD400]">
                {playbook.distribution.percentiles.at(-1)?.p50?.toFixed(2) ??
                  "0.00"}
              </span>
            </p>

            {playbook.impact && (
              <>
                <p className="text-sm text-white font-semibold mt-2">
                  Impact Forecast:
                </p>
                <p className="text-sm text-white">
                  • Timeline Impact:{" "}
                  <span className="text-[#FFD400]">
                    {playbook.impact.timelineImpact.toFixed(2)} CAD
                  </span>
                </p>
                <p className="text-sm text-white">
                  • Risk Impact:{" "}
                  <span className="text-[#FFD400]">
                    {playbook.impact.riskImpact.toFixed(2)}%
                  </span>
                </p>
              </>
            )}

            <p className="text-sm text-white font-semibold mt-2">
              Action Plan:
            </p>
            <p className="text-sm text-[#FFD400]">
              • Increase contributions by ${playbook.recommendedBoost} for the
              next 3 months
            </p>
            <p className="text-sm text-[#FFD400]">
              • Rebalance synergy with {topSynergy?.name ?? "other goals"}
            </p>
            <p className="text-sm text-[#FFD400]">
              • Re-evaluate risk after 60 days
            </p>
            <p className="text-sm text-[#FFD400]">
              • Run a new distribution simulation after next pay cycle
            </p>
          </div>
        );
      })}
    </div>
  );
}