"use client";

import React, { useState } from "react";
import { runScenario } from "@/lib/goals/scenarioRunnerEngine";
import ProjectionScenarioExplorerChart from "./ProjectionScenarioExplorerChart";

interface ProjectionScenarioExplorerPanelProps {
  goals: any[];
  profile: any;
}

export default function ProjectionScenarioExplorerPanel({
  goals,
  profile
}: ProjectionScenarioExplorerPanelProps) {
  const [selectedGoalId, setSelectedGoalId] = useState<string>("");
  const [months, setMonths] = useState(24);
  const [contributionChange, setContributionChange] = useState(0);
  const [growthMultiplier, setGrowthMultiplier] = useState(1);
  const [pauseMonths, setPauseMonths] = useState(0);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to explore projection scenarios.
        </p>
      </div>
    );
  }

  const selectedGoal = goals.find(goal => goal.id === selectedGoalId) ?? goals[0];
  const result = runScenario(selectedGoal, profile ?? {}, {
    months,
    contributionChange,
    growthMultiplier,
    pauseMonths
  });
  const combined = result.baseline.map((b, idx) => ({
    month: b.month,
    baseline: b.balance,
    scenario: result.scenario[idx]?.balance ?? b.balance
  }));

  const updateNumber = (
    value: string,
    setter: (next: number) => void,
    minimum: number
  ) => {
    const next = Number(value);
    setter(Number.isFinite(next) ? Math.max(minimum, next) : minimum);
  };

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Scenario Explorer
      </h3>

      <div className="grid gap-4 md:grid-cols-2">
        <label className="flex flex-col gap-1 text-white text-sm">
          Goal
          <select
            className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
            value={selectedGoal.id}
            onChange={event => setSelectedGoalId(event.target.value)}
          >
            {goals.map(goal => (
              <option key={goal.id} value={goal.id}>
                {goal.name}
              </option>
            ))}
          </select>
        </label>

        <label className="flex flex-col gap-1 text-white text-sm">
          Projection Horizon (months)
          <input
            type="number"
            min={1}
            className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
            value={months}
            onChange={event => updateNumber(event.target.value, setMonths, 1)}
          />
        </label>

        <label className="flex flex-col gap-1 text-white text-sm">
          Monthly Contribution Change
          <input
            type="number"
            className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
            value={contributionChange}
            onChange={event =>
              setContributionChange(Number(event.target.value) || 0)
            }
          />
        </label>

        <label className="flex flex-col gap-1 text-white text-sm">
          Growth Multiplier
          <input
            type="number"
            min={0}
            step={0.05}
            className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
            value={growthMultiplier}
            onChange={event =>
              updateNumber(event.target.value, setGrowthMultiplier, 0)
            }
          />
        </label>

        <label className="flex flex-col gap-1 text-white text-sm">
          Pause Contributions (months)
          <input
            type="number"
            min={0}
            className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
            value={pauseMonths}
            onChange={event =>
              updateNumber(event.target.value, setPauseMonths, 0)
            }
          />
        </label>
      </div>

      <ProjectionScenarioExplorerChart
        data={combined}
        goalName={selectedGoal.name}
      />
    </div>
  );
}