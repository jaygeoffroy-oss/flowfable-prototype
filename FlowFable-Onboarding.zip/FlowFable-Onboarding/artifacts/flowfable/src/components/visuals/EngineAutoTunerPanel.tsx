"use client";

import React from "react";
import { runEngineAutoTuner } from "@/lib/coaching/engineAutoTuner";
import type { AutoTunerLog } from "@/lib/coaching/engineAutoTuner";
import type { AdaptiveTuningAdvice } from "@/lib/coaching/adaptiveTuningAdvice";
import type { GuidanceEngineParams } from "@/lib/coaching/guidanceEngineParameters";
import type { EngineHealth } from "@/lib/coaching/engineHealth";
import type { EngineStability } from "@/lib/coaching/engineStability";

interface EngineAutoTunerPanelProps {
  params: GuidanceEngineParams;
  nextRunParams?: GuidanceEngineParams;
  autoTunerLog?: AutoTunerLog;
  engineHealth: EngineHealth;
  engineStability: EngineStability;
  advice: AdaptiveTuningAdvice;
}

export default function EngineAutoTunerPanel({
  params,
  nextRunParams,
  autoTunerLog,
  engineHealth,
  engineStability,
  advice
}: EngineAutoTunerPanelProps) {
  const result = runEngineAutoTuner({
    params,
    engineHealth,
    engineStability,
    advice
  });
  const displayedLog = autoTunerLog ?? result.autoTunerLog;

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Engine Auto‑Tuner
      </h3>

      <p className="text-sm text-white">• Updated Parameters:</p>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        {Object.entries(result.updatedParams).map(([key, value]) => (
          <p key={key} className="text-sm text-[#FFD400]">
            • {key}: {value}
          </p>
        ))}
      </div>

      {nextRunParams && (
        <>
          <p className="text-sm text-white">• Next Run Parameters:</p>
          <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
            {Object.entries(nextRunParams).map(([key, value]) => (
              <p key={key} className="text-sm text-[#FFD400]">
                • {key}: {value}
              </p>
            ))}
          </div>
        </>
      )}

      {displayedLog.length > 0 && (
        <div className="auto-tuner-log">
          <h3 className="text-sm text-white font-semibold">Auto‑Tuner Log</h3>
          <pre className="mt-2 whitespace-pre-wrap text-sm text-[#FFD400]">
            {JSON.stringify(displayedLog, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
}