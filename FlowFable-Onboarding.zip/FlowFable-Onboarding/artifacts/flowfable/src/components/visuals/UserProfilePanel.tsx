"use client";

import React from "react";
import type { CoachingStyle, UserProfile } from "@/lib/userProfileTypes";

interface UserProfilePanelProps {
  profile: Partial<UserProfile> & { coachingStyle?: CoachingStyle };
}

export default function UserProfilePanel({ profile }: UserProfilePanelProps) {
  const {
    name = "User",
    province = "Not set",
    householdSize = 1,
    incomeCadence = "Monthly",
    financialPriority = "Not specified",
    riskComfort = "Moderate",
    coachingStyle = "Supportive"
  } = profile;

  const details = [
    { label: "Province", value: province },
    { label: "Household Size", value: householdSize },
    { label: "Income Cadence", value: incomeCadence },
    { label: "Financial Priority", value: financialPriority },
    { label: "Risk Comfort", value: riskComfort },
    { label: "Coaching Style", value: coachingStyle }
  ];

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Profile Overview
        </h3>
        <p className="text-sm text-white mt-1">
          Welcome, <span className="font-semibold text-[#FFD400]">{name}</span>
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {details.map(detail => (
          <div
            key={detail.label}
            className="p-3 bg-[#0A1A2F] rounded border border-[#3A4F7A]"
          >
            <p className="text-xs text-[#E5E5E5]">{detail.label}</p>
            <p className="text-sm text-white font-semibold mt-1">
              {detail.value}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}