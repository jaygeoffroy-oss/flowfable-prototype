"use client";

import React from "react";

interface PriorityItem {
  text: string;
  score: number;
  priority: number;
}

interface TrendSummary {
  netFlow: string;
  overspending: string;
  volatility: string;
  alignment: string;
}

interface PortfolioItem {
  id: string;
  name: string;
  progressPercent: number;
  monthsToGoal: number | null;
  risk: string;
  score: number;
  monthlyNet?: number;
}

interface GuidanceSummaryCardProps {
  priorities: PriorityItem[];
  trends: TrendSummary;
  portfolio: PortfolioItem[];
  interdependencies: string[];
}

export default function GuidanceSummaryCard({
  priorities,
  trends,
  portfolio,
  interdependencies
}: GuidanceSummaryCardProps) {
  const topPriority = priorities[0];
  const topGoal = portfolio[0];

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Summary
      </h3>

      <div className="flex flex-col gap-2">
        <p className="text-sm text-white font-semibold">Top Priority</p>
        <p className="text-sm text-white leading-relaxed">
          • {topPriority?.text ?? "No priority guidance available yet."}
        </p>
      </div>

      <div className="flex flex-col gap-2">
        <p className="text-sm text-white font-semibold">Trend Overview</p>
        <p className="text-sm text-white leading-relaxed">
          • Net Flow: {trends.netFlow}
        </p>
        <p className="text-sm text-white leading-relaxed">
          • Overspending: {trends.overspending}
        </p>
        <p className="text-sm text-white leading-relaxed">
          • Volatility: {trends.volatility}
        </p>
        <p className="text-sm text-white leading-relaxed">
          • Goal Alignment: {trends.alignment}
        </p>
      </div>

      <div className="flex flex-col gap-2">
        <p className="text-sm text-white font-semibold">Strongest Goal</p>
        {topGoal ? (
          <>
            <p className="text-sm text-white leading-relaxed">
              • {topGoal.name} — {topGoal.progressPercent.toFixed(0)}% complete
            </p>
            <p className="text-sm text-white leading-relaxed">
              • Time Horizon:{" "}
              {topGoal.monthlyNet !== undefined && topGoal.monthlyNet <= 0
                ? "Not Achievable"
                : topGoal.monthsToGoal === null
                  ? "Not Achievable"
                  : `${topGoal.monthsToGoal} months`}
            </p>
            <p className="text-sm text-white leading-relaxed">
              • Risk Level: {topGoal.risk}
            </p>
          </>
        ) : (
          <p className="text-sm text-white">• No goal portfolio data yet.</p>
        )}
      </div>

      <div className="flex flex-col gap-2">
        <p className="text-sm text-white font-semibold">
          Key Interdependencies
        </p>
        {interdependencies.length === 0 ? (
          <p className="text-sm text-white">
            • No major interdependencies detected.
          </p>
        ) : (
          interdependencies.slice(0, 3).map((text, index) => (
            <p
              key={`${text}-${index}`}
              className="text-sm text-white leading-relaxed"
            >
              • {text}
            </p>
          ))
        )}
      </div>
    </div>
  );
}