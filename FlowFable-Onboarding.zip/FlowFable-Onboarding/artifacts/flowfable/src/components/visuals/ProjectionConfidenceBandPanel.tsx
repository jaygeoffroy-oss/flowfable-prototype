"use client";

import React, { useState } from "react";
import { buildConfidenceBands } from "@/lib/goals/projectionConfidenceBandEngine";
import ProjectionConfidenceBandChart from "./ProjectionConfidenceBandChart";

interface ProjectionConfidenceBandPanelProps {
  goals: any[];
  profile: any;
}

export default function ProjectionConfidenceBandPanel({
  goals,
  profile
}: ProjectionConfidenceBandPanelProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to view confidence bands.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Confidence Bands
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min={1}
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => {
            const nextMonths = Number(event.target.value);
            setMonths(
              Number.isFinite(nextMonths) ? Math.max(1, nextMonths) : 1
            );
          }}
        />
      </label>

      {goals.map(goal => {
        const bands = buildConfidenceBands(goal, profile ?? {}, months);
        const combined = bands.baseline.map((point, index) => ({
          month: point.month,
          baseline: point.balance,
          optimistic: bands.optimistic[index]?.balance ?? point.balance,
          conservative: bands.conservative[index]?.balance ?? point.balance
        }));

        return (
          <ProjectionConfidenceBandChart
            key={goal.id}
            data={combined}
            goalName={goal.name}
          />
        );
      })}
    </div>
  );
}