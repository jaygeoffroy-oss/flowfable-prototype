"use client";

import React from "react";
import { runGuidanceSystemGovernor } from "@/lib/coaching/guidanceSystemGovernorEngine";
import type { GuidanceSystemAutopilotInput } from "@/lib/coaching/guidanceSystemGovernorEngine";

interface GuidanceSystemGovernorPanelProps {
  autopilot?: GuidanceSystemAutopilotInput | null;
}

export default function GuidanceSystemGovernorPanel({
  autopilot
}: GuidanceSystemGovernorPanelProps) {
  const governed = runGuidanceSystemGovernor(autopilot);

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance System Governor
      </h3>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2">
        <p className="text-sm text-white">
          • Governor Status:{" "}
          <span className="text-[#27AE60]">{governed.status}</span>
        </p>
        <p className="text-sm text-white">
          • Governed Risk Weight:{" "}
          <span className="text-[#FFD400]">{governed.riskWeight}</span>
        </p>
        <p className="text-sm text-white">
          • Governed Synergy Weight:{" "}
          <span className="text-[#FFD400]">{governed.synergyWeight}</span>
        </p>
        <p className="text-sm text-white">
          • Governed Scenario Aggression:{" "}
          <span className="text-[#FFD400]">{governed.scenarioAggression}</span>
        </p>
        <p className="text-sm text-white">
          • Category Bias:{" "}
          <span className="text-[#FFD400]">{governed.categoryBias}</span>
        </p>
        <p className="text-sm text-white">
          • Tone: <span className="text-[#FFD400]">{governed.tone}</span>
        </p>
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Governor Interventions
        </p>
        {governed.interventions.length === 0 ? (
          <p className="text-sm text-[#FFD400]">
            • No interventions applied.
          </p>
        ) : (
          governed.interventions.map((line, index) => (
            <p
              key={`${line}-${index}`}
              className="text-sm text-[#FFD400] leading-relaxed"
            >
              • {line}
            </p>
          ))
        )}
      </div>
    </div>
  );
}