"use client";

import React, { useState } from "react";
import { runDistributionSimulation } from "@/lib/goals/projectionDistributionEngine";
import ProjectionDistributionChart from "./ProjectionDistributionChart";

interface ProjectionDistributionSimulatorPanelProps {
  goals: any[];
  profile: any;
}

export default function ProjectionDistributionSimulatorPanel({
  goals,
  profile
}: ProjectionDistributionSimulatorPanelProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to run distribution simulations.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Distribution Simulator
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min={1}
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => {
            const nextMonths = Number(event.target.value);
            setMonths(
              Number.isFinite(nextMonths) ? Math.max(1, nextMonths) : 1
            );
          }}
        />
      </label>

      {goals.map(goal => {
        const { percentiles } = runDistributionSimulation(
          goal,
          profile ?? {},
          months
        );

        return (
          <ProjectionDistributionChart
            key={goal.id}
            percentiles={percentiles}
            goalName={goal.name}
          />
        );
      })}
    </div>
  );
}