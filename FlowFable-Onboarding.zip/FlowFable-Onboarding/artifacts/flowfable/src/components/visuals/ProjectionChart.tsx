"use client";

import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface ProjectionChartProps {
  data: { month: number; balance: number }[];
  goalName: string;
}

export default function ProjectionChart({
  data,
  goalName
}: ProjectionChartProps) {
  if (!data || data.length === 0) {
    return (
      <p className="text-sm text-white">
        No projection data available for {goalName}.
      </p>
    );
  }

  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Projection Chart
      </p>

      <div style={{ width: "100%", height: 250 }}>
        <ResponsiveContainer>
          <LineChart data={data}>
            <XAxis
              dataKey="month"
              stroke="#FFD400"
              tick={{ fill: "#FFD400", fontSize: 12 }}
              label={{
                value: "Month",
                position: "insideBottom",
                offset: -5,
                fill: "#E5E5E5"
              }}
            />
            <YAxis
              stroke="#FFD400"
              tick={{ fill: "#FFD400", fontSize: 12 }}
              tickFormatter={value => `$${Number(value).toLocaleString()}`}
            />
            <Tooltip
              formatter={value => [
                `$${Number(value).toFixed(2)}`,
                "Balance"
              ]}
              labelFormatter={label => `Month ${label}`}
              contentStyle={{
                backgroundColor: "#0F0F0F",
                border: "1px solid #3A4F7A",
                color: "#FFD400"
              }}
            />
            <Line
              type="monotone"
              dataKey="balance"
              stroke="#FFD400"
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}