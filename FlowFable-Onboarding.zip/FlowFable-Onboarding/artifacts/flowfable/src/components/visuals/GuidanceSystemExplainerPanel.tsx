"use client";

import React from "react";
import { buildGuidanceSystemExplanation } from "@/lib/coaching/guidanceSystemExplainerEngine";

export default function GuidanceSystemExplainerPanel() {
  const sections = buildGuidanceSystemExplanation();

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance System Explainer
      </h3>

      {sections.map(section => (
        <div
          key={section.title}
          className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2"
        >
          <p className="text-sm text-white font-semibold">
            {section.title}
          </p>

          {section.details.map((detail, index) => (
            <p
              key={`${section.title}-${index}`}
              className="text-sm text-white leading-relaxed"
            >
              • {detail}
            </p>
          ))}
        </div>
      ))}
    </div>
  );
}