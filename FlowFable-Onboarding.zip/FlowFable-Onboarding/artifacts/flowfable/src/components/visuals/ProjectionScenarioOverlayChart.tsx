"use client";

import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface ProjectionScenarioOverlayChartProps {
  baseline: { month: number; balance: number }[];
  scenario: { month: number; balance: number }[];
  goalName: string;
}

export default function ProjectionScenarioOverlayChart({
  baseline,
  scenario,
  goalName
}: ProjectionScenarioOverlayChartProps) {
  const combined = baseline.map((point, index) => ({
    month: point.month,
    baseline: point.balance,
    scenario: scenario[index]?.balance ?? point.balance
  }));

  if (combined.length === 0) {
    return (
      <p className="text-sm text-white">
        No scenario projection data available for {goalName}.
      </p>
    );
  }

  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Scenario Overlay
      </p>

      <div style={{ width: "100%", height: 250 }}>
        <ResponsiveContainer>
          <LineChart data={combined}>
            <XAxis
              dataKey="month"
              stroke="#FFD400"
              tick={{ fill: "#FFD400", fontSize: 12 }}
              label={{
                value: "Month",
                position: "insideBottom",
                offset: -5,
                fill: "#E5E5E5"
              }}
            />
            <YAxis
              stroke="#FFD400"
              tick={{ fill: "#FFD400", fontSize: 12 }}
              tickFormatter={value =>
                `$${Number(value).toLocaleString()}`
              }
            />
            <Tooltip
              formatter={value => [
                `$${Number(value).toFixed(2)}`,
                "Balance"
              ]}
              labelFormatter={label => `Month ${label}`}
              contentStyle={{
                backgroundColor: "#0F0F0F",
                border: "1px solid #3A4F7A",
                color: "#FFD400"
              }}
            />

            <Line
              type="monotone"
              dataKey="baseline"
              stroke="#FFD400"
              strokeWidth={2}
              dot={false}
              name="Baseline"
            />

            <Line
              type="monotone"
              dataKey="scenario"
              stroke="#27AE60"
              strokeWidth={2}
              dot={false}
              name="Scenario"
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}