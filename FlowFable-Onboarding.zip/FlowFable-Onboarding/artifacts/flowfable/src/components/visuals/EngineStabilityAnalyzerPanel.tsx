"use client";

import React from "react";
import { analyzeEngineStability } from "@/lib/coaching/engineStabilityAnalyzer";
import type { EngineParameterSnapshot } from "@/lib/coaching/engineParameterSnapshotLogger";

interface EngineStabilityAnalyzerPanelProps {
  engineHistory: EngineParameterSnapshot[];
}

export default function EngineStabilityAnalyzerPanel({
  engineHistory
}: EngineStabilityAnalyzerPanelProps) {
  const stability = analyzeEngineStability(engineHistory);

  const color =
    stability.stability === "stable"
      ? "#27AE60"
      : stability.stability === "unstable"
        ? "#EB5757"
        : "#F2C94C";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Engine Stability Analyzer
      </h3>

      <p className="text-sm text-white">
        • Stability: <span style={{ color }}>{stability.stability}</span>
      </p>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">Drift</p>
        {Object.entries(stability.drift).map(([key, value]) => (
          <p key={key} className="text-sm text-[#FFD400]">
            • {key}: {value}
          </p>
        ))}
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">Volatility</p>
        {Object.entries(stability.volatility).map(([key, value]) => (
          <p key={key} className="text-sm text-[#FFD400]">
            • {key}: {value ? "volatile" : "stable"}
          </p>
        ))}
      </div>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">Notes</p>
        {stability.notes.length === 0 ? (
          <p className="text-sm text-[#27AE60]">
            • No instability detected.
          </p>
        ) : (
          stability.notes.map((note, index) => (
            <p key={`${note}-${index}`} className="text-sm text-[#FFD400]">
              • {note}
            </p>
          ))
        )}
      </div>
    </div>
  );
}