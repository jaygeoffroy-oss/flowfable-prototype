"use client";

import React from "react";

interface RiskGaugesProps {
  incomeTotal: number;
  billsTotal: number;
  transactionTotal: number;
  monthlyTotals: Record<string, number>;
}

function clamp(value: number) {
  return Math.min(100, Math.max(0, value));
}

function gaugeColor(value: number) {
  if (value >= 70) return "#EB5757";
  if (value >= 40) return "#FF7A00";
  return "#27AE60";
}

export default function RiskGauges({
  incomeTotal,
  billsTotal,
  transactionTotal,
  monthlyTotals
}: RiskGaugesProps) {
  const netFlow = incomeTotal - billsTotal - transactionTotal;
  const recurringPressure = billsTotal + transactionTotal;

  const cashflowPressure = clamp(
    (recurringPressure / Math.max(incomeTotal, 1)) * 100
  );

  const monthlyValues = Object.values(monthlyTotals);
  const monthlyAverage =
    monthlyValues.length > 0
      ? monthlyValues.reduce((sum, value) => sum + value, 0) /
        monthlyValues.length
      : 0;
  const variance =
    monthlyValues.length > 0
      ? monthlyValues.reduce(
          (sum, value) => sum + (value - monthlyAverage) ** 2,
          0
        ) / monthlyValues.length
      : 0;
  const spendingVolatility =
    monthlyAverage > 0
      ? clamp((Math.sqrt(variance) / monthlyAverage) * 100)
      : 0;

  const netFlowRisk =
    incomeTotal > 0
      ? clamp(netFlow < 0 ? 100 : (1 - netFlow / incomeTotal) * 100)
      : recurringPressure > 0
        ? 100
        : 0;
  const overallRisk = (cashflowPressure + spendingVolatility + netFlowRisk) / 3;

  const gauges = [
    { label: "Cashflow Pressure", value: cashflowPressure },
    { label: "Spending Volatility", value: spendingVolatility },
    { label: "Overall Risk", value: overallRisk }
  ];

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">Risk Gauges</h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Higher readings indicate less financial breathing room.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {gauges.map(gauge => {
          const color = gaugeColor(gauge.value);

          return (
            <div key={gauge.label} className="flex flex-col gap-2">
              <div className="flex justify-between text-sm text-white">
                <span>{gauge.label}</span>
                <span>{gauge.value.toFixed(0)}%</span>
              </div>
              <div
                className="h-3 bg-[#0A1A2F] rounded"
                role="progressbar"
                aria-label={gauge.label}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={Number(gauge.value.toFixed(0))}
              >
                <div
                  className="h-full rounded transition-all"
                  style={{ width: `${gauge.value}%`, backgroundColor: color }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}