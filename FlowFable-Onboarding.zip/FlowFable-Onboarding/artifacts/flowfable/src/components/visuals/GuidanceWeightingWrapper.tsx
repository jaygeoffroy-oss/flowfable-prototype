"use client";

import React from "react";
import { weightGuidance } from "@/lib/coaching/guidanceWeightingEngine";
import { applyPersonalizationRules } from "@/lib/coaching/personalizationRules";
import { applyCoachingVoice } from "@/lib/coaching/voiceEngine";

interface GuidanceWeightingWrapperProps {
  profile: any;
  style: string;
  guidance: { text: string; context?: any }[];
}

export default function GuidanceWeightingWrapper({
  profile,
  style,
  guidance
}: GuidanceWeightingWrapperProps) {
  const weighted = guidance
    .map(item => ({
      ...item,
      score: weightGuidance(profile, item.text, item.context)
    }))
    .sort((a, b) => b.score - a.score);

  return (
    <div className="flex flex-col gap-3">
      {weighted.map((item, index) => {
        const personalized = applyPersonalizationRules(profile, item.text);
        const voiced = applyCoachingVoice(style, personalized);

        return (
          <p
            key={`${item.text}-${index}`}
            className="text-sm text-white leading-relaxed"
          >
            • {voiced}{" "}
            <span className="text-[#FFD400]">({item.score})</span>
          </p>
        );
      })}
    </div>
  );
}