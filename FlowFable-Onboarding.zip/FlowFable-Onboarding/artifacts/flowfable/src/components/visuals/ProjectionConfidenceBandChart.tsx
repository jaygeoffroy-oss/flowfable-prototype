"use client";

import React from "react";
import {
  AreaChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer
} from "recharts";

interface ProjectionConfidenceBandPoint {
  month: number;
  baseline: number;
  optimistic: number;
  conservative: number;
}

interface ProjectionConfidenceBandChartProps {
  data: ProjectionConfidenceBandPoint[];
  goalName: string;
}

export default function ProjectionConfidenceBandChart({
  data,
  goalName
}: ProjectionConfidenceBandChartProps) {
  return (
    <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
      <p className="text-sm text-white font-semibold mb-2">
        {goalName} — Confidence Bands
      </p>

      {data.length === 0 ? (
        <p className="text-xs text-white opacity-70">
          No confidence-band data available.
        </p>
      ) : (
        <div style={{ width: "100%", height: 260 }}>
          <ResponsiveContainer>
            <AreaChart data={data}>
              <XAxis
                dataKey="month"
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <YAxis
                stroke="#FFD400"
                tick={{ fill: "#FFD400" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#0F0F0F",
                  border: "1px solid #3A4F7A",
                  color: "#FFD400"
                }}
              />

              <Area
                type="monotone"
                dataKey="conservative"
                stroke="#EB5757"
                fill="#EB5757"
                fillOpacity={0.25}
                name="Conservative"
              />
              <Area
                type="monotone"
                dataKey="optimistic"
                stroke="#27AE60"
                fill="#27AE60"
                fillOpacity={0.25}
                name="Optimistic"
              />
              <Line
                type="monotone"
                dataKey="baseline"
                stroke="#FFD400"
                strokeWidth={2}
                dot={false}
                name="Baseline"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      <p className="text-xs text-white opacity-70 mt-2">
        Gold = Baseline, Green = Optimistic Band, Red = Conservative Band
      </p>
    </div>
  );
}