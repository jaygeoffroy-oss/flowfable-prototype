"use client";

import React, { useState } from "react";
import { buildScenarioOverlay } from "@/lib/goals/scenarioOverlayEngine";
import ProjectionScenarioOverlayChart from "./ProjectionScenarioOverlayChart";

interface ProjectionScenarioOverlayPanelProps {
  goals: any[];
  profile: any;
  history: any[];
}

export default function ProjectionScenarioOverlayPanel({
  goals,
  profile,
  history
}: ProjectionScenarioOverlayPanelProps) {
  const [selectedScenarioId, setSelectedScenarioId] = useState<number | null>(
    null
  );
  const [months, setMonths] = useState(24);

  const scenario = history.find(historyItem => {
    return historyItem.id === selectedScenarioId;
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Scenario Overlay
      </h3>

      {history.length === 0 ? (
        <p className="text-sm text-white">
          Save a scenario to overlay projections.
        </p>
      ) : (
        <>
          <label className="flex flex-col gap-1 text-white text-sm">
            Select Scenario
            <select
              className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
              value={selectedScenarioId ?? ""}
              onChange={event => {
                setSelectedScenarioId(
                  event.target.value === ""
                    ? null
                    : Number(event.target.value)
                );
              }}
            >
              <option value="">Choose a scenario</option>
              {history.map(historyItem => (
                <option key={historyItem.id} value={historyItem.id}>
                  {historyItem.goalName} —{" "}
                  {new Date(historyItem.timestamp).toLocaleString()}
                </option>
              ))}
            </select>
          </label>

          <label className="flex flex-col gap-1 text-white text-sm">
            Projection Horizon (months)
            <input
              type="number"
              min={1}
              className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
              value={months}
              onChange={event => {
                const nextMonths = Number(event.target.value);
                setMonths(
                  Number.isFinite(nextMonths) ? Math.max(1, nextMonths) : 1
                );
              }}
            />
          </label>

          {scenario &&
            goals
              .filter(goal => goal.id === scenario.goalId)
              .map(goal => {
                const overlay = buildScenarioOverlay(
                  goal,
                  scenario,
                  profile,
                  months
                );

                return (
                  <ProjectionScenarioOverlayChart
                    key={goal.id}
                    baseline={overlay.baseline}
                    scenario={overlay.scenarioCurve}
                    goalName={goal.name}
                  />
                );
              })}
        </>
      )}
    </div>
  );
}