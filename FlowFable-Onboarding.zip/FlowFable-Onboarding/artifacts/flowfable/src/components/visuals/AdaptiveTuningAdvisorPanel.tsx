"use client";

import React from "react";
import { buildAdaptiveTuningAdvice } from "@/lib/coaching/adaptiveTuningAdvisorEngine";
import type { EngineHealthStatus } from "@/lib/coaching/engineHealth";
import type { EngineStabilityAnalysis } from "@/lib/coaching/engineStability";
import type { GuidanceEngineParameters } from "@/lib/coaching/guidanceEngineParameters";

interface AdaptiveTuningAdvisorPanelProps {
  engineHealth: EngineHealthStatus;
  engineStability: EngineStabilityAnalysis;
  params: GuidanceEngineParameters;
}

export default function AdaptiveTuningAdvisorPanel({
  engineHealth,
  engineStability,
  params
}: AdaptiveTuningAdvisorPanelProps) {
  const advice = buildAdaptiveTuningAdvice({
    engineHealth,
    engineStability,
    params
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Adaptive Tuning Advisor
      </h3>

      <p className="text-sm text-white">
        • Summary: <span className="text-[#FFD400]">{advice.summary}</span>
      </p>

      <div className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A]">
        <p className="text-sm text-white font-semibold mb-2">
          Detailed Advice
        </p>
        {advice.advice.map((line, index) => (
          <p key={`${line}-${index}`} className="text-sm text-[#FFD400]">
            • {line}
          </p>
        ))}
      </div>
    </div>
  );
}