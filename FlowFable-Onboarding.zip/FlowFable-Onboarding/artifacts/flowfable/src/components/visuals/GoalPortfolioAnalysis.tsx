"use client";

import React from "react";

interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentSavings: number;
  monthlyNet: number;
}

interface GoalPortfolioAnalysisProps {
  goals: Goal[];
}

export default function GoalPortfolioAnalysis({
  goals
}: GoalPortfolioAnalysisProps) {
  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          No goals available for portfolio analysis.
        </p>
      </div>
    );
  }

  const analyzed = goals.map(goal => {
    const remaining = Math.max(0, goal.targetAmount - goal.currentSavings);
    const monthsToGoal =
      goal.monthlyNet > 0 ? Math.ceil(remaining / goal.monthlyNet) : null;
    const progressPercent =
      goal.targetAmount > 0
        ? Math.min(
            100,
            Math.max(0, (goal.currentSavings / goal.targetAmount) * 100)
          )
        : 0;
    const risk =
      goal.monthlyNet <= 0
        ? "High"
        : monthsToGoal !== null && monthsToGoal > 18
          ? "Medium"
          : "Low";

    return { ...goal, remaining, monthsToGoal, progressPercent, risk };
  });

  const riskColor = (risk: string) =>
    risk === "Low" ? "#27AE60" : risk === "Medium" ? "#FF7A00" : "#EB5757";

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <div>
        <h3 className="text-xl font-semibold text-[#FFD400]">
          Goal Portfolio Analysis
        </h3>
        <p className="text-sm text-[#E5E5E5] mt-1">
          Compare progress, timing, and risk across your active goals.
        </p>
      </div>

      <div className="flex flex-col gap-4">
        {analyzed.map(goal => (
          <div
            key={goal.id}
            className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-4"
          >
            <div className="flex justify-between items-center gap-4">
              <p className="text-sm text-white font-semibold">{goal.name}</p>
              <span
                className="text-sm font-semibold"
                style={{ color: riskColor(goal.risk) }}
              >
                {goal.risk} Risk
              </span>
            </div>

            <div className="flex justify-between text-white text-sm">
              <span>Progress</span>
              <span style={{ color: riskColor(goal.risk) }}>
                {goal.progressPercent.toFixed(0)}%
              </span>
            </div>

            <div
              className="h-2 bg-[#0F0F0F] rounded"
              role="progressbar"
              aria-label={`${goal.name} portfolio progress`}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-valuenow={Number(goal.progressPercent.toFixed(0))}
            >
              <div
                className="h-full rounded transition-all"
                style={{
                  width: `${goal.progressPercent}%`,
                  backgroundColor: riskColor(goal.risk)
                }}
              />
            </div>

            <div className="grid grid-cols-2 gap-4 text-sm text-white">
              <span>
                Remaining:{" "}
                <strong>${goal.remaining.toFixed(2)}</strong>
              </span>
              <span>
                Time:{" "}
                <strong>
                  {goal.monthsToGoal === null
                    ? "Not achievable"
                    : goal.monthsToGoal === 0
                      ? "Reached"
                      : `${goal.monthsToGoal} months`}
                </strong>
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}