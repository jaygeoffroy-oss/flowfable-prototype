"use client";

import React from "react";
import { narrateGuidanceEvolution } from "@/lib/coaching/guidanceEvolutionNarrator";
import type { GuidanceEvolutionReport } from "@/lib/guidanceEvolutionReport";

interface GuidanceEvolutionReportPanelProps {
  report: GuidanceEvolutionReport | null;
}

export default function GuidanceEvolutionReportPanel({
  report
}: GuidanceEvolutionReportPanelProps) {
  if (!report) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-sm text-white">
          Not enough data to generate a report.
        </p>
      </div>
    );
  }

  const narrative = narrateGuidanceEvolution(report);
  const lines = Array.isArray(narrative) ? narrative : [narrative];

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-4">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Guidance Evolution Report
      </h3>

      {lines.map((line, index) => (
        <p
          key={`${line}-${index}`}
          className="text-sm text-white leading-relaxed"
        >
          • {line}
        </p>
      ))}
    </div>
  );
}