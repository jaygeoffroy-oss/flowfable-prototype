"use client";

import React, { useState } from "react";
import { optimizeScenario } from "@/lib/goals/projectionScenarioOptimizerEngine";

interface ProjectionScenarioOptimizerPanelProps {
  goals: any[];
  profile: any;
}

export default function ProjectionScenarioOptimizerPanel({
  goals,
  profile
}: ProjectionScenarioOptimizerPanelProps) {
  const [months, setMonths] = useState(24);

  if (!goals || goals.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add goals to optimize scenarios.
        </p>
      </div>
    );
  }

  const results = goals.map(goal =>
    optimizeScenario(goal, goals, profile ?? {}, months)
  );

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Projection Scenario Optimizer
      </h3>

      <label className="flex flex-col gap-1 text-white text-sm">
        Projection Horizon (months)
        <input
          type="number"
          min={1}
          className="p-2 bg-[#0A1A2F] border border-[#3A4F7A] rounded text-white"
          value={months}
          onChange={event => {
            const nextMonths = Number(event.target.value);
            setMonths(
              Number.isFinite(nextMonths) ? Math.max(1, nextMonths) : 1
            );
          }}
        />
      </label>

      {results.map((best, index) => {
        const goal = goals[index];

        return (
          <div
            key={goal.id}
            className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-2"
          >
            <p className="text-sm text-white font-semibold">{goal.name}</p>

            <p className="text-sm text-white">
              • Best Contribution Change:{" "}
              <span className="text-[#FFD400]">
                {best.change} CAD
              </span>
            </p>

            <p className="text-sm text-white">
              • Best Pause Duration:{" "}
              <span className="text-[#FFD400]">{best.pause} months</span>
            </p>

            <p className="text-sm text-white">
              • Growth Multiplier:{" "}
              <span className="text-[#FFD400]">{best.gm.toFixed(2)}</span>
            </p>

            <p className="text-sm text-white">
              • Final Balance:{" "}
              <span className="text-[#27AE60]">
                {best.finalBalance.toFixed(2)}
              </span>
            </p>

            <p className="text-sm text-white">
              • Risk Score:{" "}
              <span className="text-[#FFD400]">
                {best.risk.toFixed(2)}%
              </span>
            </p>

            <p className="text-sm text-white">
              • Synergy Score:{" "}
              <span className="text-[#FFD400]">{best.synergy.toFixed(2)}</span>
            </p>

            <p className="text-sm text-white">
              <span className="text-[#FFD400] font-semibold">
                • Overall Scenario Score: {best.score.toFixed(2)}
              </span>
            </p>
          </div>
        );
      })}
    </div>
  );
}