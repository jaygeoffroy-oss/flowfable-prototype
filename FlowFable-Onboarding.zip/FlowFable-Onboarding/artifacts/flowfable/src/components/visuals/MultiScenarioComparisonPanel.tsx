"use client";

import React from "react";
import type { ScenarioComparison } from "@/lib/scenarioComparison";

interface MultiScenarioComparisonPanelProps {
  comparisons: ScenarioComparison[];
}

export default function MultiScenarioComparisonPanel({
  comparisons
}: MultiScenarioComparisonPanelProps) {
  if (!comparisons || comparisons.length < 2) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          Add at least two scenarios to compare.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Multi-Scenario Comparison
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {comparisons.map(comparison => (
          <div
            key={comparison.id}
            className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-3"
          >
            <p className="text-white text-sm font-semibold">
              {comparison.name}
            </p>

            <p className="text-sm text-white">
              • Feasibility:{" "}
              <span className="text-[#FFD400]">
                {comparison.feasibility}/100
              </span>
            </p>

            <p className="text-sm text-white">
              • Confidence:{" "}
              <span className="text-[#FFD400]">{comparison.confidence}</span>
            </p>

            <div className="flex gap-1 mt-2" aria-label={`${comparison.name} risk heatmap`}>
              {comparison.risk.map((riskPoint, index) => {
                const color =
                  riskPoint.score > 70
                    ? "bg-red-600"
                    : riskPoint.score > 40
                      ? "bg-yellow-500"
                      : "bg-green-600";

                return (
                  <div
                    key={`${comparison.id}-${riskPoint.month}-${index}`}
                    className={`${color} h-3 w-3 rounded`}
                    title={`${riskPoint.label} — ${riskPoint.score}/100`}
                  />
                );
              })}
            </div>

            <p className="text-xs text-white opacity-70">
              Risk heatmap (month-by-month)
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}