"use client";

import React from "react";
import { buildEngineParameterTimeline } from "@/lib/coaching/engineParameterTimelineEngine";
import EngineParameterTimelineChart from "./EngineParameterTimelineChart";
import type { EngineParameterSnapshot } from "@/lib/coaching/engineParameterTimeline";

interface EngineParameterTimelinePanelProps {
  history: EngineParameterSnapshot[];
}

export default function EngineParameterTimelinePanel({
  history
}: EngineParameterTimelinePanelProps) {
  const timeline = buildEngineParameterTimeline({ history });

  if (!timeline || timeline.length === 0) {
    return (
      <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A]">
        <p className="text-[#FFD400] text-sm">
          No parameter history available yet.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Engine Parameter Timeline
      </h3>
      <EngineParameterTimelineChart data={timeline} />
    </div>
  );
}