"use client";

import React from "react";
import { buildEngineParameterIntegrationReport } from "@/lib/coaching/engineParameterIntegrationReportEngine";
import type { GuidanceEngineParameters } from "@/lib/coaching/guidanceEngineParameters";
import type { GuidanceSystemTuning } from "@/lib/coaching/guidanceSystemTuning";
import type { GuidanceSystemAutopilotInput } from "@/lib/coaching/guidanceSystemGovernorEngine";
import type { GuidanceSystemGovernorResult } from "@/lib/coaching/guidanceSystemGovernorEngine";

interface EngineParameterIntegrationReportPanelProps {
  tuning: GuidanceSystemTuning;
  autopilot: GuidanceSystemAutopilotInput & { changes?: string[] };
  governor: GuidanceSystemGovernorResult;
  params: GuidanceEngineParameters;
}

export default function EngineParameterIntegrationReportPanel({
  tuning,
  autopilot,
  governor,
  params
}: EngineParameterIntegrationReportPanelProps) {
  const report = buildEngineParameterIntegrationReport({
    tuning,
    autopilot,
    governor,
    params
  });

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">
        Engine Parameter Integration Report
      </h3>

      {report.map(section => (
        <div
          key={section.stage}
          className="p-4 bg-[#0A1A2F] rounded border border-[#3A4F7A] flex flex-col gap-3"
        >
          <p className="text-lg text-white font-semibold">{section.stage}</p>
          <p className="text-sm text-white opacity-80">
            {section.description}
          </p>

          {section.changes.length > 0 && (
            <div className="mt-2">
              <p className="text-sm text-white font-semibold">Changes:</p>
              {section.changes.map((change, index) => (
                <p key={`${change}-${index}`} className="text-sm text-[#FFD400]">
                  • {change}
                </p>
              ))}
            </div>
          )}

          <div className="mt-2">
            <p className="text-sm text-white font-semibold">Values:</p>
            {Object.entries(section.values).map(([key, value]) => (
              <p key={key} className="text-sm text-[#FFD400]">
                • {key}:{" "}
                {typeof value === "object"
                  ? JSON.stringify(value)
                  : String(value)}
              </p>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}