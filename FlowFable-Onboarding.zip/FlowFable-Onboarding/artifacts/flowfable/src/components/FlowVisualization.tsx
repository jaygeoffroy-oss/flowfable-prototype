"use client";

import React from "react";

interface FlowVisualizationProps {
  incomeTotal: number;
  billsTotal: number;
  budgetTotal: number;
  transactionTotal: number;
}

export default function FlowVisualization({
  incomeTotal,
  billsTotal,
  budgetTotal,
  transactionTotal
}: FlowVisualizationProps) {
  const netFlow = incomeTotal - billsTotal - transactionTotal;

  const maxValue = Math.max(
    incomeTotal,
    billsTotal,
    budgetTotal,
    transactionTotal,
    Math.abs(netFlow),
    1
  );

  function barWidth(value: number) {
    return `${(Math.max(0, value) / maxValue) * 100}%`;
  }

  return (
    <div className="p-6 bg-[#0F0F0F] rounded-lg border border-[#3A4F7A] flex flex-col gap-6">
      <h3 className="text-xl font-semibold text-[#FFD400]">Flow Overview</h3>

      <div className="flex flex-col gap-4">
        <div>
          <p className="text-sm text-white mb-1">Income</p>
          <div className="h-3 bg-[#0A1A2F] rounded">
            <div
              className="h-full bg-[#27AE60] rounded"
              style={{ width: barWidth(incomeTotal) }}
            />
          </div>
        </div>

        <div>
          <p className="text-sm text-white mb-1">Bills</p>
          <div className="h-3 bg-[#0A1A2F] rounded">
            <div
              className="h-full bg-[#EB5757] rounded"
              style={{ width: barWidth(billsTotal) }}
            />
          </div>
        </div>

        <div>
          <p className="text-sm text-white mb-1">Budget</p>
          <div className="h-3 bg-[#0A1A2F] rounded">
            <div
              className="h-full bg-[#2F80ED] rounded"
              style={{ width: barWidth(budgetTotal) }}
            />
          </div>
        </div>

        <div>
          <p className="text-sm text-white mb-1">Transactions</p>
          <div className="h-3 bg-[#0A1A2F] rounded">
            <div
              className="h-full bg-[#9B51E0] rounded"
              style={{ width: barWidth(transactionTotal) }}
            />
          </div>
        </div>

        <div>
          <p className="text-sm text-white mb-1">Net Flow</p>
          <div className="h-3 bg-[#0A1A2F] rounded">
            <div
              className={`h-full ${
                netFlow >= 0 ? "bg-[#27AE60]" : "bg-[#EB5757]"
              } rounded`}
              style={{ width: barWidth(Math.abs(netFlow)) }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}