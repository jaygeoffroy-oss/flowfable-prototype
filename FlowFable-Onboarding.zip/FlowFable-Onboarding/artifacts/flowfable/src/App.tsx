import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import SignUp from '@/pages/signup';
import HomePage from '@/pages/home';
import DashboardPage from '@/app/dashboard/page';
import AboutPage from '@/app/about/page';
import HelpPage from '@/app/help/page';
import ContactPage from '@/app/contact/page';
import HistoryPage from '@/app/history/page';
import HistoryDetailPage from '@/app/history/[index]/page';
import ComparisonPage from '@/app/compare/page';
import ProfilePage from '@/app/profile/page';
import SettingsPage from '@/app/settings/page';
import PrivacyPage from '@/pages/privacy';
import CookiePolicyPage from '@/pages/cookies';
import UploadPage from '@/pages/upload';
import NavBar from '@/components/NavBar';
import Footer from '@/components/Footer';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/help" component={HelpPage} />
      <Route path="/contact" component={ContactPage} />
      <Route path="/signup" component={SignUp} />
      <Route path="/history/:id" component={HistoryDetailPage} />
      <Route path="/history" component={HistoryPage} />
      <Route path="/compare/:left/:right" component={ComparisonPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/settings" component={SettingsPage} />
      <Route path="/privacy" component={PrivacyPage} />
      <Route path="/cookies" component={CookiePolicyPage} />
      <Route path="/upload" component={UploadPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppShell() {
  const [location] = useLocation();
  const showAppShell = location !== '/signup';

  if (!showAppShell) {
    return <Router />;
  }

  return (
    <div className="bg-white text-black">
      <NavBar />
      <main className="max-w-xl mx-auto p-6 ff-text">
        <Router />
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <AppShell />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
