import type { StabilitySnapshot } from "@/lib/engines/stabilityEngine";
import type { RunwaySnapshot } from "@/lib/engines/runwayEngine";
import type { RhythmSnapshot } from "@/lib/engines/rhythmEngine";
import type { PressureEvent } from "@/lib/engines/pressureEngine";
import type { SpendingPatternEvent } from "@/lib/engines/patternEngine";
import type { RecurringExpense } from "@/lib/engines/recurringEngine";
import type { ForecastEvent } from "@/lib/engines/forecastEngine";
import type { TrendResult } from "@/lib/engines/trendEngine";

import type { Insight } from "@/lib/insightTypes";

import { generateStabilityInsights } from "@/lib/insights/stabilityInsights";
import { generateRunwayInsights } from "@/lib/insights/runwayInsights";
import { generateRhythmInsights } from "@/lib/insights/rhythmInsights";
import { generatePressureInsights } from "@/lib/insights/pressureInsights";
import { generatePatternInsights } from "@/lib/insights/patternInsights";
import { generateRecurringInsights } from "@/lib/insights/recurringInsights";
import { generateForecastInsights } from "@/lib/insights/forecastInsights";
import { generateTrendInsights } from "@/lib/insights/trendInsights";

/**
 * Combine all insight sources into a unified Insight[].
 */
export function buildInsights(
  stability: StabilitySnapshot[],
  runway: RunwaySnapshot[],
  rhythm: RhythmSnapshot[],
  pressure: PressureEvent[],
  patterns: SpendingPatternEvent[],
  recurring: RecurringExpense[],
  forecast: ForecastEvent[],
  trends: TrendResult[]
): Insight[] {
  return [
    ...generateStabilityInsights(stability),
    ...generateRunwayInsights(runway),
    ...generateRhythmInsights(rhythm),
    ...generatePressureInsights(pressure),
    ...generatePatternInsights(patterns),
    ...generateRecurringInsights(recurring),
    ...generateForecastInsights(forecast),
    ...generateTrendInsights(trends)
  ];
}
