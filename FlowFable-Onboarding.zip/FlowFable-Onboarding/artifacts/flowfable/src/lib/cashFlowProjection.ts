import type { RecurringForecast } from "@/lib/recurringForecast";

export interface CashFlowProjection {
  date: string;
  projectedBalance: number;
  upcomingCharges: {
    merchant: string;
    amount: number;
  }[];
}

/**
 * Generates a simple 30‑day cash‑flow projection based on:
 * - current balance
 * - upcoming recurring charges
 *
 * This is the foundation for future runway analysis and pressure scoring.
 */
export function generateCashFlowProjection(
  currentBalance: number,
  forecasts: RecurringForecast[]
): CashFlowProjection[] {
  const projection: CashFlowProjection[] = [];

  // Build a 30‑day window
  const today = new Date();

  for (let i = 0; i < 30; i++) {
    const date = new Date(today);
    date.setDate(today.getDate() + i);

    const iso = date.toISOString().split("T")[0];

    // Find charges landing on this date
    const chargesToday = forecasts.filter(
      (f) => f.nextChargeDate === iso
    );

    // Sum charge amounts
    const totalCharges = chargesToday.reduce(
      (sum, f) => sum + f.averageAmount,
      0
    );

    // Deduct from balance
    currentBalance -= totalCharges;

    projection.push({
      date: iso,
      projectedBalance: parseFloat(currentBalance.toFixed(2)),
      upcomingCharges: chargesToday.map((f) => ({
        merchant: f.merchant,
        amount: f.averageAmount,
      })),
    });
  }

  return projection;
}
