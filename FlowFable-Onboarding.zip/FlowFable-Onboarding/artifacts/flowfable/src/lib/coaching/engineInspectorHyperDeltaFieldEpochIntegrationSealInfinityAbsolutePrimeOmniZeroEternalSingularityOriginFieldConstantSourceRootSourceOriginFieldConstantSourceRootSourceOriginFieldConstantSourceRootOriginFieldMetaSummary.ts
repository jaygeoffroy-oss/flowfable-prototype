export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldMetaSummary(
  currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary: string,
  previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary: string | null
): string {
  if (!previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary) {
    return `Cross‑hyper‑epoch sixty‑sixth‑order reliability trends cannot yet be determined. A second Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field summary is required to establish long‑range behavior.`;
  }

  const improving =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("high meta‑meta‑meta") &&
    !previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("medium meta‑meta‑meta") &&
    previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("low meta‑meta‑meta") &&
    !previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("variable meta‑meta‑meta") &&
    !previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("high meta‑meta‑meta") &&
    previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginFieldSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement patterns stabilize at the sixty‑sixth‑order meta‑layer, contradiction patterns diminish, and long‑range coherence strengthens with stable field‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement patterns weaken at the sixty‑sixth‑order meta‑layer, contradiction signals increase, and long‑range coherence declines away from field‑invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field meta‑meta‑meta‑…‑reliability. Structural coherence fails at the sixty‑sixth‑order meta‑layer, contradiction patterns dominate, and long‑range coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns oscillate at the sixty‑sixth‑order meta‑layer, producing unstable long‑range coherence with inconsistent field‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns remain balanced at the sixty‑sixth‑order meta‑layer, producing a flat long‑range trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin‑Field trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range signal.`;
}