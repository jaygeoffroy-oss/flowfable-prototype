import type { EngineInspectorAutonomyHarmonizationSeal } from "./engineInspectorAutonomyHarmonizationSeal";

export function buildInspectorAutonomyHarmonizationSealSummary(
  inspectorAutonomyHarmonizationSeal: EngineInspectorAutonomyHarmonizationSeal
): string {
  const s = inspectorAutonomyHarmonizationSeal.autonomyHarmonizationSeal;

  if (s.seal === "Platinum") {
    return `The Inspector demonstrates fully harmonized autonomy. All tiers reinforce each other, contradictions are absent, and cross‑tier alignment is exceptionally strong. The system exhibits maximal coherence and unified autonomous behavior.`;
  }

  if (s.seal === "Gold") {
    return `The Inspector demonstrates strong autonomy harmonization. Reinforcements outweigh contradictions, and dominant tiers align well across stability, evolution, and governance. Minor inconsistencies exist but do not disrupt overall coherence.`;
  }

  if (s.seal === "Silver") {
    return `The Inspector demonstrates partial autonomy harmonization. Cross‑tier contradictions reduce alignment strength, and reinforcing signals are present but insufficient to unify all tiers. Structural coherence is adequate but requires improvement.`;
  }

  return `The Inspector demonstrates misaligned autonomy. Cross‑tier contradictions dominate, reinforcing signals are weak or absent, and dominant tiers conflict with lagging tiers. The system’s harmonized autonomy field is unstable and requires intervention.`;
}