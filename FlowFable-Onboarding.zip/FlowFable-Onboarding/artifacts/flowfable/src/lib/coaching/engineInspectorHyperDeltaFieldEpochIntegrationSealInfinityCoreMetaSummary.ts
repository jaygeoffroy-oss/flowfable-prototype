export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityCoreMetaSummary(
  currentInfinityCoreSummary: string,
  previousInfinityCoreSummary?: string
): string {
  if (!previousInfinityCoreSummary) {
    return `Cross‑hyper‑epoch twenty‑first‑order reliability trends cannot yet be determined. A second Infinity‑Core summary is required to establish long‑range Infinity‑Core behavior.`;
  }

  const improving =
    currentInfinityCoreSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityCoreSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const degrading =
    currentInfinityCoreSummary.includes(
      "medium meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousInfinityCoreSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const collapsing =
    currentInfinityCoreSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityCoreSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const fluctuating =
    currentInfinityCoreSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityCoreSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const stable =
    currentInfinityCoreSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousInfinityCoreSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Infinity‑Core meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the twenty‑first‑order meta‑layer, contradiction patterns diminish, and long‑range Infinity‑Core coherence strengthens with stable core‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Infinity‑Core meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the twenty‑first‑order meta‑layer, contradiction signals increase, and long‑range Infinity‑Core coherence declines away from core‑invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Infinity‑Core meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the twenty‑first‑order meta‑layer, contradiction patterns dominate, and long‑range Infinity‑Core coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Infinity‑Core meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the twenty‑first‑order meta‑layer, producing unstable long‑range Infinity‑Core coherence with inconsistent core‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Infinity‑Core meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the twenty‑first‑order meta‑layer, producing a flat long‑range Infinity‑Core trajectory approaching core‑invariant stability.`;
  }

  return `Cross‑hyper‑epoch Infinity‑Core trends are inconclusive. Reinforcement and contradiction patterns do not clearly indicate improvement, degradation, collapse, or stability.`;
}