import type { EngineInspectorCrossSystemDeltaFieldIntegration } from "./engineInspectorCrossSystemDeltaFieldIntegration";

export function buildInspectorCrossSystemDeltaFieldIntegrationSummary(
  inspectorCrossSystemDeltaFieldIntegration: EngineInspectorCrossSystemDeltaFieldIntegration
): string {
  const i =
    inspectorCrossSystemDeltaFieldIntegration.crossSystemDeltaFieldIntegration;

  if (i.globalTrajectory === "Aligned") {
    return `The cross-system delta field is aligned. Autonomy, harmonization, unified integration, and unified-seal signals reinforce each other, producing a coherent global delta trajectory.`;
  }

  if (i.globalTrajectory === "Misaligned") {
    return `The cross-system delta field is misaligned. Contradictions across autonomy, harmonization, unified integration, and unified-seal signals weaken global delta coherence.`;
  }

  if (i.globalTrajectory === "Mixed") {
    return `The cross-system delta field is mixed. Reinforcing and contradictory signals coexist across autonomy, harmonization, unified integration, and unified-seal layers.`;
  }

  return `The cross-system delta field could not be classified. The available global delta signals do not provide sufficient clarity for unified interpretation.`;
}