import type { EngineInspectorAutonomousGovernanceRewriteSeal } from "./engineInspectorAutonomousGovernanceRewriteSeal";

export function buildInspectorAutonomousGovernanceRewriteSealSummary(
  inspectorAutonomousGovernanceRewriteSeal: EngineInspectorAutonomousGovernanceRewriteSeal
): string {
  const seal =
    inspectorAutonomousGovernanceRewriteSeal.autonomousGovernanceRewriteSeal;

  if (seal.seal === "Platinum") {
    return `The Inspector’s governance model is fully future-ready. Rewrite actions are minimal, governance integrity is strong, and no significant risks were detected. The system demonstrates exceptional resilience and long-term governance stability.`;
  }

  if (seal.seal === "Gold") {
    return `The Inspector’s governance model is stable but requires attention. Rewrite actions are recommended to address emerging governance concerns. Issues requiring attention: ${seal.issues.join(", ")}.`;
  }

  if (seal.seal === "Silver") {
    return `The Inspector’s governance model shows signs of degradation. Rewrite actions are necessary to restore alignment and prevent future instability. Issues detected: ${seal.issues.join(", ")}.`;
  }

  return `The Inspector’s governance model requires critical intervention. Rewrite actions are high-priority and essential to restore governance integrity. Issues detected: ${seal.issues.join(", ")}.`;
}