export function buildInspectorCrossSystemDeltaFieldIntegrationMetaSummary(
  inspectorCrossSystemDeltaFieldIntegrationSummary: string,
  previousCrossSystemDeltaFieldIntegrationSummary?: string
): string {
  const current = inspectorCrossSystemDeltaFieldIntegrationSummary;
  const previous = previousCrossSystemDeltaFieldIntegrationSummary;

  if (!previous) {
    return `The cross‑system delta field meta‑summary has been generated for the first time. Cross‑cycle global delta field trends will begin once a second meta‑summary is available.`;
  }

  const improving =
    current.includes("aligned") &&
    !previous.includes("aligned");

  const degrading =
    current.includes("misaligned") &&
    !previous.includes("misaligned");

  const stable =
    current === previous;

  const mixed =
    current.includes("mixed") &&
    !previous.includes("mixed");

  if (improving) {
    return `Cross‑cycle analysis shows improving global delta alignment. Reinforcement signals across autonomy, harmonization, unified integration, and unified‑seal deltas have strengthened, reducing contradictions and producing a more coherent cross‑system delta field.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows degrading global delta alignment. Contradictions across autonomy, harmonization, unified integration, and unified‑seal deltas have increased, weakening global delta coherence and destabilizing the merged delta ecosystem.`;
  }

  if (mixed) {
    return `Cross‑cycle analysis shows mixed global delta behavior. Reinforcing and contradictory elements shifted unevenly across autonomy, harmonization, unified integration, and unified‑seal deltas, producing an ambiguous global delta trajectory.`;
  }

  if (stable) {
    return `Cross‑cycle global delta field behavior remains stable. The merged autonomy‑harmonization‑unified delta ecosystem continues to evolve consistently across cycles, with no major shifts in global alignment.`;
  }

  return `Cross‑cycle global delta signals do not clearly indicate improvement or degradation. Partial shifts across autonomy, harmonization, unified integration, and unified‑seal deltas produce an indeterminate global delta trajectory.`;
}