import { saveEngineHistory } from "./engineParameterPersistence";
import {
  appendEngineParameterSnapshot,
  createEngineParameterSnapshot
} from "./engineParameterSnapshotLogger";

export function commitNextRunParameters(flow: any) {
  const nextRunParams = flow.nextRunParams;
  const { engineHistory, tuning, autopilot, governor } = flow;

  if (!nextRunParams) {
    return flow;
  }

  const snapshot = createEngineParameterSnapshot({
    tuning,
    autopilot,
    governor,
    params: nextRunParams
  });

  const updatedHistory = appendEngineParameterSnapshot(
    engineHistory ?? [],
    snapshot
  );
  saveEngineHistory(updatedHistory);

  return {
    ...flow,
    engineHistory: updatedHistory
  };
}