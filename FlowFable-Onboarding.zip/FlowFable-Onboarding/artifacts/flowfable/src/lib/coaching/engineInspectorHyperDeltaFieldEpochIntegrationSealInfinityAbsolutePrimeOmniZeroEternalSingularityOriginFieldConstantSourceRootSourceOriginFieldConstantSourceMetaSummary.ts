export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantSourceMetaSummary(
  currentFieldConstantSourceRootSourceOriginFieldConstantSourceSummary: string,
  previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary: string | null
): string {
  if (!previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary) {
    return `Cross‑hyper‑epoch fifty‑seventh‑order reliability trends cannot yet be determined. A second Field‑Root‑Source‑Origin‑Field‑Constant‑Source summary is required to establish long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source behavior.`;
  }

  const improving =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("high meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("medium meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("low meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("variable meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("high meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Field‑Root‑Source‑Origin‑Field‑Constant‑Source meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the fifty‑seventh‑order meta‑layer, contradiction patterns diminish, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source coherence strengthens with stable root‑source‑origin‑field‑constant‑source‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑constant‑source‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Field‑Root‑Source‑Origin‑Field‑Constant‑Source meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the fifty‑seventh‑order meta‑layer, contradiction signals increase, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source coherence declines away from invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Field‑Root‑Source‑Origin‑Field‑Constant‑Source meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the fifty‑seventh‑order meta‑layer, contradiction patterns dominate, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Field‑Root‑Source‑Origin‑Field‑Constant‑Source meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the fifty‑seventh‑order meta‑layer, producing unstable long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source coherence with inconsistent root‑source‑origin‑field‑constant‑source‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑constant‑source‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Field‑Root‑Source‑Origin‑Field‑Constant‑Source meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the fifty‑seventh‑order meta‑layer, producing a flat long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Field‑Root‑Source‑Origin‑Field‑Constant‑Source trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source signal.`;
}