import type { EngineInspectorAutonomyHarmonizationLayer } from "./engineInspectorAutonomyHarmonizationLayer";

export function buildInspectorAutonomyHarmonizationMetaSummary(
  inspectorAutonomyHarmonizationLayer: EngineInspectorAutonomyHarmonizationLayer,
  previousAutonomyHarmonizationLayer?: EngineInspectorAutonomyHarmonizationLayer
): string {
  const current =
    inspectorAutonomyHarmonizationLayer.autonomyHarmonizationLayer;
  const previous =
    previousAutonomyHarmonizationLayer?.autonomyHarmonizationLayer;

  if (!previous) {
    return `The Autonomy Harmonization Layer has produced its first harmonization profile. Cross‑cycle harmonization trends will begin once a second profile is available.`;
  }

  const improving =
    current.harmonizationStrength === "Strong" &&
    previous.harmonizationStrength !== "Strong";

  const degrading =
    current.harmonizationStrength === "Weak" &&
    previous.harmonizationStrength !== "Weak";

  const stable =
    current.harmonizationStrength === previous.harmonizationStrength;

  if (improving) {
    return `Cross‑cycle analysis shows an improvement in autonomy harmonization. Reinforcing signals increased across stability, evolution, and governance, while contradictions decreased. The system demonstrates stronger multi‑tier alignment than in the previous cycle.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows a decline in autonomy harmonization. Contradictions increased across autonomy tiers, and reinforcing signals weakened. The system’s multi‑tier alignment is less cohesive than in the previous cycle.`;
  }

  if (stable) {
    return `Cross‑cycle analysis shows stable autonomy harmonization. Reinforcements and contradictions remain consistent with the previous cycle, and multi‑tier alignment is unchanged.`;
  }

  return `Cross‑cycle harmonization signals are mixed. The system shows partial shifts in alignment that do not clearly indicate improvement or degradation.`;
}