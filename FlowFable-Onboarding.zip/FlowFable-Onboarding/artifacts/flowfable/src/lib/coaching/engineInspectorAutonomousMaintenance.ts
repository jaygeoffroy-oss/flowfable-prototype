import type { EngineInspectorAutonomousStability } from "./engineInspectorAutonomousStability";
import type { EngineInspectorMetaGovernanceIntegrity } from "./engineInspectorMetaGovernanceIntegrity";
import type { EngineInspectorCoherence } from "./engineInspectorCoherence";
import type { EngineInspectorOperationalState } from "./engineInspectorOperationalState";

export type EngineInspectorAutonomousMaintenance = {
  version: string;
  autonomousMaintenance: {
    recommendedActions: string[];
    priority: string;
    rationale: string;
    issues: string[];
  };
};

export function buildInspectorAutonomousMaintenance({
  inspectorAutonomousStability,
  inspectorMetaGovernanceIntegrityReport,
  inspectorCoherenceReport,
  inspectorOperationalState
}: {
  inspectorAutonomousStability: EngineInspectorAutonomousStability;
  inspectorMetaGovernanceIntegrityReport: EngineInspectorMetaGovernanceIntegrity;
  inspectorCoherenceReport: EngineInspectorCoherence;
  inspectorOperationalState: EngineInspectorOperationalState;
}): EngineInspectorAutonomousMaintenance {
  const stability = inspectorAutonomousStability.autonomousStability;
  const metaGovInt =
    inspectorMetaGovernanceIntegrityReport.metaGovernanceIntegrity;
  const coherence = inspectorCoherenceReport.coherence;
  const op = inspectorOperationalState.operationalState;
  const issues = [
    ...stability.issues,
    ...metaGovInt.issues,
    ...coherence.issues
  ];
  const recommendedActions: string[] = [];
  let priority = "Low";
  let rationale = "System stable";

  if (stability.trend === "Degrading") {
    recommendedActions.push(
      "Repair governance-rule inconsistencies",
      "Rebuild coherence model",
      "Recompute operational-state classification"
    );
    priority = "Medium";
    rationale = "Degradation trend detected";
  }

  if (stability.trend === "Critical" || op.state === "Non-Operational") {
    recommendedActions.push(
      "Reset governance model",
      "Regenerate manifest-registry alignment",
      "Rebuild operational-state engine",
      "Trigger full introspection cascade"
    );
    priority = "High";
    rationale = "Critical degradation detected";
  }

  if (issues.length === 0 && recommendedActions.length === 0) {
    recommendedActions.push("No maintenance required");
  }

  return {
    version: inspectorAutonomousStability.version,
    autonomousMaintenance: {
      recommendedActions,
      priority,
      rationale,
      issues
    }
  };
}