export type EngineAdvisory = string[];

export function buildEngineAdvisory({
  engineSummary: _engineSummary,
  engineConsistency,
  engineConfidence,
  parameterDelta
}: {
  engineSummary: Record<string, any>;
  engineConsistency: {
    parameterConsistency: boolean;
    stabilityConsistency: boolean;
    healthConsistency: boolean;
  };
  engineConfidence: { score: number; issues: string[] };
  parameterDelta?: Record<
    string,
    { deltaToNext?: number | null }
  >;
}): EngineAdvisory {
  const advice: string[] = [];

  if (engineConfidence.score < 70) {
    advice.push("Engine confidence is low. Review recent parameter changes.");
  }

  if (!engineConsistency.parameterConsistency) {
    advice.push("Next-run parameters do not fully match current parameters.");
  }

  if (!engineConsistency.stabilityConsistency) {
    advice.push("Engine stability is unknown or degraded.");
  }

  if (!engineConsistency.healthConsistency) {
    advice.push("Engine health is unknown or degraded.");
  }

  if (parameterDelta) {
    const largeChanges = Object.entries(parameterDelta)
      .filter(([, value]) => Math.abs(value.deltaToNext ?? 0) > 0.5)
      .map(([key]) => key);

    if (largeChanges.length > 0) {
      advice.push(
        `Large parameter shifts detected: ${largeChanges.join(", ")}.`
      );
    }
  }

  if (advice.length === 0) {
    advice.push("Engine diagnostics are consistent and healthy.");
  }

  return advice;
}