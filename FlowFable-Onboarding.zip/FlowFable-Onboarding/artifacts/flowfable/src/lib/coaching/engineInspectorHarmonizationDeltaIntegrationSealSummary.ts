import type { EngineInspectorHarmonizationDeltaIntegrationSeal } from "./engineInspectorHarmonizationDeltaIntegrationSeal";

export function buildInspectorHarmonizationDeltaIntegrationSealSummary(
  inspectorHarmonizationDeltaIntegrationSeal: EngineInspectorHarmonizationDeltaIntegrationSeal
): string {
  const s =
    inspectorHarmonizationDeltaIntegrationSeal.harmonizationDeltaIntegrationSeal;

  if (s.seal === "Platinum") {
    return `The unified delta field demonstrates full cross‑system alignment. Autonomy and harmonization deltas reinforce each other completely, contradictions are absent, and the system exhibits maximal delta‑level coherence across cycles.`;
  }

  if (s.seal === "Gold") {
    return `The unified delta field demonstrates strong cross‑system alignment. Reinforcements outweigh contradictions, and autonomy and harmonization deltas evolve in parallel. Minor inconsistencies exist but do not disrupt overall delta coherence.`;
  }

  if (s.seal === "Silver") {
    return `The unified delta field demonstrates partial cross‑system alignment. Autonomy and harmonization deltas show mixed signals, with contradictions reducing unified coherence. Reinforcing signals are present but insufficient for full alignment.`;
  }

  return `The unified delta field is misaligned. Cross‑system contradictions dominate, reinforcing signals are weak or absent, and autonomy and harmonization deltas evolve in conflicting directions. The unified delta trajectory is unstable and requires corrective action.`;
}