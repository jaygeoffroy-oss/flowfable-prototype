export function buildInspectorHyperDeltaFieldEpochIntegrationMetaSummary(
  inspectorHyperDeltaFieldEpochIntegrationSummary: string,
  previousHyperDeltaFieldEpochIntegrationSummary?: string
): string {
  const current = inspectorHyperDeltaFieldEpochIntegrationSummary;
  const previous = previousHyperDeltaFieldEpochIntegrationSummary;

  if (!previous) {
    return `The hyper‑delta epoch meta‑summary has been generated for the first time. Cross‑epoch trends will begin once a second epoch summary is available.`;
  }

  const improving =
    current.includes("strengthening") &&
    !previous.includes("strengthening");

  const degrading =
    current.includes("weakening") &&
    !previous.includes("weakening");

  const critical =
    current.includes("severe") &&
    !previous.includes("severe");

  const stable =
    current.includes("consistent") &&
    previous.includes("consistent");

  const mixed =
    current.includes("inconclusive") &&
    !previous.includes("inconclusive");

  if (improving) {
    return `Cross‑epoch analysis shows strengthening long‑range delta coherence. Reinforcement patterns accumulated across epochs, contradiction patterns diminished, and the merged delta ecosystem trended upward across multi‑epoch evolution.`;
  }

  if (degrading) {
    return `Cross‑epoch analysis shows weakening long‑range delta coherence. Contradiction patterns accumulated across epochs, reinforcement signals declined, and the merged delta ecosystem trended downward across multi‑epoch evolution.`;
  }

  if (critical) {
    return `Cross‑epoch analysis shows severe long‑range delta instability. Persistent contradictions dominated multiple epochs, overwhelming reinforcement signals and destabilizing the merged delta ecosystem. Immediate corrective action is recommended.`;
  }

  if (stable) {
    return `Cross‑epoch analysis shows consistent long‑range delta behavior. Reinforcement and contradiction patterns remained balanced across epochs, producing a stable multi‑epoch trajectory.`;
  }

  if (mixed) {
    return `Cross‑epoch analysis shows mixed long‑range delta behavior. Reinforcement and contradiction patterns shifted unevenly across epochs, producing an ambiguous multi‑epoch trajectory.`;
  }

  return `Cross‑epoch analysis is inconclusive. Long‑range reinforcement and contradiction patterns do not clearly indicate improvement, degradation, or stability across epochs.`;
}