export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantMetaSummary(
  currentFieldConstantSourceRootSourceOriginFieldConstantSummary: string,
  previousFieldConstantSourceRootSourceOriginFieldConstantSummary: string | null
): string {
  if (!previousFieldConstantSourceRootSourceOriginFieldConstantSummary) {
    return `Cross‑hyper‑epoch fifty‑sixth‑order reliability trends cannot yet be determined. A second Field‑Root‑Source‑Origin‑Field‑Constant summary is required to establish long‑range Field‑Root‑Source‑Origin‑Field‑Constant behavior.`;
  }

  const improving =
    currentFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("medium meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("low meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("variable meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Field‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the fifty‑sixth‑order meta‑layer, contradiction patterns diminish, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant coherence strengthens with stable root‑source‑origin‑field‑constant‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑constant‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Field‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the fifty‑sixth‑order meta‑layer, contradiction signals increase, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant coherence declines away from invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Field‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the fifty‑sixth‑order meta‑layer, contradiction patterns dominate, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Field‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the fifty‑sixth‑order meta‑layer, producing unstable long‑range Field‑Root‑Source‑Origin‑Field‑Constant coherence with inconsistent root‑source‑origin‑field‑constant‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑constant‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Field‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the fifty‑sixth‑order meta‑layer, producing a flat long‑range Field‑Root‑Source‑Origin‑Field‑Constant trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Field‑Root‑Source‑Origin‑Field‑Constant trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range Field‑Root‑Source‑Origin‑Field‑Constant signal.`;
}