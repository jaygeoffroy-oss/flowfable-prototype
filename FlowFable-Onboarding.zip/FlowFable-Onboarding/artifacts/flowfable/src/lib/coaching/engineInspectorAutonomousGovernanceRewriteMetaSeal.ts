import type { EngineInspectorAutonomousGovernanceRewriteSeal } from "./engineInspectorAutonomousGovernanceRewriteSeal";

export type EngineInspectorAutonomousGovernanceRewriteMetaSeal = {
  version: string;
  autonomousGovernanceRewriteMetaSeal: {
    cycle: number;
    previousSeal: string | null;
    currentSeal: string;
    metaSeal: string;
    changes: string[];
    issuesTrend: string[];
  };
};

export function buildInspectorAutonomousGovernanceRewriteMetaSeal({
  inspectorAutonomousGovernanceRewriteSeal,
  previousAutonomousGovernanceRewriteSeal,
  cycleNumber
}: {
  inspectorAutonomousGovernanceRewriteSeal: EngineInspectorAutonomousGovernanceRewriteSeal;
  previousAutonomousGovernanceRewriteSeal?: EngineInspectorAutonomousGovernanceRewriteSeal;
  cycleNumber: number;
}): EngineInspectorAutonomousGovernanceRewriteMetaSeal {
  const current =
    inspectorAutonomousGovernanceRewriteSeal.autonomousGovernanceRewriteSeal;
  const previous =
    previousAutonomousGovernanceRewriteSeal?.autonomousGovernanceRewriteSeal;

  let metaSeal = "Stable";
  const changes: string[] = [];
  const issuesTrend: string[] = [];

  if (previous) {
    if (current.seal !== previous.seal) {
      if (current.seal === "Platinum" && previous.seal === "Gold") {
        metaSeal = "Improving";
        changes.push("Governance rewrite readiness improved");
      } else if (current.seal === "Gold" && previous.seal === "Platinum") {
        metaSeal = "Degrading";
        changes.push("Governance rewrite readiness degraded");
      } else if (current.seal === "Red") {
        metaSeal = "Critical";
        changes.push("Governance rewrite readiness collapsed");
      }
    }

    if (current.issues.length > previous.issues.length) {
      issuesTrend.push("Governance issues increasing");
    } else if (current.issues.length < previous.issues.length) {
      issuesTrend.push("Governance issues decreasing");
    } else {
      issuesTrend.push("Governance issues stable");
    }
  }

  return {
    version: inspectorAutonomousGovernanceRewriteSeal.version,
    autonomousGovernanceRewriteMetaSeal: {
      cycle: cycleNumber,
      previousSeal: previous?.seal || null,
      currentSeal: current.seal,
      metaSeal,
      changes,
      issuesTrend
    }
  };
}