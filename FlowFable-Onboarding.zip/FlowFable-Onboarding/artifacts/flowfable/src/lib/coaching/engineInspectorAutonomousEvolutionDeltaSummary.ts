import type { EngineInspectorAutonomousEvolutionDelta } from "./engineInspectorAutonomousEvolutionDelta";

export function buildInspectorAutonomousEvolutionDeltaSummary(
  inspectorAutonomousEvolutionDelta: EngineInspectorAutonomousEvolutionDelta
): string {
  const delta = inspectorAutonomousEvolutionDelta.autonomousEvolutionDelta;

  if (delta.deltaClassification === "Positive") {
    return `The Inspector’s evolutionary trajectory improved this cycle. Evolution readiness increased, stability strengthened, and priority levels decreased. Positive changes include: ${delta.changes.join(", ")}. Pending evolution items remain optional: ${delta.pendingEvolution.join(", ")}.`;
  }

  if (delta.deltaClassification === "Negative") {
    return `The Inspector’s evolutionary trajectory degraded this cycle. Stability weakened or evolution priority increased. Notable changes include: ${delta.changes.join(", ")}. Pending evolution items require attention: ${delta.pendingEvolution.join(", ")}. Regression risks detected: ${delta.regressionRisks.join(", ")}.`;
  }

  if (delta.deltaClassification === "Critical") {
    return `The Inspector’s evolutionary trajectory entered a critical state. Evolution readiness collapsed, and high‑priority interventions are required. Critical changes include: ${delta.changes.join(", ")}. Pending evolution items are mandatory: ${delta.pendingEvolution.join(", ")}. Regression risks are severe: ${delta.regressionRisks.join(", ")}.`;
  }

  return `The Inspector’s evolutionary trajectory remained neutral this cycle. No major changes were detected. Pending evolution items: ${delta.pendingEvolution.join(", ")}.`;
}