import type { EngineConsistencyResult } from "./engineConsistency";

export type EngineConfidenceResult = {
  score: number;
  issues: string[];
};

export function computeEngineConfidence(
  engineConsistency: EngineConsistencyResult
): EngineConfidenceResult {
  let score = 100;

  if (!engineConsistency.parameterConsistency) score -= 20;
  if (!engineConsistency.stabilityConsistency) score -= 20;
  if (!engineConsistency.healthConsistency) score -= 20;
  if (!engineConsistency.historyConsistency) score -= 20;
  if (!engineConsistency.autoTunerConsistency) score -= 10;
  if (!engineConsistency.summaryConsistency) score -= 10;

  return {
    score,
    issues: engineConsistency.issues
  };
}