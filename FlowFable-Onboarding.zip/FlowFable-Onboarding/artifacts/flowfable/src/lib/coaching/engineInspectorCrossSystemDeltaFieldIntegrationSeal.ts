import type { EngineInspectorCrossSystemDeltaFieldIntegration } from "./engineInspectorCrossSystemDeltaFieldIntegration";

export type EngineInspectorCrossSystemDeltaFieldIntegrationSeal = {
  version: string;
  crossSystemDeltaFieldIntegrationSeal: {
    seal: string;
    autonomyDeltaClassification: string;
    harmonizationDeltaClassification: string;
    unifiedTrajectory: string;
    unifiedSeal: string;
    unifiedSealDeltaClassification: string;
    contradictions: string[];
    reinforcements: string[];
    globalTrajectory: string;
  };
};

export function buildInspectorCrossSystemDeltaFieldIntegrationSeal(
  inspectorCrossSystemDeltaFieldIntegration: EngineInspectorCrossSystemDeltaFieldIntegration
): EngineInspectorCrossSystemDeltaFieldIntegrationSeal {
  const f =
    inspectorCrossSystemDeltaFieldIntegration.crossSystemDeltaFieldIntegration;

  const contradictions = f.contradictions.length;
  const reinforcements = f.reinforcements.length;

  let seal = "Silver";

  if (f.globalTrajectory === "Aligned" && contradictions === 0) {
    seal = "Platinum";
  } else if (
    f.globalTrajectory === "Aligned" ||
    reinforcements > contradictions
  ) {
    seal = "Gold";
  } else if (f.globalTrajectory === "Mixed" && contradictions <= 2) {
    seal = "Silver";
  } else {
    seal = "Red";
  }

  return {
    version: inspectorCrossSystemDeltaFieldIntegration.version,
    crossSystemDeltaFieldIntegrationSeal: {
      seal,
      autonomyDeltaClassification: f.autonomyDeltaClassification,
      harmonizationDeltaClassification:
        f.harmonizationDeltaClassification,
      unifiedTrajectory: f.unifiedTrajectory,
      unifiedSeal: f.unifiedSeal,
      unifiedSealDeltaClassification:
        f.unifiedSealDeltaClassification,
      contradictions: f.contradictions,
      reinforcements: f.reinforcements,
      globalTrajectory: f.globalTrajectory
    }
  };
}