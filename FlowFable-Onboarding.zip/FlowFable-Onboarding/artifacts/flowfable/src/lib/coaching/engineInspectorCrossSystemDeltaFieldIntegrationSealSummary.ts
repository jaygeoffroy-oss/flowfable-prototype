import type { EngineInspectorCrossSystemDeltaFieldIntegrationSeal } from "./engineInspectorCrossSystemDeltaFieldIntegrationSeal";

export function buildInspectorCrossSystemDeltaFieldIntegrationSealSummary(
  inspectorCrossSystemDeltaFieldIntegrationSeal: EngineInspectorCrossSystemDeltaFieldIntegrationSeal
): string {
  const s =
    inspectorCrossSystemDeltaFieldIntegrationSeal
      .crossSystemDeltaFieldIntegrationSeal;

  if (s.seal === "Platinum") {
    return `The global delta field demonstrates full cross‑system coherence. Autonomy, harmonization, unified integration, and unified‑seal deltas reinforce each other completely, with no dominant contradictions. This represents maximal global delta alignment.`;
  }

  if (s.seal === "Gold") {
    return `The global delta field demonstrates strong cross‑system coherence. Reinforcing signals outweigh contradictions across autonomy, harmonization, unified integration, and unified‑seal deltas. Minor inconsistencies exist but do not disrupt overall global alignment.`;
  }

  if (s.seal === "Silver") {
    return `The global delta field demonstrates partial cross‑system coherence. Mixed reinforcing and contradictory signals reduce global alignment, producing a moderately stable but imperfect delta ecosystem.`;
  }

  return `The global delta field is misaligned. Contradictions dominate across autonomy, harmonization, unified integration, and unified‑seal deltas, resulting in unstable global delta behavior and weakened cross‑system coherence.`;
}