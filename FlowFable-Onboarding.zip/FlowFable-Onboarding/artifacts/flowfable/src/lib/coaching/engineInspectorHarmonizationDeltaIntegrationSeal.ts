import type { EngineInspectorHarmonizationDeltaIntegration } from "./engineInspectorHarmonizationDeltaIntegration";

export type EngineInspectorHarmonizationDeltaIntegrationSeal = {
  version: string;
  harmonizationDeltaIntegrationSeal: {
    seal: string;
    autonomyDeltaClassification: string;
    harmonizationDeltaClassification: string;
    contradictions: string[];
    reinforcements: string[];
    unifiedTrajectory: string;
  };
};

export function buildInspectorHarmonizationDeltaIntegrationSeal(
  inspectorHarmonizationDeltaIntegration: EngineInspectorHarmonizationDeltaIntegration
): EngineInspectorHarmonizationDeltaIntegrationSeal {
  const i =
    inspectorHarmonizationDeltaIntegration.harmonizationDeltaIntegration;

  const contradictions = i.contradictions.length;
  const reinforcements = i.reinforcements.length;

  let seal = "Silver";

  if (i.unifiedTrajectory === "Aligned" && contradictions === 0) {
    seal = "Platinum";
  } else if (
    i.unifiedTrajectory === "Aligned" ||
    reinforcements > contradictions
  ) {
    seal = "Gold";
  } else if (i.unifiedTrajectory === "Mixed" && contradictions <= 2) {
    seal = "Silver";
  } else {
    seal = "Red";
  }

  return {
    version: inspectorHarmonizationDeltaIntegration.version,
    harmonizationDeltaIntegrationSeal: {
      seal,
      autonomyDeltaClassification: i.autonomyDeltaClassification,
      harmonizationDeltaClassification:
        i.harmonizationDeltaClassification,
      contradictions: i.contradictions,
      reinforcements: i.reinforcements,
      unifiedTrajectory: i.unifiedTrajectory
    }
  };
}