import type { EngineInspectorHyperDeltaFieldEpochIntegration } from "./engineInspectorHyperDeltaFieldEpochIntegration";

export type EngineInspectorHyperDeltaFieldEpochIntegrationSeal = {
  version: string;
  hyperDeltaFieldEpochIntegrationSeal: {
    seal: string;
    epochLength: number;
    epochClassification: string;
    dominantTrajectory: string;
    reinforcingPatterns: string[];
    contradictionPatterns: string[];
    epochSummary: string;
  };
};

export type EngineInspectorHyperDeltaFieldEpochIntegrationHyperSeal = {
  version: string;
  hyperDeltaFieldEpochIntegrationSeal: {
    seal: string;
    rationale: string;
    stability: string;
  };
};

export function buildInspectorHyperDeltaFieldEpochIntegrationSeal(
  inspectorHyperDeltaFieldEpochIntegration: EngineInspectorHyperDeltaFieldEpochIntegration
): EngineInspectorHyperDeltaFieldEpochIntegrationSeal;
export function buildInspectorHyperDeltaFieldEpochIntegrationSeal(
  inspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummarySummary: string
): EngineInspectorHyperDeltaFieldEpochIntegrationHyperSeal;
export function buildInspectorHyperDeltaFieldEpochIntegrationSeal(
  inspectorHyperDeltaFieldEpochIntegration:
    | EngineInspectorHyperDeltaFieldEpochIntegration
    | string
):
  | EngineInspectorHyperDeltaFieldEpochIntegrationSeal
  | EngineInspectorHyperDeltaFieldEpochIntegrationHyperSeal {
  if (typeof inspectorHyperDeltaFieldEpochIntegration === "string") {
    const m = inspectorHyperDeltaFieldEpochIntegration;

    if (m.includes("strong")) {
      return {
        version: "1.0.0",
        hyperDeltaFieldEpochIntegrationSeal: {
          seal: "Hyper‑Gold",
          rationale: "Structural coherence is strong across hyper‑epochs.",
          stability: "High"
        }
      };
    }

    if (m.includes("compromised")) {
      return {
        version: "1.0.0",
        hyperDeltaFieldEpochIntegrationSeal: {
          seal: "Hyper‑Silver",
          rationale:
            "Structural coherence is compromised across hyper‑epochs.",
          stability: "Medium"
        }
      };
    }

    if (m.includes("moderate")) {
      return {
        version: "1.0.0",
        hyperDeltaFieldEpochIntegrationSeal: {
          seal: "Hyper‑Bronze",
          rationale:
            "Structural coherence is moderate and fluctuating across hyper‑epochs.",
          stability: "Variable"
        }
      };
    }

    if (m.includes("collapsed")) {
      return {
        version: "1.0.0",
        hyperDeltaFieldEpochIntegrationSeal: {
          seal: "Hyper‑Red",
          rationale:
            "Structural coherence has collapsed across hyper‑epochs.",
          stability: "Low"
        }
      };
    }

    return {
      version: "1.0.0",
      hyperDeltaFieldEpochIntegrationSeal: {
        seal: "Hyper‑Initial",
        rationale: "First hyper‑epoch; no comparison available.",
        stability: "Unknown"
      }
    };
  }
  const e =
    inspectorHyperDeltaFieldEpochIntegration.hyperDeltaFieldEpochIntegration;

  let seal = "Epoch‑Silver";

  if (
    e.epochClassification === "Improving" &&
    e.dominantTrajectory === "Upward"
  ) {
    seal = "Epoch‑Gold";
  }

  if (
    e.epochClassification === "Stable" &&
    e.dominantTrajectory === "Flat"
  ) {
    seal = "Epoch‑Silver";
  }

  if (
    e.epochClassification === "Degrading" &&
    e.dominantTrajectory === "Downward"
  ) {
    seal = "Epoch‑Bronze";
  }

  if (
    e.epochClassification === "Critical" &&
    e.dominantTrajectory === "Collapse"
  ) {
    seal = "Epoch‑Red";
  }

  return {
    version: inspectorHyperDeltaFieldEpochIntegration.version,
    hyperDeltaFieldEpochIntegrationSeal: {
      seal,
      epochLength: e.epochLength,
      epochClassification: e.epochClassification,
      dominantTrajectory: e.dominantTrajectory,
      reinforcingPatterns: e.reinforcingPatterns,
      contradictionPatterns: e.contradictionPatterns,
      epochSummary: e.epochSummary
    }
  };
}