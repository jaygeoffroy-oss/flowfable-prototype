export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsoluteMetaSummary(
  currentInfinityAbsoluteSummary: string,
  previousInfinityAbsoluteSummary?: string
): string {
  if (!previousInfinityAbsoluteSummary) {
    return `Cross‑hyper‑epoch thirteenth‑order reliability trends cannot yet be determined. A second Infinity‑Absolute summary is required to establish long‑range Infinity‑Absolute behavior.`;
  }

  const improving =
    currentInfinityAbsoluteSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityAbsoluteSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const degrading =
    currentInfinityAbsoluteSummary.includes(
      "medium meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousInfinityAbsoluteSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const collapsing =
    currentInfinityAbsoluteSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityAbsoluteSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const fluctuating =
    currentInfinityAbsoluteSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityAbsoluteSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const stable =
    currentInfinityAbsoluteSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousInfinityAbsoluteSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Infinity‑Absolute meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the thirteenth‑order meta‑layer, contradiction patterns diminish, and long‑range Infinity‑Absolute coherence strengthens with stable absolute‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Infinity‑Absolute meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the thirteenth‑order meta‑layer, contradiction signals increase, and long‑range Infinity‑Absolute coherence declines away from absolute‑invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Infinity‑Absolute meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the thirteenth‑order meta‑layer, contradiction patterns dominate, and long‑range Infinity‑Absolute coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Infinity‑Absolute meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the thirteenth‑order meta‑layer, producing unstable long‑range Infinity‑Absolute coherence with inconsistent absolute‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Infinity‑Absolute meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the thirteenth‑order meta‑layer, producing a flat long‑range Infinity‑Absolute trajectory approaching absolute‑invariant stability.`;
  }

  return `Cross‑hyper‑epoch Infinity‑Absolute trends are inconclusive. Reinforcement and contradiction patterns do not clearly indicate improvement, degradation, collapse, or stability.`;
}