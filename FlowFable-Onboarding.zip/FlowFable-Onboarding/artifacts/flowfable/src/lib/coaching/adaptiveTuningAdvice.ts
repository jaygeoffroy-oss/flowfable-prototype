import type { EngineHealthStatus } from "./engineHealth";
import type { EngineStabilityAnalysis } from "./engineStability";
import type { GuidanceEngineParameters } from "./guidanceEngineParameters";

export type AdaptiveTuningAdvice = {
  summary: string;
  advice: string[];
};

export function buildAdaptiveTuningAdvice({
  engineHealth,
  engineStability,
  params
}: {
  engineHealth: EngineHealthStatus;
  engineStability: EngineStabilityAnalysis;
  params: GuidanceEngineParameters;
}): AdaptiveTuningAdvice {
  const advice: string[] = [];

  if (engineHealth.status === "error") {
    advice.push(
      "System health is in error state — reduce riskWeight and scenarioAggression."
    );
  } else if (engineHealth.status === "warning") {
    advice.push(
      "System health shows warnings — consider mild reductions in riskWeight."
    );
  } else {
    advice.push(
      "System health is good — tuning can safely explore moderate adjustments."
    );
  }

  if (engineStability.stability === "unstable") {
    advice.push(
      "Parameters are unstable — freeze synergyWeight and confidenceSmoothing for a few runs."
    );
  } else if (engineStability.stability === "stable") {
    advice.push(
      "Parameters are stable — you can experiment with small synergyWeight increases."
    );
  } else {
    advice.push(
      "Insufficient history — keep changes small until more data is available."
    );
  }

  if (params.riskWeight > 1.3) {
    advice.push(
      "RiskWeight is high — consider shifting categoryBias toward stability."
    );
  }
  if (params.scenarioAggression > 1.3) {
    advice.push(
      "ScenarioAggression is high — reduce aggression if confidence drops in future runs."
    );
  }

  return {
    summary: advice[0],
    advice
  };
}