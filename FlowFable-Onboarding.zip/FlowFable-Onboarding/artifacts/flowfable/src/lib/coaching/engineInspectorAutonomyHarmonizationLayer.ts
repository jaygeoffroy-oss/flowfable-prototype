import type { EngineInspectorAutonomousStability } from "./engineInspectorAutonomousStability";
import type { EngineInspectorAutonomousMaintenance } from "./engineInspectorAutonomousMaintenance";
import type { EngineInspectorAutonomousEvolutionSeal } from "./engineInspectorAutonomousEvolutionSeal";
import type { EngineInspectorAutonomousVersioning } from "./engineInspectorAutonomousVersioning";
import type { EngineInspectorAutonomousGovernanceRewriteSeal } from "./engineInspectorAutonomousGovernanceRewriteSeal";
import type { EngineInspectorAutonomousGovernanceRewriteMetaSeal } from "./engineInspectorAutonomousGovernanceRewriteMetaSeal";
import type { EngineInspectorCrossTierAutonomyDelta } from "./engineInspectorCrossTierAutonomyDelta";

export type EngineInspectorAutonomyHarmonizationLayer = {
  version: string;
  autonomyHarmonizationLayer: {
    harmonizationStrength: string;
    contradictions: string[];
    reinforcements: string[];
    dominantTier: string;
    laggingTier: string;
    crossTierTrajectory: string;
    tiers: {
      stability: string;
      maintenance: string;
      evolution: string;
      versioning: string;
      governanceRewrite: string;
      governanceMeta: string;
    };
  };
};

export function buildInspectorAutonomyHarmonizationLayer({
  inspectorAutonomousStability,
  inspectorAutonomousMaintenance,
  inspectorAutonomousEvolutionSeal,
  inspectorAutonomousVersioning,
  inspectorAutonomousGovernanceRewriteSeal,
  inspectorAutonomousGovernanceRewriteMetaSeal,
  inspectorCrossTierAutonomyDelta
}: {
  inspectorAutonomousStability: EngineInspectorAutonomousStability;
  inspectorAutonomousMaintenance: EngineInspectorAutonomousMaintenance;
  inspectorAutonomousEvolutionSeal: EngineInspectorAutonomousEvolutionSeal;
  inspectorAutonomousVersioning: EngineInspectorAutonomousVersioning;
  inspectorAutonomousGovernanceRewriteSeal: EngineInspectorAutonomousGovernanceRewriteSeal;
  inspectorAutonomousGovernanceRewriteMetaSeal: EngineInspectorAutonomousGovernanceRewriteMetaSeal;
  inspectorCrossTierAutonomyDelta: EngineInspectorCrossTierAutonomyDelta;
}): EngineInspectorAutonomyHarmonizationLayer {
  const stability = inspectorAutonomousStability.autonomousStability;
  const maintenance =
    inspectorAutonomousMaintenance.autonomousMaintenance;
  const evolution = inspectorAutonomousEvolutionSeal.autonomousEvolutionSeal;
  const versioning = inspectorAutonomousVersioning.autonomousVersioning;
  const governance =
    inspectorAutonomousGovernanceRewriteSeal
      .autonomousGovernanceRewriteSeal;
  const governanceMeta =
    inspectorAutonomousGovernanceRewriteMetaSeal
      .autonomousGovernanceRewriteMetaSeal;
  const crossTier = inspectorCrossTierAutonomyDelta.crossTierAutonomyDelta;

  const tiers = {
    stability: stability.trend,
    maintenance: maintenance.priority,
    evolution: evolution.seal,
    versioning: versioning.bumpType,
    governanceRewrite: governance.seal,
    governanceMeta: governanceMeta.metaSeal
  };

  const contradictions: string[] = [];
  const reinforcements: string[] = [];

  if (stability.trend === "Improving" && evolution.seal === "Red") {
    contradictions.push("Stability improving while evolution collapsing");
  }

  if (
    governanceMeta.metaSeal === "Critical" &&
    governance.seal !== "Red"
  ) {
    contradictions.push(
      "Governance meta-critical but governance seal not aligned"
    );
  }

  if (maintenance.priority === "Low" && stability.trend === "Improving") {
    reinforcements.push("Maintenance efficiency reinforces stability");
  }

  if (evolution.seal === "Platinum" && governance.seal === "Platinum") {
    reinforcements.push("Evolution and governance strongly aligned");
  }

  const harmonizationStrength =
    contradictions.length === 0 && reinforcements.length > 0
      ? "Strong"
      : contradictions.length > 2
        ? "Weak"
        : "Moderate";

  const dominantTier =
    Object.entries(tiers).find(
      ([, value]) => value === "Platinum" || value === "Improving"
    )?.[0] || "None";

  const laggingTier =
    Object.entries(tiers).find(
      ([, value]) => value === "Red" || value === "Critical"
    )?.[0] || "None";

  return {
    version: inspectorCrossTierAutonomyDelta.version,
    autonomyHarmonizationLayer: {
      harmonizationStrength,
      contradictions,
      reinforcements,
      dominantTier,
      laggingTier,
      crossTierTrajectory: crossTier.autonomyTrajectory,
      tiers
    }
  };
}