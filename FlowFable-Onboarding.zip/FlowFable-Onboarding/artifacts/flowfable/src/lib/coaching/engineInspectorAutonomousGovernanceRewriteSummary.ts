import type { EngineInspectorAutonomousGovernanceRewrite } from "./engineInspectorAutonomousGovernanceRewrite";

export function buildInspectorAutonomousGovernanceRewriteSummary(
  inspectorAutonomousGovernanceRewrite: EngineInspectorAutonomousGovernanceRewrite
): string {
  const g =
    inspectorAutonomousGovernanceRewrite.autonomousGovernanceRewrite;

  if (g.priority === "Low") {
    return `The Inspector’s governance model remains stable. Rewrite actions are optional and focus on proactive enhancements such as governance drift detection and redundancy checks. No significant governance risks were detected.`;
  }

  if (g.priority === "Medium") {
    return `The Inspector’s governance model shows signs of degradation. Rewrite actions include repairing rule inconsistencies and rebuilding extension rules. These updates aim to restore governance alignment and prevent future instability. Issues requiring attention: ${g.issues.join(", ")}.`;
  }

  return `The Inspector’s governance model requires critical intervention. Rewrite actions include regenerating the governance-rule hierarchy, introducing adaptive thresholds, and rewriting extension-resilience rules. These changes are essential to restore governance integrity. Issues detected: ${g.issues.join(", ")}.`;
}