import { assessEngineHealth } from "./engineHealthMonitorEngine";
import { runEngineSelfRecovery } from "./engineSelfRecoveryEngine";
import { applyEngineParameters } from "./engineParameterApplication";

export type EngineControlLoopResult = {
  health: {
    status: "healthy" | "warning" | "error";
    issues: string[];
  };
  recoveredFlow: any;
};

export function runEngineControlLoop(flow: any): EngineControlLoopResult {
  const health = assessEngineHealth(flow);
  let recoveredFlow = flow;

  if (health.status !== "healthy") {
    recoveredFlow = runEngineSelfRecovery(flow);
    recoveredFlow = applyEngineParameters(recoveredFlow);
  }

  return {
    health,
    recoveredFlow
  };
}