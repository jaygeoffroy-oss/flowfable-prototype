export function buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummarySummary(
  inspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummary: string
): string {
  const m =
    inspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummary;

  if (m.includes("strengthening")) {
    return `Hyper‑epoch delta‑engine evolution is strengthening. Reinforcement patterns increased across hyper‑epochs, contradiction patterns diminished, and the system exhibits a sustained upward long‑range structural trajectory.`;
  }

  if (m.includes("weakening")) {
    return `Hyper‑epoch delta‑engine evolution is weakening. Reinforcement signals faded across hyper‑epochs, contradiction patterns increased, and the system exhibits a sustained downward long‑range structural trajectory.`;
  }

  if (m.includes("collapse‑direction")) {
    return `Hyper‑epoch delta‑engine evolution is collapse‑direction. Structural coherence failed across hyper‑epochs, contradiction patterns dominated, and the system exhibits collapse‑level long‑range structural behavior. Immediate corrective action is recommended.`;
  }

  if (m.includes("oscillating")) {
    return `Hyper‑epoch delta‑engine evolution is oscillating. Reinforcement and contradiction patterns fluctuated unevenly across hyper‑epochs, producing no consistent long‑range structural trajectory.`;
  }

  if (m.includes("stable")) {
    return `Hyper‑epoch delta‑engine evolution is stable. Reinforcement and contradiction patterns remained balanced across hyper‑epochs, producing a flat long‑range structural trajectory.`;
  }

  return `Hyper‑epoch delta‑engine evolution is inconclusive. Additional hyper‑epochs are required to determine a clear long‑range structural trend.`;
}