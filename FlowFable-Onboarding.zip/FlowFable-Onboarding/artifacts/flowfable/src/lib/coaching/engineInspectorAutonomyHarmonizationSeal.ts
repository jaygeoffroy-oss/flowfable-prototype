import type { EngineInspectorAutonomyHarmonizationLayer } from "./engineInspectorAutonomyHarmonizationLayer";

export type EngineInspectorAutonomyHarmonizationSeal = {
  version: string;
  autonomyHarmonizationSeal: {
    seal: string;
    harmonizationStrength: string;
    contradictions: string[];
    reinforcements: string[];
    dominantTier: string;
    laggingTier: string;
    crossTierTrajectory: string;
  };
};

export function buildInspectorAutonomyHarmonizationSeal(
  inspectorAutonomyHarmonizationLayer: EngineInspectorAutonomyHarmonizationLayer
): EngineInspectorAutonomyHarmonizationSeal {
  const h =
    inspectorAutonomyHarmonizationLayer.autonomyHarmonizationLayer;

  let seal = "Silver";

  const strong = h.harmonizationStrength === "Strong";
  const moderate = h.harmonizationStrength === "Moderate";
  const weak = h.harmonizationStrength === "Weak";

  const contradictions = h.contradictions.length;
  const reinforcements = h.reinforcements.length;
  void reinforcements;

  if (strong && contradictions === 0) {
    seal = "Platinum";
  } else if (strong || moderate) {
    seal = "Gold";
  } else if (weak && contradictions <= 2) {
    seal = "Silver";
  } else {
    seal = "Red";
  }

  return {
    version: inspectorAutonomyHarmonizationLayer.version,
    autonomyHarmonizationSeal: {
      seal,
      harmonizationStrength: h.harmonizationStrength,
      contradictions: h.contradictions,
      reinforcements: h.reinforcements,
      dominantTier: h.dominantTier,
      laggingTier: h.laggingTier,
      crossTierTrajectory: h.crossTierTrajectory
    }
  };
}