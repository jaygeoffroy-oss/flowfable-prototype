import type { EngineInspectorAutonomyHarmonizationSeal } from "./engineInspectorAutonomyHarmonizationSeal";

export type EngineInspectorAutonomyHarmonizationSealDelta = {
  version: string;
  autonomyHarmonizationSealDelta: {
    previousSeal: string | null;
    currentSeal: string;
    deltaClassification: string;
    contributingFactors: string[];
    trajectory: string;
  };
};

export function buildInspectorAutonomyHarmonizationSealDelta(
  inspectorAutonomyHarmonizationSeal: EngineInspectorAutonomyHarmonizationSeal,
  previousAutonomyHarmonizationSeal?: EngineInspectorAutonomyHarmonizationSeal
): EngineInspectorAutonomyHarmonizationSealDelta {
  const current =
    inspectorAutonomyHarmonizationSeal.autonomyHarmonizationSeal;
  const previous =
    previousAutonomyHarmonizationSeal?.autonomyHarmonizationSeal;

  if (!previous) {
    return {
      version: inspectorAutonomyHarmonizationSeal.version,
      autonomyHarmonizationSealDelta: {
        previousSeal: null,
        currentSeal: current.seal,
        deltaClassification: "Initial",
        contributingFactors: [],
        trajectory: "Stable"
      }
    };
  }

  let deltaClassification = "Stable";
  const contributingFactors: string[] = [];

  if (current.seal !== previous.seal) {
    if (current.seal === "Platinum") {
      deltaClassification = "Improving";
      contributingFactors.push("Full cross‑tier alignment achieved");
    } else if (current.seal === "Gold" && previous.seal === "Silver") {
      deltaClassification = "Improving";
      contributingFactors.push(
        "Reinforcements increased",
        "Contradictions reduced"
      );
    } else if (current.seal === "Silver" && previous.seal === "Gold") {
      deltaClassification = "Degrading";
      contributingFactors.push("Contradictions increased");
    } else if (current.seal === "Red") {
      deltaClassification = "Critical";
      contributingFactors.push("Severe cross‑tier misalignment");
    }
  }

  const trajectory =
    deltaClassification === "Improving"
      ? "Upward"
      : deltaClassification === "Degrading"
        ? "Downward"
        : deltaClassification === "Critical"
          ? "Critical"
          : "Stable";

  return {
    version: inspectorAutonomyHarmonizationSeal.version,
    autonomyHarmonizationSealDelta: {
      previousSeal: previous?.seal || null,
      currentSeal: current.seal,
      deltaClassification,
      contributingFactors,
      trajectory
    }
  };
}