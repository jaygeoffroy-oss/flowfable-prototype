import type { EngineParameterSnapshot } from "./engineParameterSnapshotLogger";

const STORAGE_KEY = "flowfable_engine_history";

export function loadEngineHistory(): EngineParameterSnapshot[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];

    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as EngineParameterSnapshot[]) : [];
  } catch {
    return [];
  }
}

export function saveEngineHistory(
  history: EngineParameterSnapshot[]
): void {
  if (typeof window === "undefined") return;

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
  } catch {
    // Storage may be unavailable in restricted browser contexts.
  }
}