import type { EngineInspectorHarmonizationDeltaIntegrationSeal } from "./engineInspectorHarmonizationDeltaIntegrationSeal";

export function buildInspectorHarmonizationDeltaIntegrationSealMetaSummary(
  inspectorHarmonizationDeltaIntegrationSeal: EngineInspectorHarmonizationDeltaIntegrationSeal,
  previousHarmonizationDeltaIntegrationSeal?: EngineInspectorHarmonizationDeltaIntegrationSeal
): string {
  const current =
    inspectorHarmonizationDeltaIntegrationSeal.harmonizationDeltaIntegrationSeal;
  const previous =
    previousHarmonizationDeltaIntegrationSeal?.harmonizationDeltaIntegrationSeal;

  if (!previous) {
    return `The unified delta seal has been generated for the first time. Cross‑cycle unified delta trends will begin once a second seal is available.`;
  }

  const improving =
    current.seal === "Platinum" &&
    previous.seal !== "Platinum";

  const strengthening =
    current.seal === "Gold" &&
    previous.seal === "Silver";

  const weakening =
    current.seal === "Silver" &&
    previous.seal === "Gold";

  const degrading =
    current.seal === "Red" &&
    previous.seal !== "Red";

  const stable =
    current.seal === previous.seal;

  if (improving) {
    return `Cross‑cycle analysis shows a major improvement in unified delta alignment. Autonomy and harmonization deltas now reinforce each other completely, resolving prior contradictions and producing a fully aligned cross‑system delta field.`;
  }

  if (strengthening) {
    return `Cross‑cycle analysis shows strengthening unified delta alignment. The seal improved from Silver to Gold, indicating reduced contradictions and stronger reinforcement between autonomy and harmonization deltas.`;
  }

  if (weakening) {
    return `Cross‑cycle analysis shows weakening unified delta alignment. The seal declined from Gold to Silver, reflecting increased contradictions or reduced reinforcement across the merged delta field.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows severe unified delta degradation. The system entered a Red state, indicating dominant contradictions and unstable cross‑system delta behavior. Immediate corrective action is recommended.`;
  }

  if (stable) {
    return `Cross‑cycle unified delta alignment remains stable. The seal classification is unchanged, and autonomy and harmonization deltas continue to evolve consistently across cycles.`;
  }

  return `Cross‑cycle unified delta signals are mixed. Partial shifts in autonomy and harmonization deltas do not clearly indicate improvement or degradation.`;
}