export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldMetaSummary(
  currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary: string,
  previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary: string | null
): string {
  if (!previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary) {
    return `Cross‑hyper‑epoch sixty‑first‑order reliability trends cannot yet be determined. A second Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field summary is required to establish long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field behavior.`;
  }

  const improving =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("medium meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("low meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("variable meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement patterns stabilize at the sixty‑first‑order meta‑layer, contradiction patterns diminish, and long‑range coherence strengthens with stable root‑source‑origin‑field‑constant‑source‑root‑source‑origin‑field‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement patterns weaken at the sixty‑first‑order meta‑layer, contradiction signals increase, and long‑range coherence declines away from invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field meta‑meta‑meta‑…‑reliability. Structural coherence fails at the sixty‑first‑order meta‑layer, contradiction patterns dominate, and long‑range coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns oscillate at the sixty‑first‑order meta‑layer, producing unstable long‑range coherence with inconsistent invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns remain balanced at the sixty‑first‑order meta‑layer, producing a flat long‑range trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range signal.`;
}