export function buildInspectorHarmonizationDeltaIntegrationSealDeltaEngineMetaSummary(
  inspectorHarmonizationDeltaIntegrationSealDeltaEngineSummary: string,
  previousHarmonizationDeltaIntegrationSealDeltaEngineSummary?: string
): string {
  const current =
    inspectorHarmonizationDeltaIntegrationSealDeltaEngineSummary;
  const previous =
    previousHarmonizationDeltaIntegrationSealDeltaEngineSummary;

  if (!previous) {
    return `The Global Delta Seal Delta Engine has produced its first meta‑summary. Cross‑cycle global‑engine trends will begin once a second meta‑summary is available.`;
  }

  const improving =
    current.includes("improving") &&
    !previous.includes("improving");

  const degrading =
    current.includes("degrading") &&
    !previous.includes("degrading");

  const critical =
    current.includes("critical") &&
    !previous.includes("critical");

  const stable =
    current === previous;

  if (improving) {
    return `Cross‑cycle analysis shows the global‑seal delta engine is strengthening. Reinforcement signals across autonomy, harmonization, unified integration, and unified‑seal deltas have increased, contradictions have decreased, and global delta coherence is improving across cycles.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows the global‑seal delta engine is weakening. Contradictions across the merged delta ecosystem have increased, reinforcement signals have declined, and global delta coherence is degrading across cycles.`;
  }

  if (critical) {
    return `Cross‑cycle analysis shows the global‑seal delta engine has entered a critical state. Severe cross‑system misalignment dominates global delta behavior, destabilizing the merged autonomy‑harmonization‑unified delta field. Immediate corrective action is recommended.`;
  }

  if (stable) {
    return `Cross‑cycle global‑seal delta engine behavior remains stable. The engine’s interpretation of global delta coherence is unchanged, indicating consistent cross‑system evolution.`;
  }

  return `Cross‑cycle global‑seal delta engine signals are mixed. Partial shifts across the merged delta ecosystem do not clearly indicate improvement or degradation.`;
}