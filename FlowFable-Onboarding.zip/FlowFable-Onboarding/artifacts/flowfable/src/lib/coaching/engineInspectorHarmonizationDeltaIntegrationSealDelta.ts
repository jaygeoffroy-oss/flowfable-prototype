import type { EngineInspectorHarmonizationDeltaIntegrationSeal } from "./engineInspectorHarmonizationDeltaIntegrationSeal";

export type EngineInspectorHarmonizationDeltaIntegrationSealDelta = {
  version: string;
  harmonizationDeltaIntegrationSealDelta: {
    previousSeal: string | null;
    currentSeal: string;
    deltaClassification: string;
    contributingFactors: string[];
    trajectory: string;
  };
};

export function buildInspectorHarmonizationDeltaIntegrationSealDelta(
  inspectorHarmonizationDeltaIntegrationSeal: EngineInspectorHarmonizationDeltaIntegrationSeal,
  previousHarmonizationDeltaIntegrationSeal?: EngineInspectorHarmonizationDeltaIntegrationSeal
): EngineInspectorHarmonizationDeltaIntegrationSealDelta {
  const current =
    inspectorHarmonizationDeltaIntegrationSeal.harmonizationDeltaIntegrationSeal;
  const previous =
    previousHarmonizationDeltaIntegrationSeal?.harmonizationDeltaIntegrationSeal;

  if (!previous) {
    return {
      version: inspectorHarmonizationDeltaIntegrationSeal.version,
      harmonizationDeltaIntegrationSealDelta: {
        previousSeal: null,
        currentSeal: current.seal,
        deltaClassification: "Initial",
        contributingFactors: [],
        trajectory: "Stable"
      }
    };
  }

  let deltaClassification = "Stable";
  const contributingFactors: string[] = [];

  if (current.seal !== previous.seal) {
    if (current.seal === "Platinum") {
      deltaClassification = "Improving";
      contributingFactors.push("Full unified delta alignment achieved");
    } else if (current.seal === "Gold" && previous.seal === "Silver") {
      deltaClassification = "Improving";
      contributingFactors.push(
        "Cross‑system reinforcements increased",
        "Cross‑system contradictions reduced"
      );
    } else if (current.seal === "Silver" && previous.seal === "Gold") {
      deltaClassification = "Degrading";
      contributingFactors.push("Increased cross‑system contradictions");
    } else if (current.seal === "Red") {
      deltaClassification = "Critical";
      contributingFactors.push("Severe unified delta misalignment");
    }
  }

  const trajectory =
    deltaClassification === "Improving"
      ? "Upward"
      : deltaClassification === "Degrading"
        ? "Downward"
        : deltaClassification === "Critical"
          ? "Critical"
          : "Stable";

  return {
    version: inspectorHarmonizationDeltaIntegrationSeal.version,
    harmonizationDeltaIntegrationSealDelta: {
      previousSeal: previous.seal,
      currentSeal: current.seal,
      deltaClassification,
      contributingFactors,
      trajectory
    }
  };
}