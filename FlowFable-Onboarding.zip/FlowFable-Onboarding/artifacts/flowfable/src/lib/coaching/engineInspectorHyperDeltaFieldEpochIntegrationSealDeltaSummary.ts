import type {
  EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta,
  EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta
} from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDelta";

type HyperDeltaFieldEpochIntegrationSealDelta =
  | EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta
  | EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta;

export function buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaSummary(
  inspectorHyperDeltaFieldEpochIntegrationSealDelta: HyperDeltaFieldEpochIntegrationSealDelta
): string {
  const d =
    inspectorHyperDeltaFieldEpochIntegrationSealDelta
      .hyperDeltaFieldEpochIntegrationSealDelta;

  if (d.deltaClassification === "Improving") {
    return `The hyper‑epoch seal strengthened across hyper‑epochs. Structural coherence increased, reinforcement patterns intensified, and contradiction patterns diminished, producing an upward long‑range trajectory.`;
  }

  if (d.deltaClassification === "Degrading") {
    return `The hyper‑epoch seal weakened across hyper‑epochs. Structural coherence declined, reinforcement signals faded, and contradiction patterns increased, producing a downward long‑range trajectory.`;
  }

  if (d.deltaClassification === "Critical") {
    return `The hyper‑epoch seal entered a collapse‑level state. Structural coherence failed across hyper‑epochs, contradiction patterns dominated, and the system exhibited collapse‑direction long‑range behavior. Immediate corrective action is recommended.`;
  }

  if (d.deltaClassification === "Mixed") {
    return `The hyper‑epoch seal fluctuated unevenly across hyper‑epochs. Structural coherence oscillated between moderate and unstable states, producing an inconsistent long‑range trajectory.`;
  }

  if (d.deltaClassification === "Initial") {
    return `This is the first hyper‑epoch seal delta. Long‑range structural trends will emerge once additional hyper‑epochs are available for comparison.`;
  }

  return `The hyper‑epoch seal remained stable across hyper‑epochs. Reinforcement and contradiction patterns balanced out, producing a flat long‑range trajectory.`;
}