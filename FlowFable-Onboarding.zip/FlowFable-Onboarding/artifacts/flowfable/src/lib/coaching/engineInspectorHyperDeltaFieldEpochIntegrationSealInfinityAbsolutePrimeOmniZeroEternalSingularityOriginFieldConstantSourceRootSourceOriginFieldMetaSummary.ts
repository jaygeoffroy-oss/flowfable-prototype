export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldMetaSummary(
  currentFieldConstantSourceRootSourceOriginFieldSummary: string,
  previousFieldConstantSourceRootSourceOriginFieldSummary: string | null
): string {
  if (!previousFieldConstantSourceRootSourceOriginFieldSummary) {
    return `Cross‑hyper‑epoch fifty‑fifth‑order reliability trends cannot yet be determined. A second Field‑Root‑Source‑Origin‑Field summary is required to establish long‑range Field‑Root‑Source‑Origin‑Field behavior.`;
  }

  const improving =
    currentFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentFieldConstantSourceRootSourceOriginFieldSummary.includes("medium meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentFieldConstantSourceRootSourceOriginFieldSummary.includes("low meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentFieldConstantSourceRootSourceOriginFieldSummary.includes("variable meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Field‑Root‑Source‑Origin‑Field meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the fifty‑fifth‑order meta‑layer, contradiction patterns diminish, and long‑range Field‑Root‑Source‑Origin‑Field coherence strengthens with stable root‑source‑origin‑field‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Field‑Root‑Source‑Origin‑Field meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the fifty‑fifth‑order meta‑layer, contradiction signals increase, and long‑range Field‑Root‑Source‑Origin‑Field coherence declines away from invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Field‑Root‑Source‑Origin‑Field meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the fifty‑fifth‑order meta‑layer, contradiction patterns dominate, and long‑range Field‑Root‑Source‑Origin‑Field coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Field‑Root‑Source‑Origin‑Field meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the fifty‑fifth‑order meta‑layer, producing unstable long‑range Field‑Root‑Source‑Origin‑Field coherence with inconsistent root‑source‑origin‑field‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Field‑Root‑Source‑Origin‑Field meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the fifty‑fifth‑order meta‑layer, producing a flat long‑range Field‑Root‑Source‑Origin‑Field trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Field‑Root‑Source‑Origin‑Field trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range Field‑Root‑Source‑Origin‑Field signal.`;
}