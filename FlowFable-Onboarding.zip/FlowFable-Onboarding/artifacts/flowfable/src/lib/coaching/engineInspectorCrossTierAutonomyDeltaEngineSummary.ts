import type { EngineInspectorCrossTierAutonomyDelta } from "./engineInspectorCrossTierAutonomyDelta";

export function buildInspectorCrossTierAutonomyDeltaEngineSummary(
  inspectorCrossTierAutonomyDelta: EngineInspectorCrossTierAutonomyDelta
): string {
  const delta = inspectorCrossTierAutonomyDelta.crossTierAutonomyDelta;

  const classification = delta.deltaClassification;
  const trajectory = delta.autonomyTrajectory;
  void trajectory;

  if (classification === "Improving") {
    return `The Cross‑Tier Autonomy Delta Engine reports an improving global autonomy trajectory. Cross‑tier synthesis shows upward movement across stability, maintenance, evolution, versioning, and governance layers. The system demonstrates strong resilience and positive multi‑tier alignment.`;
  }

  if (classification === "Degrading") {
    return `The Cross‑Tier Autonomy Delta Engine reports a degrading global autonomy trajectory. Cross‑tier synthesis indicates weakening signals across multiple autonomy layers. The system requires attention to prevent further decline and restore multi‑tier alignment.`;
  }

  if (classification === "Critical") {
    return `The Cross‑Tier Autonomy Delta Engine reports a critical global autonomy trajectory. Severe degradation across multiple autonomy layers requires immediate intervention. Cross‑tier risks outweigh improvements, and the system’s autonomous integrity is compromised.`;
  }

  return `The Cross‑Tier Autonomy Delta Engine reports a stable global autonomy trajectory. Cross‑tier synthesis shows no major changes across autonomy layers. The system remains balanced with minor fluctuations that do not affect overall alignment.`;
}