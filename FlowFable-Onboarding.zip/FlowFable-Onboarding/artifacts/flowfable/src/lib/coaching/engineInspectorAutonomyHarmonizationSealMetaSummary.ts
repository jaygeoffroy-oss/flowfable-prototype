import type { EngineInspectorAutonomyHarmonizationSeal } from "./engineInspectorAutonomyHarmonizationSeal";

export function buildInspectorAutonomyHarmonizationSealMetaSummary(
  inspectorAutonomyHarmonizationSeal: EngineInspectorAutonomyHarmonizationSeal,
  previousAutonomyHarmonizationSeal?: EngineInspectorAutonomyHarmonizationSeal
): string {
  const current =
    inspectorAutonomyHarmonizationSeal.autonomyHarmonizationSeal;
  const previous =
    previousAutonomyHarmonizationSeal?.autonomyHarmonizationSeal;

  if (!previous) {
    return `The Autonomy Harmonization Seal has been generated for the first time. Cross‑cycle seal trends will begin once a second seal is available.`;
  }

  const improving =
    current.seal === "Platinum" &&
    previous.seal !== "Platinum";

  const degrading =
    current.seal === "Red" &&
    previous.seal !== "Red";

  const strengthening =
    current.seal === "Gold" &&
    previous.seal === "Silver";

  const weakening =
    current.seal === "Silver" &&
    previous.seal === "Gold";

  if (improving) {
    return `Cross‑cycle analysis shows a major improvement in harmonization. The system advanced to Platinum, indicating full cross‑tier alignment and the resolution of prior contradictions.`;
  }

  if (strengthening) {
    return `Cross‑cycle analysis shows strengthening harmonization. The seal improved from Silver to Gold, reflecting reduced contradictions and stronger multi‑tier reinforcement.`;
  }

  if (weakening) {
    return `Cross‑cycle analysis shows weakening harmonization. The seal declined from Gold to Silver, indicating increased contradictions or reduced reinforcement across autonomy tiers.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows severe harmonization degradation. The system entered a Red state, indicating dominant contradictions and unstable cross‑tier alignment. Immediate corrective action is recommended.`;
  }

  return `Cross‑cycle harmonization remains stable. The seal classification is unchanged, and cross‑tier alignment trends are consistent with the previous cycle.`;
}