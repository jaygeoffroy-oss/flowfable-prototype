import type { EngineInspectorAutonomyHarmonizationSealDelta } from "./engineInspectorAutonomyHarmonizationSealDelta";

export function buildInspectorAutonomyHarmonizationSealDeltaSummary(
  inspectorAutonomyHarmonizationSealDelta: EngineInspectorAutonomyHarmonizationSealDelta
): string {
  const d =
    inspectorAutonomyHarmonizationSealDelta.autonomyHarmonizationSealDelta;

  if (d.deltaClassification === "Improving") {
    return `The harmonization seal improved this cycle, indicating stronger cross‑tier alignment and reduced contradictions. Reinforcing signals increased across autonomy tiers, contributing to an upward harmonization trajectory.`;
  }

  if (d.deltaClassification === "Degrading") {
    return `The harmonization seal degraded this cycle, reflecting increased contradictions or weakened reinforcement across autonomy tiers. Cross‑tier alignment declined, resulting in a downward harmonization trajectory.`;
  }

  if (d.deltaClassification === "Critical") {
    return `The harmonization seal entered a critical state. Severe cross‑tier misalignment and dominant contradictions destabilized the harmonized autonomy field. Immediate corrective action is recommended to restore alignment.`;
  }

  if (d.deltaClassification === "Initial") {
    return `This is the first harmonization seal delta. Cross‑cycle trends will begin once additional cycles are available for comparison.`;
  }

  return `The harmonization seal remained stable this cycle. Cross‑tier alignment did not significantly change, and the harmonized autonomy field maintained its previous trajectory.`;
}