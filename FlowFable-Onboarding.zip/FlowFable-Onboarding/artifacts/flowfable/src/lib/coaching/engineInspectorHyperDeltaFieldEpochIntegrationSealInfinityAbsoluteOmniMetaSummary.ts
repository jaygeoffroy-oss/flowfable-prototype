export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsoluteOmniMetaSummary(
  currentInfinityAbsoluteOmniSummary: string,
  previousInfinityAbsoluteOmniSummary?: string
): string {
  if (!previousInfinityAbsoluteOmniSummary) {
    return `Cross‑hyper‑epoch thirty‑third‑order reliability trends cannot yet be determined. A second Infinity‑Absolute‑Omni summary is required to establish long‑range Infinity‑Absolute‑Omni behavior.`;
  }

  const improving =
    currentInfinityAbsoluteOmniSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityAbsoluteOmniSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const degrading =
    currentInfinityAbsoluteOmniSummary.includes(
      "medium meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousInfinityAbsoluteOmniSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const collapsing =
    currentInfinityAbsoluteOmniSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityAbsoluteOmniSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const fluctuating =
    currentInfinityAbsoluteOmniSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousInfinityAbsoluteOmniSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const stable =
    currentInfinityAbsoluteOmniSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousInfinityAbsoluteOmniSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability"
    );

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Infinity‑Absolute‑Omni meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the thirty‑third‑order meta‑layer, contradiction patterns diminish, and long‑range Infinity‑Absolute‑Omni coherence strengthens with stable omni‑absolute‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Infinity‑Absolute‑Omni meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the thirty‑third‑order meta‑layer, contradiction signals increase, and long‑range Infinity‑Absolute‑Omni coherence declines away from omni‑absolute‑invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Infinity‑Absolute‑Omni meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the thirty‑third‑order meta‑layer, contradiction patterns dominate, and long‑range Infinity‑Absolute‑Omni coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Infinity‑Absolute‑Omni meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the thirty‑third‑order meta‑layer, producing unstable long‑range Infinity‑Absolute‑Omni coherence with inconsistent omni‑absolute‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Infinity‑Absolute‑Omni meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the thirty‑third‑order meta‑layer, producing a flat long‑range Infinity‑Absolute‑Omni trajectory approaching omni‑absolute‑invariant stability.`;
  }

  return `Cross‑hyper‑epoch Infinity‑Absolute‑Omni trends are inconclusive. Reinforcement and contradiction patterns do not clearly indicate improvement, degradation, collapse, or stability.`;
}