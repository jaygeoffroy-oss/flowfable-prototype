import type { EngineInspectorCrossSystemDeltaFieldIntegrationSealDelta } from "./engineInspectorCrossSystemDeltaFieldIntegrationSealDelta";

export type EngineInspectorHyperDeltaFieldEpochIntegration = {
  version: string;
  hyperDeltaFieldEpochIntegration: {
    epochLength: number;
    epochClassification: string;
    dominantTrajectory: string;
    reinforcingPatterns: string[];
    contradictionPatterns: string[];
    epochSummary: string;
  };
};

export function buildInspectorHyperDeltaFieldEpochIntegration(
  epochDeltas: EngineInspectorCrossSystemDeltaFieldIntegrationSealDelta[]
): EngineInspectorHyperDeltaFieldEpochIntegration {
  if (!epochDeltas || epochDeltas.length === 0) {
    return {
      version: "1.0.0",
      hyperDeltaFieldEpochIntegration: {
        epochLength: 0,
        epochClassification: "InsufficientData",
        dominantTrajectory: "Unknown",
        reinforcingPatterns: [],
        contradictionPatterns: [],
        epochSummary: "No epoch-level delta patterns available."
      }
    };
  }

  const epochLength = epochDeltas.length;

  const improvingCount = epochDeltas.filter(
    (d) =>
      d.crossSystemDeltaFieldIntegrationSealDelta.deltaClassification ===
      "Improving"
  ).length;

  const degradingCount = epochDeltas.filter(
    (d) =>
      d.crossSystemDeltaFieldIntegrationSealDelta.deltaClassification ===
      "Degrading"
  ).length;

  const criticalCount = epochDeltas.filter(
    (d) =>
      d.crossSystemDeltaFieldIntegrationSealDelta.deltaClassification ===
      "Critical"
  ).length;

  const reinforcingPatterns = epochDeltas.flatMap((d) =>
    d.crossSystemDeltaFieldIntegrationSealDelta.contributingFactors.filter(
      (f) => f.toLowerCase().includes("reinforcement")
    )
  );

  const contradictionPatterns = epochDeltas.flatMap((d) =>
    d.crossSystemDeltaFieldIntegrationSealDelta.contributingFactors.filter(
      (f) => f.toLowerCase().includes("contradiction")
    )
  );

  let epochClassification = "Stable";
  let dominantTrajectory = "Flat";

  if (criticalCount > 0) {
    epochClassification = "Critical";
    dominantTrajectory = "Collapse";
  } else if (improvingCount > degradingCount) {
    epochClassification = "Improving";
    dominantTrajectory = "Upward";
  } else if (degradingCount > improvingCount) {
    epochClassification = "Degrading";
    dominantTrajectory = "Downward";
  }

  return {
    version: "1.0.0",
    hyperDeltaFieldEpochIntegration: {
      epochLength,
      epochClassification,
      dominantTrajectory,
      reinforcingPatterns,
      contradictionPatterns,
      epochSummary: `Across ${epochLength} cycles, the delta ecosystem shows a ${epochClassification.toLowerCase()} epoch with a ${dominantTrajectory.toLowerCase()} trajectory.`
    }
  };
}