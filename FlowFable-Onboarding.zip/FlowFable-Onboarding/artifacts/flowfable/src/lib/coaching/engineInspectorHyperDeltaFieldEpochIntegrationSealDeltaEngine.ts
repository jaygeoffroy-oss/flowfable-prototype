import {
  buildInspectorHyperDeltaFieldEpochIntegrationSealDelta as buildSealDelta
} from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDelta";
import { buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaSummary } from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDeltaSummary";
import { buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary } from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary";
import { buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummary } from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummary";
import { buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummarySummary } from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummarySummary";

export {
  buildInspectorHyperDeltaFieldEpochIntegrationSealDelta
} from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDelta";
export type {
  EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta,
  EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta
} from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDelta";

export function buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngine(
  currentSummaryString: string,
  previousSummaryString?: string
) {
  const delta = buildSealDelta(
    currentSummaryString,
    previousSummaryString
  );

  const deltaSummary =
    buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaSummary(delta);

  const deltaEngineSummary =
    buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary(delta);

  const deltaEngineMetaSummary =
    buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummary(
      deltaEngineSummary,
      previousSummaryString
    );

  const deltaEngineMetaSummarySummary =
    buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummarySummary(
      deltaEngineMetaSummary
    );

  return {
    version: "1.0.0",
    hyperDeltaFieldEpochIntegrationSealDeltaEngine: {
      delta,
      deltaSummary,
      deltaEngineSummary,
      deltaEngineMetaSummary,
      deltaEngineMetaSummarySummary
    }
  };
}