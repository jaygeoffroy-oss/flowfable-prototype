import type { EngineInspectorAutonomousVersioning } from "./engineInspectorAutonomousVersioning";

export function buildInspectorAutonomousVersioningSummary(
  inspectorAutonomousVersioning: EngineInspectorAutonomousVersioning
): string {
  const v = inspectorAutonomousVersioning.autonomousVersioning;

  if (v.bumpType === "Patch") {
    return `The Inspector applied a patch-level version increment. Evolution remained neutral, with no major changes detected. This update reflects minor adjustments or routine maintenance with no impact on long-term evolutionary trajectory.`;
  }

  if (v.bumpType === "Minor") {
    return `The Inspector applied a minor version increment. Evolution deltas indicate meaningful changes in stability, governance integrity, or evolution priority. This update reflects forward progress in the Inspector’s evolutionary trajectory. Changes: ${v.changes.join(", ")}. Pending evolution: ${v.pendingEvolution.join(", ")}.`;
  }

  return `The Inspector applied a major version increment. Critical evolution deltas were detected, requiring substantial architectural or governance updates. This update reflects a significant shift in the Inspector’s long-term evolutionary trajectory. Changes: ${v.changes.join(", ")}. Regression risks: ${v.regressionRisks.join(", ")}.`;
}