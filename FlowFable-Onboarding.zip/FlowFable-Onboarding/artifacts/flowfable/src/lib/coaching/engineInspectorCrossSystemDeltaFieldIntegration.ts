import type { EngineInspectorAutonomyHarmonizationSealDelta } from "./engineInspectorAutonomyHarmonizationSealDelta";
import type { EngineInspectorCrossTierAutonomyDelta } from "./engineInspectorCrossTierAutonomyDelta";
import type { EngineInspectorHarmonizationDeltaIntegration } from "./engineInspectorHarmonizationDeltaIntegration";
import type { EngineInspectorHarmonizationDeltaIntegrationSeal } from "./engineInspectorHarmonizationDeltaIntegrationSeal";

export type EngineInspectorCrossSystemDeltaFieldIntegration = {
  version: string;
  crossSystemDeltaFieldIntegration: {
    autonomyDeltaClassification: string;
    harmonizationDeltaClassification: string;
    unifiedTrajectory: string;
    unifiedSeal: string;
    unifiedSealDeltaClassification: string;
    contradictions: string[];
    reinforcements: string[];
    globalTrajectory: string;
  };
};

export function buildInspectorCrossSystemDeltaFieldIntegration({
  inspectorCrossTierAutonomyDelta,
  inspectorAutonomyHarmonizationSealDelta,
  inspectorHarmonizationDeltaIntegration,
  inspectorHarmonizationDeltaIntegrationSeal,
  inspectorHarmonizationDeltaIntegrationSealDelta
}: {
  inspectorCrossTierAutonomyDelta: EngineInspectorCrossTierAutonomyDelta;
  inspectorAutonomyHarmonizationSealDelta: EngineInspectorAutonomyHarmonizationSealDelta;
  inspectorHarmonizationDeltaIntegration: EngineInspectorHarmonizationDeltaIntegration;
  inspectorHarmonizationDeltaIntegrationSeal: EngineInspectorHarmonizationDeltaIntegrationSeal;
  inspectorHarmonizationDeltaIntegrationSealDelta: import("./engineInspectorHarmonizationDeltaIntegrationSealDelta").EngineInspectorHarmonizationDeltaIntegrationSealDelta;
}): EngineInspectorCrossSystemDeltaFieldIntegration {
  const autonomyDelta =
    inspectorCrossTierAutonomyDelta.crossTierAutonomyDelta;

  const harmonizationDelta =
    inspectorAutonomyHarmonizationSealDelta
      .autonomyHarmonizationSealDelta;

  const unifiedIntegration =
    inspectorHarmonizationDeltaIntegration.harmonizationDeltaIntegration;

  const unifiedSeal =
    inspectorHarmonizationDeltaIntegrationSeal.harmonizationDeltaIntegrationSeal;

  const unifiedSealDelta =
    inspectorHarmonizationDeltaIntegrationSealDelta
      .harmonizationDeltaIntegrationSealDelta;

  const contradictions = [
    ...unifiedIntegration.contradictions,
    ...(unifiedSealDelta.deltaClassification === "Degrading"
      ? ["Unified seal degrading"]
      : []),
    ...(unifiedSealDelta.deltaClassification === "Critical"
      ? ["Unified seal in critical state"]
      : [])
  ];

  const reinforcements = [
    ...unifiedIntegration.reinforcements,
    ...(unifiedSealDelta.deltaClassification === "Improving"
      ? ["Unified seal improving"]
      : [])
  ];

  const globalTrajectory =
    contradictions.length === 0 && reinforcements.length > 0
      ? "Aligned"
      : contradictions.length > reinforcements.length
        ? "Misaligned"
        : "Mixed";

  return {
    version: inspectorCrossTierAutonomyDelta.version,
    crossSystemDeltaFieldIntegration: {
      autonomyDeltaClassification: autonomyDelta.deltaClassification,
      harmonizationDeltaClassification:
        harmonizationDelta.deltaClassification,
      unifiedTrajectory: unifiedIntegration.unifiedTrajectory,
      unifiedSeal: unifiedSeal.seal,
      unifiedSealDeltaClassification:
        unifiedSealDelta.deltaClassification,
      contradictions,
      reinforcements,
      globalTrajectory
    }
  };
}