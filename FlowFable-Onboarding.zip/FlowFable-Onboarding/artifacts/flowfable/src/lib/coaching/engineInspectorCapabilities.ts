import type { EngineInspectorSchema } from "./engineInspectorSchema";

export type EngineInspectorCapabilities = {
  version: string;
  capabilities: Record<string, boolean>;
};

export function buildInspectorCapabilities(
  inspectorRegistry: EngineInspectorSchema
): EngineInspectorCapabilities {
  return {
    version: inspectorRegistry.version,
    capabilities: {
      renderStatusBanner: !!inspectorRegistry.blocks.statusBanner,
      renderIntegritySeal: !!inspectorRegistry.blocks.integritySeal,
      renderConfidenceScore: !!inspectorRegistry.blocks.confidenceScore,
      renderMetaSummary: !!inspectorRegistry.blocks.metaSummary,
      renderExpandedMetaSummary: !!inspectorRegistry.blocks.expandedMetaSummary,
      renderAdvisory: !!inspectorRegistry.blocks.advisory,
      renderSummary: !!inspectorRegistry.blocks.summary,
      renderParameterDelta: !!inspectorRegistry.blocks.parameterDelta,
      renderEngineHistory: !!inspectorRegistry.blocks.engineHistory,
      renderEngineHealth: !!inspectorRegistry.blocks.engineHealth,
      renderEngineStability: !!inspectorRegistry.blocks.engineStability,
      renderCurrentParams: !!inspectorRegistry.blocks.currentParams,
      renderNextRunParams: !!inspectorRegistry.blocks.nextRunParams,
      computeParameterDelta: true,
      computeEngineConsistency: true,
      computeEngineConfidence: true,
      computeEngineIntegrity: true,
      computeMetaSummary: true,
      computeExpandedMetaSummary: true,
      describeInspectorStructure: true,
      describeInspectorMetadata: true,
      describeInspectorVersioning: true
    }
  };
}

export const engineInspectorCapabilities: EngineInspectorCapabilities = {
  version: "1.0.0",
  capabilities: {
    renderStatusBanner: true,
    renderIntegritySeal: true,
    renderConfidenceScore: true,
    renderMetaSummary: true,
    renderExpandedMetaSummary: true,
    renderAdvisory: true,
    renderSummary: true,
    renderParameterDelta: true,
    renderEngineHistory: true,
    renderEngineHealth: true,
    renderEngineStability: true,
    renderCurrentParams: true,
    renderNextRunParams: true,
    computeParameterDelta: true,
    computeEngineConsistency: true,
    computeEngineConfidence: true,
    computeEngineIntegrity: true,
    computeMetaSummary: true,
    computeExpandedMetaSummary: true,
    describeInspectorStructure: true,
    describeInspectorMetadata: true,
    describeInspectorVersioning: true
  }
};