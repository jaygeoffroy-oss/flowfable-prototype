export { buildInspectorAutonomousGovernanceRewrite } from "./engineInspectorAutonomousGovernanceRewrite";
export type {
  EngineInspectorAutonomousGovernanceRewrite
} from "./engineInspectorAutonomousGovernanceRewrite";