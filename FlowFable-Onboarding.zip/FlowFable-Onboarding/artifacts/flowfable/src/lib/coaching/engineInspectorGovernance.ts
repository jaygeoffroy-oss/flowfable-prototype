import type { EngineInspectorSchema } from "./engineInspectorSchema";

export type EngineInspectorGovernance = {
  version: string;
  governance: {
    versioningPolicy: {
      majorChanges: string;
      minorChanges: string;
      patchChanges: string;
    };
    compatibilityRules: {
      requireStableIds: boolean;
      requireStableOrder: boolean;
      allowNewBlocks: boolean;
      allowDeprecatedBlocks: boolean;
      forbidBreakingSchemaChanges: boolean;
    };
    lifecycle: {
      blockStates: string[];
      defaultState: string;
      deprecationProcess: string;
    };
    integrityRules: {
      requireManifest: boolean;
      requireRegistry: boolean;
      requireCapabilitiesMap: boolean;
      requireIndex: boolean;
    };
    extensionRules: {
      allowCustomBlocks: boolean;
      requireSchemaForCustomBlocks: boolean;
      requireVersionForCustomBlocks: boolean;
    };
  };
};

export function buildInspectorGovernance(
  inspectorRegistry: EngineInspectorSchema
): EngineInspectorGovernance {
  return {
    version: inspectorRegistry.version,
    governance: {
      versioningPolicy: {
        majorChanges: "Breaking structural changes or schema changes.",
        minorChanges: "New blocks, new metadata, new capabilities.",
        patchChanges: "Bug fixes, description updates, non-breaking changes."
      },
      compatibilityRules: {
        requireStableIds: true,
        requireStableOrder: true,
        allowNewBlocks: true,
        allowDeprecatedBlocks: true,
        forbidBreakingSchemaChanges: true
      },
      lifecycle: {
        blockStates: ["active", "deprecated", "experimental"],
        defaultState: "active",
        deprecationProcess:
          "Announce → Mark deprecated → Remove in next major version."
      },
      integrityRules: {
        requireManifest: true,
        requireRegistry: true,
        requireCapabilitiesMap: true,
        requireIndex: true
      },
      extensionRules: {
        allowCustomBlocks: true,
        requireSchemaForCustomBlocks: true,
        requireVersionForCustomBlocks: true
      }
    }
  };
}

export const engineInspectorGovernance: EngineInspectorGovernance = {
  version: "1.0.0",
  governance: {
    versioningPolicy: {
      majorChanges: "Breaking structural changes or schema changes.",
      minorChanges: "New blocks, new metadata, new capabilities.",
      patchChanges: "Bug fixes, description updates, non-breaking changes."
    },
    compatibilityRules: {
      requireStableIds: true,
      requireStableOrder: true,
      allowNewBlocks: true,
      allowDeprecatedBlocks: true,
      forbidBreakingSchemaChanges: true
    },
    lifecycle: {
      blockStates: ["active", "deprecated", "experimental"],
      defaultState: "active",
      deprecationProcess:
        "Announce → Mark deprecated → Remove in next major version."
    },
    integrityRules: {
      requireManifest: true,
      requireRegistry: true,
      requireCapabilitiesMap: true,
      requireIndex: true
    },
    extensionRules: {
      allowCustomBlocks: true,
      requireSchemaForCustomBlocks: true,
      requireVersionForCustomBlocks: true
    }
  }
};