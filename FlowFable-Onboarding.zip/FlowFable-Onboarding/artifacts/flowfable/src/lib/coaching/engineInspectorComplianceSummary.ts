import type { EngineInspectorCompliance } from "./engineInspectorCompliance";

export function buildInspectorComplianceSummary(
  inspectorComplianceReport: EngineInspectorCompliance
): string {
  const c = inspectorComplianceReport.compliance;

  const allGood =
    c.versioningPolicy &&
    c.compatibilityRules &&
    c.lifecycleRules &&
    c.integrityRules &&
    c.extensionRules &&
    c.issues.length === 0;

  if (allGood) {
    return "The Inspector complies fully with all governance rules, including versioning, compatibility, lifecycle, integrity, and extension policies. No issues were detected.";
  }

  const failing: string[] = [];
  if (!c.versioningPolicy) failing.push("versioning policy");
  if (!c.compatibilityRules) failing.push("compatibility rules");
  if (!c.lifecycleRules) failing.push("lifecycle rules");
  if (!c.integrityRules) failing.push("integrity rules");
  if (!c.extensionRules) failing.push("extension rules");

  return `The Inspector is partially compliant with governance rules. The following areas require attention: ${failing.join(", ")}. A total of ${c.issues.length} issues were detected.`;
}