import type { EngineInspectorGovernance } from "./engineInspectorGovernance";
import type { EngineInspectorSchema } from "./engineInspectorSchema";

export type EngineInspectorCompliance = {
  version: string;
  compliance: {
    versioningPolicy: boolean;
    compatibilityRules: boolean;
    lifecycleRules: boolean;
    integrityRules: boolean;
    extensionRules: boolean;
    issues: string[];
  };
};

export function buildInspectorComplianceReport({
  inspectorRegistry,
  inspectorGovernance
}: {
  inspectorRegistry: EngineInspectorSchema;
  inspectorGovernance: EngineInspectorGovernance;
}): EngineInspectorCompliance {
  const issues: string[] = [];

  const versioningPolicyOk = inspectorRegistry.version === "1.0.0";
  if (!versioningPolicyOk) {
    issues.push("Registry version does not match governance version.");
  }

  const compatibilityRules =
    inspectorGovernance.governance.compatibilityRules;
  const compatibilityOk =
    compatibilityRules.requireStableIds &&
    compatibilityRules.requireStableOrder &&
    !!inspectorRegistry.blocks &&
    Object.keys(inspectorRegistry.blocks).length > 0;

  if (!compatibilityOk) {
    issues.push("Compatibility rules violated.");
  }

  const integrityRules = inspectorGovernance.governance.integrityRules;
  const integrityOk =
    integrityRules.requireManifest &&
    integrityRules.requireRegistry &&
    integrityRules.requireCapabilitiesMap &&
    integrityRules.requireIndex;

  if (!integrityOk) {
    issues.push("Integrity rules violated.");
  }

  const lifecycleRules = inspectorGovernance.governance.lifecycle;
  const lifecycleOk = lifecycleRules.blockStates.includes("active");
  if (!lifecycleOk) {
    issues.push("Lifecycle rules violated.");
  }

  const extensionRules = inspectorGovernance.governance.extensionRules;
  const extensionOk =
    extensionRules.allowCustomBlocks &&
    extensionRules.requireSchemaForCustomBlocks &&
    extensionRules.requireVersionForCustomBlocks;

  if (!extensionOk) {
    issues.push("Extension rules violated.");
  }

  return {
    version: inspectorRegistry.version,
    compliance: {
      versioningPolicy: versioningPolicyOk,
      compatibilityRules: compatibilityOk,
      lifecycleRules: lifecycleOk,
      integrityRules: integrityOk,
      extensionRules: extensionOk,
      issues
    }
  };
}

export function buildInspectorCompliance(
  inspectorGovernance: EngineInspectorGovernance,
  inspectorRegistry?: EngineInspectorSchema
): EngineInspectorCompliance {
  const issues: string[] = [];
  const governance = inspectorGovernance.governance;

  let versioningPolicy = Boolean(
    governance.versioningPolicy.majorChanges &&
      governance.versioningPolicy.minorChanges &&
      governance.versioningPolicy.patchChanges
  );
  if (inspectorRegistry) {
    for (const [key, block] of Object.entries(inspectorRegistry.blocks)) {
      if (!block.version) {
        issues.push(`Block '${key}' missing version field`);
        versioningPolicy = false;
      }
    }
  }
  const compatibilityRules = Boolean(
    governance.compatibilityRules.requireStableIds &&
      governance.compatibilityRules.requireStableOrder
  );
  const lifecycleRules = Boolean(
    governance.lifecycle.blockStates.length > 0 &&
      governance.lifecycle.defaultState &&
      governance.lifecycle.deprecationProcess
  );
  const integrityRules = Boolean(
    governance.integrityRules.requireManifest &&
      governance.integrityRules.requireRegistry &&
      governance.integrityRules.requireCapabilitiesMap &&
      governance.integrityRules.requireIndex
  );
  const extensionRules = Boolean(
    governance.extensionRules.allowCustomBlocks &&
      governance.extensionRules.requireSchemaForCustomBlocks &&
      governance.extensionRules.requireVersionForCustomBlocks
  );

  if (!versioningPolicy && issues.length === 0) {
    issues.push("Versioning policy is incomplete.");
  }
  if (!compatibilityRules) issues.push("Compatibility rules are incomplete.");
  if (!lifecycleRules) issues.push("Lifecycle rules are incomplete.");
  if (!integrityRules) issues.push("Integrity rules are incomplete.");
  if (!extensionRules) issues.push("Extension rules are incomplete.");

  return {
    version: inspectorGovernance.version,
    compliance: {
      versioningPolicy,
      compatibilityRules,
      lifecycleRules,
      integrityRules,
      extensionRules,
      issues
    }
  };
}