import type { EngineInspectorSelfIntegritySeal } from "./engineInspectorSelfIntegritySeal";

export type EngineInspectorAutonomousStability = {
  version: string;
  autonomousStability: {
    trend: string;
    lastSeal: string | null;
    currentSeal: string;
    delta: string;
    degradationRisk: string;
    issues: string[];
  };
};

export function buildInspectorAutonomousStability({
  inspectorSelfIntegritySeal,
  previousSelfIntegritySeal
}: {
  inspectorSelfIntegritySeal: EngineInspectorSelfIntegritySeal;
  previousSelfIntegritySeal?: EngineInspectorSelfIntegritySeal;
}): EngineInspectorAutonomousStability {
  const current = inspectorSelfIntegritySeal.selfIntegritySeal;
  const previous = previousSelfIntegritySeal?.selfIntegritySeal;
  const issues = current.issues || [];

  let trend = "Stable";
  let delta = "No change";
  let degradationRisk = "Low";

  if (previous && current.seal !== previous.seal) {
    if (current.seal === "Gold" && previous.seal === "Platinum") {
      trend = "Degrading";
      delta = "Minor governance warnings";
      degradationRisk = "Medium";
    } else if (current.seal === "Silver" && previous.seal === "Gold") {
      trend = "Degrading";
      delta = "Structural inconsistencies increasing";
      degradationRisk = "High";
    } else if (current.seal === "Red") {
      trend = "Critical";
      delta = "Major governance and coherence failures";
      degradationRisk = "High";
    }
  }

  return {
    version: inspectorSelfIntegritySeal.version,
    autonomousStability: {
      trend,
      lastSeal: previous?.seal || null,
      currentSeal: current.seal,
      delta,
      degradationRisk,
      issues
    }
  };
}