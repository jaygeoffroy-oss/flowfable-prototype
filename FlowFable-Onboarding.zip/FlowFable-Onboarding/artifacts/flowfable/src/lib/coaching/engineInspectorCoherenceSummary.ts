import type { EngineInspectorCoherence } from "./engineInspectorCoherence";

export function buildInspectorCoherenceSummary(
  inspectorCoherenceReport: EngineInspectorCoherence
): string {
  const c = inspectorCoherenceReport.coherence;

  const allGood =
    c.indexVsManifest &&
    c.manifestVsRegistry &&
    c.registryVsCapabilities &&
    c.capabilitiesVsGovernance &&
    c.governanceVsCompliance &&
    c.complianceVsNarrative &&
    c.issues.length === 0;

  if (allGood) {
    return "The Inspector is fully coherent across all structural, metadata, versioning, capability, governance, and compliance layers. No cross-layer inconsistencies were detected.";
  }

  const failing: string[] = [];
  if (!c.indexVsManifest) failing.push("index vs manifest");
  if (!c.manifestVsRegistry) failing.push("manifest vs registry");
  if (!c.registryVsCapabilities) failing.push("registry vs capabilities");
  if (!c.capabilitiesVsGovernance) failing.push("capabilities vs governance");
  if (!c.governanceVsCompliance) failing.push("governance vs compliance");
  if (!c.complianceVsNarrative) failing.push("compliance vs narrative");

  return `The Inspector exhibits partial coherence. The following cross-layer relationships require attention: ${failing.join(", ")}. A total of ${c.issues.length} issues were detected.`;
}