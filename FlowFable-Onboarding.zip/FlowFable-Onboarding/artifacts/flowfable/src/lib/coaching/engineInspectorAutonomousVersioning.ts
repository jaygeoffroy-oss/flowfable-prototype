import type { EngineInspectorAutonomousEvolutionDelta } from "./engineInspectorAutonomousEvolutionDelta";

export type EngineInspectorAutonomousVersioning = {
  version: string;
  autonomousVersioning: {
    previousVersion: string;
    newVersion: string;
    bumpType: string;
    rationale: string;
    changes: string[];
    pendingEvolution: string[];
    regressionRisks: string[];
  };
};

export function buildInspectorAutonomousVersioning({
  inspectorAutonomousEvolutionDelta,
  previousVersion
}: {
  inspectorAutonomousEvolutionDelta: EngineInspectorAutonomousEvolutionDelta;
  previousVersion: string;
}): EngineInspectorAutonomousVersioning {
  const delta =
    inspectorAutonomousEvolutionDelta.autonomousEvolutionDelta;
  let bumpType = "Patch";
  let rationale = "Neutral evolution delta";
  const changes = delta.changes;
  const pendingEvolution = delta.pendingEvolution;
  const regressionRisks = delta.regressionRisks;

  if (delta.deltaClassification === "Positive") {
    bumpType = "Minor";
    rationale = "Positive evolution delta; stability improved";
  }

  if (delta.deltaClassification === "Negative") {
    bumpType = "Minor";
    rationale = "Negative evolution delta; evolution priority increased";
  }

  if (delta.deltaClassification === "Critical") {
    bumpType = "Major";
    rationale = "Critical degradation detected; major evolution required";
  }

  const [major, minor, patch] = previousVersion.split(".").map(Number);
  let newVersion = previousVersion;

  if (bumpType === "Patch") {
    newVersion = `${major}.${minor}.${patch + 1}`;
  }

  if (bumpType === "Minor") {
    newVersion = `${major}.${minor + 1}.0`;
  }

  if (bumpType === "Major") {
    newVersion = `${major + 1}.0.0`;
  }

  return {
    version: newVersion,
    autonomousVersioning: {
      previousVersion,
      newVersion,
      bumpType,
      rationale,
      changes,
      pendingEvolution,
      regressionRisks
    }
  };
}