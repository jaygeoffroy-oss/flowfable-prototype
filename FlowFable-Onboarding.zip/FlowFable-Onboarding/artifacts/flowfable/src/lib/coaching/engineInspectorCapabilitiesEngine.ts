export {
  buildInspectorCapabilities,
  engineInspectorCapabilities
} from "./engineInspectorCapabilities";
export type { EngineInspectorCapabilities } from "./engineInspectorCapabilities";