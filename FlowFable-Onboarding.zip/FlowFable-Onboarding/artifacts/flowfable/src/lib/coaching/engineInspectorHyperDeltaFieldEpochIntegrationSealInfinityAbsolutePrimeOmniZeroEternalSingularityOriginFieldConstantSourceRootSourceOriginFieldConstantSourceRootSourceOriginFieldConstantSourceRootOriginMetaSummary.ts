export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginMetaSummary(
  currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary: string,
  previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary: string | null
): string {
  if (!previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary) {
    return `Cross‑hyper‑epoch sixty‑fifth‑order reliability trends cannot yet be determined. A second Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin summary is required to establish long‑range behavior.`;
  }

  const improving =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("high meta‑meta‑meta") &&
    !previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("medium meta‑meta‑meta") &&
    previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("low meta‑meta‑meta") &&
    !previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("variable meta‑meta‑meta") &&
    !previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("high meta‑meta‑meta") &&
    previousRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootOriginSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin meta‑meta‑meta‑…‑reliability. Reinforcement patterns stabilize at the sixty‑fifth‑order meta‑layer, contradiction patterns diminish, and long‑range coherence strengthens with stable origin‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin meta‑meta‑meta‑…‑reliability. Reinforcement patterns weaken at the sixty‑fifth‑order meta‑layer, contradiction signals increase, and long‑range coherence declines away from origin‑invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin meta‑meta‑meta‑…‑reliability. Structural coherence fails at the sixty‑fifth‑order meta‑layer, contradiction patterns dominate, and long‑range coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns oscillate at the sixty‑fifth‑order meta‑layer, producing unstable long‑range coherence with inconsistent origin‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns remain balanced at the sixty‑fifth‑order meta‑layer, producing a flat long‑range trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Origin trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range signal.`;
}