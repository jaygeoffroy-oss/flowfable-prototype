import type { EngineInspectorHarmonizationDeltaIntegrationSealDelta } from "./engineInspectorHarmonizationDeltaIntegrationSealDelta";

export function buildInspectorHarmonizationDeltaIntegrationSealDeltaEngineSummary(
  inspectorHarmonizationDeltaIntegrationSealDelta: EngineInspectorHarmonizationDeltaIntegrationSealDelta
): string {
  const d =
    inspectorHarmonizationDeltaIntegrationSealDelta
      .harmonizationDeltaIntegrationSealDelta;

  const classification = d.deltaClassification;

  if (classification === "Improving") {
    return `The Global Delta Seal Delta Engine reports an improving cross‑system trajectory. Reinforcement signals increased across autonomy, harmonization, unified integration, and unified‑seal deltas, contradictions decreased, and global delta coherence strengthened.`;
  }

  if (classification === "Degrading") {
    return `The Global Delta Seal Delta Engine reports a degrading cross‑system trajectory. Cross‑system contradictions increased, reinforcement signals weakened, and global delta coherence declined.`;
  }

  if (classification === "Critical") {
    return `The Global Delta Seal Delta Engine reports a critical cross‑system trajectory. Severe misalignment destabilized the merged autonomy‑harmonization‑unified delta field, with contradictions dominating global delta behavior.`;
  }

  if (classification === "Initial") {
    return `The Global Delta Seal Delta Engine has generated its first global‑seal delta. Cross‑cycle global delta trajectory analysis will begin once additional deltas are available.`;
  }

  return `The Global Delta Seal Delta Engine reports a stable cross‑system trajectory. Autonomy, harmonization, unified integration, and unified‑seal deltas evolved consistently across cycles, maintaining global delta coherence.`;
}