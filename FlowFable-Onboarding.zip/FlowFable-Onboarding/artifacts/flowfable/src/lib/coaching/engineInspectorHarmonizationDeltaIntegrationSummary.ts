import type { EngineInspectorHarmonizationDeltaIntegration } from "./engineInspectorHarmonizationDeltaIntegration";

export function buildInspectorHarmonizationDeltaIntegrationSummary(
  inspectorHarmonizationDeltaIntegration: EngineInspectorHarmonizationDeltaIntegration
): string {
  const i =
    inspectorHarmonizationDeltaIntegration.harmonizationDeltaIntegration;

  if (i.unifiedTrajectory === "Aligned") {
    return `Autonomy deltas and harmonization deltas are aligned this cycle. Improvements or stability in autonomy are reinforced by parallel improvements or stability in harmonization, indicating cohesive cross‑system evolution.`;
  }

  if (i.unifiedTrajectory === "Misaligned") {
    return `Autonomy deltas and harmonization deltas are misaligned this cycle. One system is improving while the other is degrading, creating cross‑system contradictions that weaken unified structural coherence.`;
  }

  if (i.unifiedTrajectory === "Mixed") {
    return `Cross‑system delta signals are mixed. Autonomy and harmonization exhibit partial alignment but also contain contradictory elements, resulting in an ambiguous unified delta trajectory.`;
  }

  return `Cross‑system delta signals could not be classified. Autonomy and harmonization trajectories do not provide sufficient clarity for unified interpretation.`;
}