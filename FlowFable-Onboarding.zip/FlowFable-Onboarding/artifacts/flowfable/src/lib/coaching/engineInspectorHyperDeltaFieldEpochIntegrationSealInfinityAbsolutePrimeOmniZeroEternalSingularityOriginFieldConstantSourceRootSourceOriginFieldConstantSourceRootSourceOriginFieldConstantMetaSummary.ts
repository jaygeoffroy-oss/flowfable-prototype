export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantMetaSummary(
  currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary: string,
  previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary: string | null
): string {
  if (!previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary) {
    return `Cross‑hyper‑epoch sixty‑second‑order reliability trends cannot yet be determined. A second Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant summary is required to establish long‑range behavior.`;
  }

  const improving =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("medium meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("low meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("variable meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginFieldConstantSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑…‑reliability. Reinforcement patterns stabilize at the sixty‑second‑order meta‑layer, contradiction patterns diminish, and long‑range coherence strengthens with stable invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑…‑reliability. Reinforcement patterns weaken at the sixty‑second‑order meta‑layer, contradiction signals increase, and long‑range coherence declines away from invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑…‑reliability. Structural coherence fails at the sixty‑second‑order meta‑layer, contradiction patterns dominate, and long‑range coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns oscillate at the sixty‑second‑order meta‑layer, producing unstable long‑range coherence with inconsistent invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant meta‑meta‑meta‑…‑reliability. Reinforcement and contradiction patterns remain balanced at the sixty‑second‑order meta‑layer, producing a flat long‑range trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin‑Field‑Constant trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range signal.`;
}