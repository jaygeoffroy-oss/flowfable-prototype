import type { EngineInspectorAutonomousGovernanceRewriteSeal } from "./engineInspectorAutonomousGovernanceRewriteSeal";

export function buildInspectorAutonomousGovernanceRewriteSealSummaryGenerator(
  inspectorAutonomousGovernanceRewriteSeal: EngineInspectorAutonomousGovernanceRewriteSeal
): string {
  const seal =
    inspectorAutonomousGovernanceRewriteSeal.autonomousGovernanceRewriteSeal;

  if (seal.seal === "Platinum") {
    return `The Inspector’s governance rewrite readiness is at its highest level. The governance model is stable, resilient, and requires no significant structural changes. Rewrite actions are minimal and focused on proactive enhancements.`;
  }

  if (seal.seal === "Gold") {
    return `The Inspector’s governance rewrite readiness is strong but not perfect. Some governance issues require attention, and rewrite actions are recommended to maintain long-term stability. These actions will reinforce governance integrity and prevent future drift.`;
  }

  if (seal.seal === "Silver") {
    return `The Inspector’s governance rewrite readiness is moderate. Governance inconsistencies or extension‑resilience issues have been detected. Rewrite actions are necessary to restore alignment and ensure future stability.`;
  }

  return `The Inspector’s governance rewrite readiness is critically low. High‑priority rewrite actions are required to repair governance-rule hierarchy, restore extension resilience, and stabilize the governance model. Immediate intervention is essential.`;
}