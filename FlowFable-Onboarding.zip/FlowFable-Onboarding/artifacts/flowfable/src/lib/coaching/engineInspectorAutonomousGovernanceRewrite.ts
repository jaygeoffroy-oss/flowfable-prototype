import type { EngineInspectorAutonomousEvolutionDelta } from "./engineInspectorAutonomousEvolutionDelta";
import type { EngineInspectorMetaGovernanceIntegrity } from "./engineInspectorMetaGovernanceIntegrity";

export type EngineInspectorAutonomousGovernanceRewrite = {
  version: string;
  autonomousGovernanceRewrite: {
    rewriteActions: string[];
    priority: string;
    rationale: string;
    dependencies: string[];
    issues: string[];
  };
};

export function buildInspectorAutonomousGovernanceRewrite({
  inspectorAutonomousEvolutionDelta,
  inspectorMetaGovernanceIntegrityReport
}: {
  inspectorAutonomousEvolutionDelta: EngineInspectorAutonomousEvolutionDelta;
  inspectorMetaGovernanceIntegrityReport: EngineInspectorMetaGovernanceIntegrity;
}): EngineInspectorAutonomousGovernanceRewrite {
  const delta =
    inspectorAutonomousEvolutionDelta.autonomousEvolutionDelta;
  const metaGovInt =
    inspectorMetaGovernanceIntegrityReport.metaGovernanceIntegrity;
  const issues = [...delta.regressionRisks, ...metaGovInt.issues];
  const rewriteActions: string[] = [];
  let priority = "Low";
  let rationale = "System stable";
  const dependencies: string[] = [];

  if (delta.deltaClassification === "Positive") {
    rewriteActions.push(
      "Add proactive governance drift detection",
      "Introduce governance redundancy checks"
    );
    dependencies.push("Governance model");
  }

  if (delta.deltaClassification === "Negative") {
    rewriteActions.push(
      "Repair governance-rule inconsistencies",
      "Rebuild governance extension rules"
    );
    priority = "Medium";
    rationale = "Negative evolution delta detected";
    dependencies.push("Governance model");
  }

  if (delta.deltaClassification === "Critical") {
    rewriteActions.push(
      "Regenerate governance-rule hierarchy",
      "Introduce adaptive governance thresholds",
      "Rewrite extension-resilience rules"
    );
    priority = "High";
    rationale = "Critical evolution delta detected";
    dependencies.push("Governance model", "Coherence engine");
  }

  if (issues.length === 0 && rewriteActions.length === 0) {
    rewriteActions.push("No governance rewrite required");
  }

  return {
    version: inspectorAutonomousEvolutionDelta.version,
    autonomousGovernanceRewrite: {
      rewriteActions,
      priority,
      rationale,
      dependencies,
      issues
    }
  };
}