import type { GuidanceEngineParams } from "./guidanceEngineParameters";

export type ParameterDeltaValue = {
  current: GuidanceEngineParams[keyof GuidanceEngineParams];
  next?: GuidanceEngineParams[keyof GuidanceEngineParams];
  previous?: GuidanceEngineParams[keyof GuidanceEngineParams];
  deltaFromPrevious: number | null;
  deltaToNext: number | null;
};

export type ParameterDelta = Partial<
  Record<keyof GuidanceEngineParams, ParameterDeltaValue>
>;

function numericDelta(
  current: GuidanceEngineParams[keyof GuidanceEngineParams],
  other: GuidanceEngineParams[keyof GuidanceEngineParams] | undefined
) {
  return typeof current === "number" && typeof other === "number"
    ? current - other
    : null;
}

export function computeParameterDelta({
  current,
  next,
  previous
}: {
  current: GuidanceEngineParams;
  next?: GuidanceEngineParams;
  previous?: GuidanceEngineParams;
}): ParameterDelta {
  const delta: ParameterDelta = {};

  for (const key of Object.keys(current) as Array<
    keyof GuidanceEngineParams
  >) {
    delta[key] = {
      current: current[key],
      next: next?.[key],
      previous: previous?.[key],
      deltaFromPrevious: previous
        ? numericDelta(current[key], previous[key])
        : null,
      deltaToNext: next ? numericDelta(next[key], current[key]) : null
    };
  }

  return delta;
}