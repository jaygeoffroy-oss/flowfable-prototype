import type { EngineInspectorAutonomyHarmonizationSealDelta } from "./engineInspectorAutonomyHarmonizationSealDelta";
import type { EngineInspectorCrossTierAutonomyDelta } from "./engineInspectorCrossTierAutonomyDelta";

export type EngineInspectorHarmonizationDeltaIntegration = {
  version: string;
  harmonizationDeltaIntegration: {
    autonomyDeltaClassification: string;
    harmonizationDeltaClassification: string;
    contradictions: string[];
    reinforcements: string[];
    unifiedTrajectory: string;
  };
};

export function buildInspectorHarmonizationDeltaIntegration({
  inspectorCrossTierAutonomyDelta,
  inspectorAutonomyHarmonizationSealDelta
}: {
  inspectorCrossTierAutonomyDelta: EngineInspectorCrossTierAutonomyDelta;
  inspectorAutonomyHarmonizationSealDelta: EngineInspectorAutonomyHarmonizationSealDelta;
}): EngineInspectorHarmonizationDeltaIntegration {
  const autonomyDelta =
    inspectorCrossTierAutonomyDelta.crossTierAutonomyDelta;
  const harmonizationDelta =
    inspectorAutonomyHarmonizationSealDelta.autonomyHarmonizationSealDelta;

  const contradictions: string[] = [];
  const reinforcements: string[] = [];

  if (
    autonomyDelta.deltaClassification === "Improving" &&
    harmonizationDelta.deltaClassification === "Degrading"
  ) {
    contradictions.push(
      "Autonomy improving while harmonization weakening"
    );
  }

  if (
    autonomyDelta.deltaClassification === "Degrading" &&
    harmonizationDelta.deltaClassification === "Improving"
  ) {
    contradictions.push(
      "Autonomy degrading while harmonization strengthening"
    );
  }

  if (
    autonomyDelta.deltaClassification === "Improving" &&
    harmonizationDelta.deltaClassification === "Improving"
  ) {
    reinforcements.push(
      "Autonomy and harmonization improving together"
    );
  }

  if (
    autonomyDelta.deltaClassification === "Stable" &&
    harmonizationDelta.deltaClassification === "Stable"
  ) {
    reinforcements.push("Both systems stable across cycles");
  }

  const unifiedTrajectory =
    reinforcements.length > 0 && contradictions.length === 0
      ? "Aligned"
      : contradictions.length > 0
        ? "Misaligned"
        : "Mixed";

  return {
    version: inspectorCrossTierAutonomyDelta.version,
    harmonizationDeltaIntegration: {
      autonomyDeltaClassification: autonomyDelta.deltaClassification,
      harmonizationDeltaClassification:
        harmonizationDelta.deltaClassification,
      contradictions,
      reinforcements,
      unifiedTrajectory
    }
  };
}