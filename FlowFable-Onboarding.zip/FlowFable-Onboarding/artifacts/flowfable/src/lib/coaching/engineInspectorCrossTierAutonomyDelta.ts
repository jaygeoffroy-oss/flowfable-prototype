import type { EngineInspectorAutonomousStability } from "./engineInspectorAutonomousStability";
import type { EngineInspectorAutonomousMaintenance } from "./engineInspectorAutonomousMaintenance";
import type { EngineInspectorAutonomousEvolutionSeal } from "./engineInspectorAutonomousEvolutionSeal";
import type { EngineInspectorAutonomousVersioning } from "./engineInspectorAutonomousVersioning";
import type { EngineInspectorAutonomousGovernanceRewriteSeal } from "./engineInspectorAutonomousGovernanceRewriteSeal";
import type { EngineInspectorAutonomousGovernanceRewriteMetaSeal } from "./engineInspectorAutonomousGovernanceRewriteMetaSeal";
import type { EngineInspectorGlobalAutonomySeal } from "./engineInspectorGlobalAutonomySeal";

export type EngineInspectorCrossTierAutonomyDelta = {
  version: string;
  crossTierAutonomyDelta: {
    cycle: number;
    globalSeal: string;
    previousGlobalSeal: string | null;
    deltaClassification: string;
    tierChanges: {
      stability: string;
      maintenance: string;
      evolution: string;
      versioning: string;
      governanceRewrite: string;
      governanceMeta: string;
    };
    crossTierRisks: string[];
    crossTierImprovements: string[];
    autonomyTrajectory: string;
  };
};

export function buildInspectorCrossTierAutonomyDelta({
  inspectorGlobalAutonomySeal,
  previousGlobalAutonomySeal,
  inspectorAutonomousStability,
  inspectorAutonomousMaintenance,
  inspectorAutonomousEvolutionSeal,
  inspectorAutonomousVersioning,
  inspectorAutonomousGovernanceRewriteSeal,
  inspectorAutonomousGovernanceRewriteMetaSeal,
  cycleNumber
}: {
  inspectorAutonomousStability: EngineInspectorAutonomousStability;
  inspectorAutonomousMaintenance: EngineInspectorAutonomousMaintenance;
  inspectorAutonomousEvolutionSeal: EngineInspectorAutonomousEvolutionSeal;
  inspectorAutonomousVersioning: EngineInspectorAutonomousVersioning;
  inspectorAutonomousGovernanceRewriteSeal: EngineInspectorAutonomousGovernanceRewriteSeal;
  inspectorAutonomousGovernanceRewriteMetaSeal: EngineInspectorAutonomousGovernanceRewriteMetaSeal;
  inspectorGlobalAutonomySeal: EngineInspectorGlobalAutonomySeal;
  previousGlobalAutonomySeal?: EngineInspectorGlobalAutonomySeal;
  cycleNumber: number;
}): EngineInspectorCrossTierAutonomyDelta {
  const global = inspectorGlobalAutonomySeal.globalAutonomySeal;
  const prevGlobal = previousGlobalAutonomySeal?.globalAutonomySeal;

  let deltaClassification = "Neutral";
  const crossTierRisks: string[] = [];
  const crossTierImprovements: string[] = [];

  if (prevGlobal) {
    if (global.seal !== prevGlobal.seal) {
      if (global.seal === "Platinum" && prevGlobal.seal === "Gold") {
        deltaClassification = "Improving";
      } else if (global.seal === "Gold" && prevGlobal.seal === "Platinum") {
        deltaClassification = "Degrading";
      } else if (global.seal === "Red") {
        deltaClassification = "Critical";
      }
    }
  }

  const stabilityTrend =
    inspectorAutonomousStability.autonomousStability.trend;
  const maintenancePriority =
    inspectorAutonomousMaintenance.autonomousMaintenance.priority;
  const evolutionSeal =
    inspectorAutonomousEvolutionSeal.autonomousEvolutionSeal.seal;
  const versionBump =
    inspectorAutonomousVersioning.autonomousVersioning.bumpType;
  const governanceSeal =
    inspectorAutonomousGovernanceRewriteSeal
      .autonomousGovernanceRewriteSeal.seal;
  const governanceMeta =
    inspectorAutonomousGovernanceRewriteMetaSeal
      .autonomousGovernanceRewriteMetaSeal.metaSeal;

  if (stabilityTrend === "Degrading") {
    crossTierRisks.push("Stability degradation");
  }
  if (evolutionSeal === "Gold" || evolutionSeal === "Red") {
    crossTierRisks.push("Evolution instability");
  }
  if (governanceSeal === "Silver" || governanceSeal === "Red") {
    crossTierRisks.push("Governance mismatch");
  }
  if (governanceMeta === "Degrading" || governanceMeta === "Critical") {
    crossTierRisks.push("Governance trajectory collapse");
  }

  if (maintenancePriority === "Low") {
    crossTierImprovements.push("Maintenance efficiency increased");
  }

  const autonomyTrajectory =
    deltaClassification === "Improving"
      ? "Upward"
      : deltaClassification === "Degrading"
        ? "Downward"
        : deltaClassification === "Critical"
          ? "Critical"
          : "Stable";

  return {
    version: inspectorGlobalAutonomySeal.version,
    crossTierAutonomyDelta: {
      cycle: cycleNumber,
      globalSeal: global.seal,
      previousGlobalSeal: prevGlobal?.seal || null,
      deltaClassification,
      tierChanges: {
        stability: stabilityTrend,
        maintenance: maintenancePriority,
        evolution: evolutionSeal,
        versioning: versionBump,
        governanceRewrite: governanceSeal,
        governanceMeta
      },
      crossTierRisks,
      crossTierImprovements,
      autonomyTrajectory
    }
  };
}