import type { EngineInspectorCrossSystemDeltaFieldIntegrationSeal } from "./engineInspectorCrossSystemDeltaFieldIntegrationSeal";

export type EngineInspectorCrossSystemDeltaFieldIntegrationSealDelta = {
  version: string;
  crossSystemDeltaFieldIntegrationSealDelta: {
    previousSeal: string | null;
    currentSeal: string;
    deltaClassification: string;
    contributingFactors: string[];
    trajectory: string;
  };
};

export function buildInspectorCrossSystemDeltaFieldIntegrationSealDelta(
  inspectorCrossSystemDeltaFieldIntegrationSeal: EngineInspectorCrossSystemDeltaFieldIntegrationSeal,
  previousCrossSystemDeltaFieldIntegrationSeal?: EngineInspectorCrossSystemDeltaFieldIntegrationSeal
): EngineInspectorCrossSystemDeltaFieldIntegrationSealDelta {
  const current =
    inspectorCrossSystemDeltaFieldIntegrationSeal
      .crossSystemDeltaFieldIntegrationSeal;
  const previous =
    previousCrossSystemDeltaFieldIntegrationSeal
      ?.crossSystemDeltaFieldIntegrationSeal;

  if (!previous) {
    return {
      version: inspectorCrossSystemDeltaFieldIntegrationSeal.version,
      crossSystemDeltaFieldIntegrationSealDelta: {
        previousSeal: null,
        currentSeal: current.seal,
        deltaClassification: "Initial",
        contributingFactors: [],
        trajectory: "Stable"
      }
    };
  }

  let deltaClassification = "Stable";
  const contributingFactors: string[] = [];

  if (current.seal !== previous.seal) {
    if (current.seal === "Platinum") {
      deltaClassification = "Improving";
      contributingFactors.push("Full global delta alignment achieved");
    } else if (current.seal === "Gold" && previous.seal === "Silver") {
      deltaClassification = "Improving";
      contributingFactors.push(
        "Cross‑system reinforcements increased",
        "Cross‑system contradictions reduced"
      );
    } else if (current.seal === "Silver" && previous.seal === "Gold") {
      deltaClassification = "Degrading";
      contributingFactors.push("Increased global contradictions");
    } else if (current.seal === "Red") {
      deltaClassification = "Critical";
      contributingFactors.push("Severe global delta misalignment");
    }
  }

  const trajectory =
    deltaClassification === "Improving"
      ? "Upward"
      : deltaClassification === "Degrading"
        ? "Downward"
        : deltaClassification === "Critical"
          ? "Critical"
          : "Stable";

  return {
    version: inspectorCrossSystemDeltaFieldIntegrationSeal.version,
    crossSystemDeltaFieldIntegrationSealDelta: {
      previousSeal: previous.seal,
      currentSeal: current.seal,
      deltaClassification,
      contributingFactors,
      trajectory
    }
  };
}