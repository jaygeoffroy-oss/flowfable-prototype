import type { EngineInspectorAutonomyHarmonizationLayer } from "./engineInspectorAutonomyHarmonizationLayer";

export function buildInspectorAutonomyHarmonizationSummary(
  inspectorAutonomyHarmonizationLayer: EngineInspectorAutonomyHarmonizationLayer
): string {
  const h =
    inspectorAutonomyHarmonizationLayer.autonomyHarmonizationLayer;

  if (h.harmonizationStrength === "Strong") {
    return `The Inspector’s autonomy tiers are strongly harmonized. Cross‑tier reinforcements outweigh contradictions, and dominant autonomy signals align across stability, evolution, and governance. The system demonstrates cohesive multi‑tier behavior and high structural integrity.`;
  }

  if (h.harmonizationStrength === "Moderate") {
    return `The Inspector’s autonomy tiers show moderate harmonization. Some contradictions exist, but they are balanced by reinforcing signals across maintenance, stability, or governance. Overall alignment is stable, though improvements could strengthen cross‑tier coherence.`;
  }

  if (h.harmonizationStrength === "Weak") {
    return `The Inspector’s autonomy tiers are weakly harmonized. Multiple contradictions reduce cross‑tier alignment, and dominant autonomy signals are inconsistent across stability, evolution, and governance. Structural coherence requires attention to prevent further misalignment.`;
  }

  return `The Inspector’s autonomy harmonization state could not be classified. Cross‑tier signals are ambiguous or insufficient for determining harmonization strength.`;
}