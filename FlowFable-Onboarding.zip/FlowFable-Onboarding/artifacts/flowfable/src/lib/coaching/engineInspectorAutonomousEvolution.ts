import type { EngineInspectorAutonomousStability } from "./engineInspectorAutonomousStability";
import type { EngineInspectorAutonomousMaintenance } from "./engineInspectorAutonomousMaintenance";
import type { EngineInspectorMetaGovernanceIntegrity } from "./engineInspectorMetaGovernanceIntegrity";

export type EngineInspectorAutonomousEvolution = {
  version: string;
  autonomousEvolution: {
    proposedEnhancements: string[];
    priority: string;
    rationale: string;
    dependencies: string[];
    issues: string[];
  };
};

export function buildInspectorAutonomousEvolution({
  inspectorAutonomousStability,
  inspectorAutonomousMaintenance,
  inspectorMetaGovernanceIntegrityReport
}: {
  inspectorAutonomousStability: EngineInspectorAutonomousStability;
  inspectorAutonomousMaintenance: EngineInspectorAutonomousMaintenance;
  inspectorMetaGovernanceIntegrityReport: EngineInspectorMetaGovernanceIntegrity;
}): EngineInspectorAutonomousEvolution {
  const stability = inspectorAutonomousStability.autonomousStability;
  const maintenance =
    inspectorAutonomousMaintenance.autonomousMaintenance;
  const metaGovInt =
    inspectorMetaGovernanceIntegrityReport.metaGovernanceIntegrity;
  const issues = [
    ...stability.issues,
    ...maintenance.issues,
    ...metaGovInt.issues
  ];
  const proposedEnhancements: string[] = [];
  let priority = "Low";
  let rationale = "System stable";
  const dependencies: string[] = [];

  if (stability.trend === "Stable" && issues.length === 0) {
    proposedEnhancements.push(
      "Add proactive governance drift detection",
      "Introduce structural redundancy checks"
    );
    dependencies.push("Governance model");
  }

  if (stability.trend === "Degrading") {
    proposedEnhancements.push(
      "Introduce adaptive governance thresholds",
      "Add predictive coherence modeling",
      "Add temporal operational-state smoothing"
    );
    priority = "Medium";
    rationale = "Stability trending downward";
    dependencies.push("Governance model", "Coherence engine");
  }

  if (stability.trend === "Critical") {
    proposedEnhancements.push(
      "Rebuild governance-rule hierarchy",
      "Introduce multi-layer coherence recalibration",
      "Add operational-state predictive modeling",
      "Add self-healing governance deltas"
    );
    priority = "High";
    rationale = "Critical degradation detected";
    dependencies.push(
      "Governance model",
      "Coherence engine",
      "Operational engine"
    );
  }

  return {
    version: inspectorAutonomousMaintenance.version,
    autonomousEvolution: {
      proposedEnhancements,
      priority,
      rationale,
      dependencies,
      issues
    }
  };
}