import type { EngineInspectorHarmonizationDeltaIntegration } from "./engineInspectorHarmonizationDeltaIntegration";

export function buildInspectorHarmonizationDeltaIntegrationMetaSummary(
  inspectorHarmonizationDeltaIntegration: EngineInspectorHarmonizationDeltaIntegration,
  previousHarmonizationDeltaIntegration?: EngineInspectorHarmonizationDeltaIntegration
): string {
  const current =
    inspectorHarmonizationDeltaIntegration.harmonizationDeltaIntegration;
  const previous =
    previousHarmonizationDeltaIntegration?.harmonizationDeltaIntegration;

  if (!previous) {
    return `The unified delta field has been generated for the first time. Cross‑cycle integration trends will begin once a second unified delta profile is available.`;
  }

  const improving =
    current.unifiedTrajectory === "Aligned" &&
    previous.unifiedTrajectory !== "Aligned";

  const degrading =
    current.unifiedTrajectory === "Misaligned" &&
    previous.unifiedTrajectory !== "Misaligned";

  const stable =
    current.unifiedTrajectory === previous.unifiedTrajectory;

  if (improving) {
    return `Cross‑cycle analysis shows improved cross‑system alignment. Autonomy and harmonization deltas now reinforce each other more strongly, reducing contradictions and strengthening unified structural coherence.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows declining cross‑system alignment. Autonomy and harmonization deltas have become contradictory, weakening unified structural coherence and increasing cross‑system risk.`;
  }

  if (stable) {
    return `Cross‑cycle analysis shows stable unified delta behavior. Autonomy and harmonization trajectories remain consistent with the previous cycle, indicating steady cross‑system evolution.`;
  }

  return `Cross‑cycle unified delta signals are mixed. Partial shifts in autonomy and harmonization trajectories do not clearly indicate improvement or degradation.`;
}