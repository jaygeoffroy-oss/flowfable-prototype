import type { EngineInspectorGlobalAutonomySeal } from "./engineInspectorGlobalAutonomySeal";

export function buildInspectorGlobalAutonomySummary(
  inspectorGlobalAutonomySeal: EngineInspectorGlobalAutonomySeal
): string {
  const g = inspectorGlobalAutonomySeal.globalAutonomySeal;

  if (g.seal === "Platinum") {
    return `The Inspector demonstrates full autonomous readiness across all tiers. Stability is strong, maintenance is proactive, evolution is healthy, versioning is consistent, and governance integrity is robust. No significant risks were detected, and the system is fully future-ready.`;
  }

  if (g.seal === "Gold") {
    return `The Inspector maintains strong autonomy with minor concerns. Stability or governance trends show early signs of degradation, but overall autonomy remains reliable. Issues requiring attention: ${g.issues.join(", ")}.`;
  }

  if (g.seal === "Silver") {
    return `The Inspector’s autonomy is partially compromised. Structural concerns or recurring issues require attention to prevent long-term degradation. Issues detected: ${g.issues.join(", ")}.`;
  }

  return `The Inspector’s autonomy is critically degraded. Stability, evolution, or governance trends indicate severe risks requiring immediate intervention. Issues detected: ${g.issues.join(", ")}.`;
}