import type { EngineConfidenceResult } from "./engineConfidence";
import type { EngineHealth } from "./engineHealth";
import type { EngineIntegrityResult } from "./engineIntegrity";
import type { EngineStability } from "./engineStability";
import type { GuidanceEngineParams } from "./guidanceEngineParameters";
import type { EngineConsistencyResult } from "./engineConsistency";

export type EngineInspectorSection =
  | "statusBanner"
  | "integritySeal"
  | "confidenceScore"
  | "metaSummary"
  | "expandedMetaSummary"
  | "advisory"
  | "summary"
  | "parameterDelta"
  | "engineHistory"
  | "engineHealth"
  | "engineStability"
  | "currentParams"
  | "nextRunParams";

export type EngineInspectorConfig = {
  statusBanner: boolean;
  integritySeal: boolean;
  confidenceScore: boolean;
  metaSummary: boolean;
  expandedMetaSummary: boolean;
  advisory: boolean;
  summary: boolean;
  parameterDelta: boolean;
  engineHistory: boolean;
  engineHealth: boolean;
  engineStability: boolean;
  currentParams: boolean;
  nextRunParams: boolean;
  order: EngineInspectorSection[];
};

export type EngineInspectorIndex = EngineInspectorConfig;

export function buildInspectorIndex({
  engineStatusBanner,
  engineIntegrity,
  engineConfidence,
  engineMetaSummary,
  expandedEngineMetaSummary,
  engineAdvisory,
  engineSummary,
  parameterDelta,
  engineHistory,
  engineHealth,
  engineStability,
  params,
  nextRunParams
}: {
  engineStatusBanner?: Record<string, unknown>;
  engineIntegrity?: EngineIntegrityResult;
  engineConfidence?: EngineConfidenceResult;
  engineMetaSummary?: string;
  expandedEngineMetaSummary?: string;
  engineAdvisory?: string[];
  engineSummary?: Record<string, unknown>;
  parameterDelta?: Record<string, unknown>;
  engineHistory?: unknown[];
  engineHealth?: EngineHealth;
  engineStability?: EngineStability;
  params?: GuidanceEngineParams;
  nextRunParams?: GuidanceEngineParams;
}): EngineInspectorIndex {
  return {
    statusBanner: !!engineStatusBanner,
    integritySeal: !!engineIntegrity,
    confidenceScore: !!engineConfidence,
    metaSummary: !!engineMetaSummary,
    expandedMetaSummary: !!expandedEngineMetaSummary,
    advisory: !!engineAdvisory,
    summary: !!engineSummary,
    parameterDelta: !!parameterDelta,
    engineHistory: !!engineHistory,
    engineHealth: !!engineHealth,
    engineStability: !!engineStability,
    currentParams: !!params,
    nextRunParams: !!nextRunParams,
    order: [
      "statusBanner",
      "integritySeal",
      "confidenceScore",
      "metaSummary",
      "expandedMetaSummary",
      "advisory",
      "summary",
      "parameterDelta",
      "engineHistory",
      "engineHealth",
      "engineStability",
      "currentParams",
      "nextRunParams"
    ]
  };
}

export const engineInspectorConfig: EngineInspectorConfig = {
  statusBanner: true,
  integritySeal: true,
  confidenceScore: true,
  metaSummary: true,
  expandedMetaSummary: true,
  advisory: true,
  summary: true,
  parameterDelta: true,
  engineHistory: true,
  engineHealth: true,
  engineStability: true,
  currentParams: true,
  nextRunParams: true,
  order: [
    "statusBanner",
    "integritySeal",
    "confidenceScore",
    "metaSummary",
    "expandedMetaSummary",
    "advisory",
    "summary",
    "parameterDelta",
    "engineHistory",
    "engineHealth",
    "engineStability",
    "currentParams",
    "nextRunParams"
  ]
};