import type { EngineInspectorAutonomyHarmonizationSealDelta } from "./engineInspectorAutonomyHarmonizationSealDelta";

export function buildInspectorAutonomyHarmonizationSealDeltaEngineSummary(
  inspectorAutonomyHarmonizationSealDelta: EngineInspectorAutonomyHarmonizationSealDelta
): string {
  const d =
    inspectorAutonomyHarmonizationSealDelta.autonomyHarmonizationSealDelta;

  const classification = d.deltaClassification;
  const trajectory = d.trajectory;
  void trajectory;

  if (classification === "Improving") {
    return `The Autonomy Harmonization Seal Delta Engine reports an improving harmonization trajectory. Cross‑tier alignment strengthened, contradictions decreased, and reinforcing signals increased across autonomy tiers.`;
  }

  if (classification === "Degrading") {
    return `The Autonomy Harmonization Seal Delta Engine reports a degrading harmonization trajectory. Cross‑tier contradictions increased, reinforcement signals weakened, and multi‑tier alignment declined.`;
  }

  if (classification === "Critical") {
    return `The Autonomy Harmonization Seal Delta Engine reports a critical harmonization trajectory. Severe cross‑tier misalignment destabilized the harmonized autonomy field, and contradictions dominate the system’s alignment profile.`;
  }

  if (classification === "Initial") {
    return `The Autonomy Harmonization Seal Delta Engine has generated its first harmonization delta. Cross‑cycle trajectory analysis will begin once additional deltas are available.`;
  }

  return `The Autonomy Harmonization Seal Delta Engine reports a stable harmonization trajectory. Cross‑tier alignment shows no major changes, and reinforcing signals remain consistent across cycles.`;
}