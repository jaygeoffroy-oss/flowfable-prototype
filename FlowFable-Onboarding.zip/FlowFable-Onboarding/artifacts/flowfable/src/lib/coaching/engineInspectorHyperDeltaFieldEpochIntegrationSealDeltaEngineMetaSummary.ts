export function buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineMetaSummary(
  inspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary: string,
  previousHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary?: string
): string {
  const current =
    inspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary;
  const previous =
    previousHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary;

  if (!previous) {
    return `The hyper‑epoch delta engine meta‑summary has been generated for the first time. Cross‑hyper‑epoch engine‑behavior trends will emerge once a second engine summary is available.`;
  }

  const improving =
    current.includes("strengthening") &&
    !previous.includes("strengthening");

  const degrading =
    current.includes("weakening") &&
    !previous.includes("weakening");

  const critical =
    current.includes("collapse‑direction") &&
    !previous.includes("collapse‑direction");

  const mixed =
    current.includes("oscillating") &&
    !previous.includes("oscillating");

  const stable =
    current.includes("stable") &&
    previous.includes("stable");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows strengthening delta‑engine behavior. Reinforcement patterns increased across hyper‑epochs, contradiction patterns diminished, and the system exhibits an upward long‑range structural trajectory.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows weakening delta‑engine behavior. Reinforcement signals faded across hyper‑epochs, contradiction patterns increased, and the system exhibits a downward long‑range structural trajectory.`;
  }

  if (critical) {
    return `Cross‑hyper‑epoch analysis shows collapse‑direction delta‑engine behavior. Structural coherence failed across hyper‑epochs, contradiction patterns dominated, and the system exhibits collapse‑level long‑range trajectory. Immediate corrective action is recommended.`;
  }

  if (mixed) {
    return `Cross‑hyper‑epoch analysis shows oscillating delta‑engine behavior. Reinforcement and contradiction patterns fluctuated unevenly across hyper‑epochs, producing inconsistent long‑range structural evolution.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable delta‑engine behavior. Reinforcement and contradiction patterns remained balanced across hyper‑epochs, producing a flat long‑range structural trajectory.`;
  }

  return `Cross‑hyper‑epoch analysis is inconclusive. Long‑range reinforcement and contradiction patterns do not clearly indicate improvement, degradation, stability, or collapse across hyper‑epochs.`;
}