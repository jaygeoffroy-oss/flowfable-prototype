import type { AdaptiveTuningAdvice } from "./adaptiveTuningAdvice";
import type { EngineHealthStatus } from "./engineHealth";
import type { EngineStabilityAnalysis } from "./engineStability";
import type { GuidanceEngineParameters } from "./guidanceEngineParameters";

export type AutoTunerLog = string[];

export type EngineAutoTunerResult = {
  updatedParams: GuidanceEngineParameters;
  autoTunerLog: AutoTunerLog;
};

export function runEngineAutoTuner({
  params,
  engineHealth,
  engineStability,
  advice
}: {
  params: GuidanceEngineParameters;
  engineHealth: EngineHealthStatus;
  engineStability: EngineStabilityAnalysis;
  advice: AdaptiveTuningAdvice;
}): EngineAutoTunerResult {
  const updated = { ...params };
  const log: string[] = [];

  if (engineHealth.status === "error") {
    updated.riskWeight = Math.max(0.7, params.riskWeight - 0.1);
    updated.scenarioAggression = Math.max(
      0.8,
      params.scenarioAggression - 0.1
    );
    log.push("Reduced riskWeight and scenarioAggression due to error state.");
  } else if (engineHealth.status === "warning") {
    updated.riskWeight = Math.max(0.8, params.riskWeight - 0.05);
    log.push("Mild reduction in riskWeight due to warning state.");
  }

  if (engineStability.stability === "unstable") {
    updated.synergyWeight = params.synergyWeight;
    updated.confidenceSmoothing = params.confidenceSmoothing;
    log.push(
      "Frozen synergyWeight and confidenceSmoothing due to instability."
    );
  } else if (engineStability.stability === "stable") {
    updated.synergyWeight = Math.min(1.5, params.synergyWeight + 0.05);
    log.push("Increased synergyWeight slightly due to stable parameters.");
  }

  advice.advice.forEach(line => {
    if (line.includes("shift categoryBias toward stability")) {
      updated.categoryBias = "stability";
      log.push("Shifted categoryBias toward stability based on advisor.");
    }
    if (line.includes("reduce aggression")) {
      updated.scenarioAggression = Math.max(
        0.8,
        params.scenarioAggression - 0.05
      );
      log.push("Reduced scenarioAggression based on advisor.");
    }
  });

  return {
    updatedParams: updated,
    autoTunerLog: log
  };
}