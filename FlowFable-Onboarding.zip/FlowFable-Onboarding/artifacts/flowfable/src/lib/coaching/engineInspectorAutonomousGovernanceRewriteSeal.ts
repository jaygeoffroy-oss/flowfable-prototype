import type { EngineInspectorAutonomousGovernanceRewrite } from "./engineInspectorAutonomousGovernanceRewrite";

export type EngineInspectorAutonomousGovernanceRewriteSeal = {
  version: string;
  autonomousGovernanceRewriteSeal: {
    seal: string;
    priority: string;
    issues: string[];
    rewriteActions: string[];
  };
};

export function buildInspectorAutonomousGovernanceRewriteSeal(
  inspectorAutonomousGovernanceRewrite: EngineInspectorAutonomousGovernanceRewrite
): EngineInspectorAutonomousGovernanceRewriteSeal {
  const g =
    inspectorAutonomousGovernanceRewrite.autonomousGovernanceRewrite;

  let seal = "Platinum";

  if (g.priority === "Medium") {
    seal = "Gold";
  }

  if (g.priority === "High") {
    seal = "Red";
  }

  if (g.priority === "Low" && g.issues.length > 0) {
    seal = "Silver";
  }

  return {
    version: inspectorAutonomousGovernanceRewrite.version,
    autonomousGovernanceRewriteSeal: {
      seal,
      priority: g.priority,
      issues: g.issues,
      rewriteActions: g.rewriteActions
    }
  };
}