import type { EngineInspectorIndex } from "./engineInspectorConfig";
import type { EngineInspectorManifest } from "./engineInspectorManifest";
import type { EngineInspectorSchema } from "./engineInspectorSchema";
import type { EngineInspectorCapabilities } from "./engineInspectorCapabilities";
import type { EngineInspectorGovernance } from "./engineInspectorGovernance";
import type { EngineInspectorCompliance } from "./engineInspectorCompliance";

export type EngineInspectorCoherence = {
  version: string;
  coherence: {
    indexVsManifest: boolean;
    manifestVsRegistry: boolean;
    registryVsCapabilities: boolean;
    capabilitiesVsGovernance: boolean;
    governanceVsCompliance: boolean;
    complianceVsNarrative: boolean;
    issues: string[];
  };
};

export function buildInspectorCoherenceReport({
  inspectorIndex,
  inspectorManifest,
  inspectorRegistry,
  inspectorCapabilities,
  inspectorGovernance: _inspectorGovernance,
  inspectorComplianceReport,
  inspectorComplianceSummary
}: {
  inspectorIndex: EngineInspectorIndex;
  inspectorManifest: EngineInspectorManifest;
  inspectorRegistry: EngineInspectorSchema;
  inspectorCapabilities: EngineInspectorCapabilities;
  inspectorGovernance: EngineInspectorGovernance;
  inspectorComplianceReport: EngineInspectorCompliance;
  inspectorComplianceSummary?: string;
}): EngineInspectorCoherence {
  const issues: string[] = [];

  const indexVsManifest = inspectorIndex.order.every(key =>
    Boolean(inspectorManifest.blocks[key])
  );
  if (!indexVsManifest) {
    issues.push("Index and Manifest mismatch.");
  }

  const manifestVsRegistry = Object.keys(inspectorManifest.blocks).every(key =>
    Boolean(inspectorRegistry.blocks[key])
  );
  if (!manifestVsRegistry) {
    issues.push("Manifest and Registry mismatch.");
  }

  const registryVsCapabilities = Object.keys(inspectorRegistry.blocks).every(
    key =>
      Object.keys(inspectorCapabilities.capabilities).some(capability =>
        capability.toLowerCase().includes(key.toLowerCase())
      )
  );
  if (!registryVsCapabilities) {
    issues.push("Registry and Capabilities mismatch.");
  }

  const governanceVsCompliance =
    inspectorComplianceReport.compliance.issues.length === 0;
  if (!governanceVsCompliance) {
    issues.push("Governance and Compliance mismatch.");
  }

  const complianceVsNarrative = Boolean(
    inspectorComplianceSummary && inspectorComplianceSummary.length > 0
  );
  if (!complianceVsNarrative) {
    issues.push("Compliance Summary missing or empty.");
  }

  return {
    version: inspectorRegistry.version,
    coherence: {
      indexVsManifest,
      manifestVsRegistry,
      registryVsCapabilities,
      capabilitiesVsGovernance: true,
      governanceVsCompliance,
      complianceVsNarrative,
      issues
    }
  };
}

export function buildInspectorCoherence({
  inspectorIndex,
  inspectorManifest,
  inspectorRegistry,
  inspectorCapabilities,
  inspectorGovernance,
  inspectorCompliance,
  engineMetaSummary,
  expandedEngineMetaSummary
}: {
  inspectorIndex: EngineInspectorIndex;
  inspectorManifest: EngineInspectorManifest;
  inspectorRegistry: EngineInspectorSchema;
  inspectorCapabilities: EngineInspectorCapabilities;
  inspectorGovernance: EngineInspectorGovernance;
  inspectorCompliance: EngineInspectorCompliance;
  engineMetaSummary?: string;
  expandedEngineMetaSummary?: string;
}): EngineInspectorCoherence {
  const issues: string[] = [];
  const manifestBlocks = inspectorManifest.blocks;
  const registryBlocks = inspectorRegistry.blocks;

  const indexVsManifest = inspectorIndex.order.every(key => {
    if (!manifestBlocks[key]) {
      issues.push(`Block '${key}' appears in index but is missing in manifest`);
      return false;
    }
    return true;
  });

  const manifestVsRegistry = Object.keys(manifestBlocks).every(key => {
    const present = Boolean(registryBlocks[key]);
    if (!present) {
      issues.push(`Block '${key}' appears in manifest but is missing in registry`);
    }
    return present;
  });

  const registryVsCapabilities =
    Object.keys(registryBlocks).length > 0 &&
    Object.keys(inspectorCapabilities.capabilities).length > 0;
  if (!registryVsCapabilities) {
    issues.push("Registry and capabilities map are not both populated.");
  }

  const capabilitiesVsGovernance =
    Boolean(inspectorCapabilities.version) &&
    Boolean(inspectorGovernance.version);
  if (!capabilitiesVsGovernance) {
    issues.push("Capabilities and governance versions are incomplete.");
  }

  const governanceVsCompliance =
    inspectorGovernance.version === inspectorCompliance.version &&
    inspectorCompliance.compliance.issues.length === 0;
  if (!governanceVsCompliance) {
    issues.push("Governance and compliance are not fully aligned.");
  }

  const complianceVsNarrative = Boolean(
    engineMetaSummary && expandedEngineMetaSummary
  );
  if (!complianceVsNarrative) {
    issues.push("Compliance narrative summaries are incomplete.");
  }

  return {
    version: inspectorIndex.order.length > 0 ? "1.0.0" : "unknown",
    coherence: {
      indexVsManifest,
      manifestVsRegistry,
      registryVsCapabilities,
      capabilitiesVsGovernance,
      governanceVsCompliance,
      complianceVsNarrative,
      issues
    }
  };
}

export const engineInspectorCoherence: EngineInspectorCoherence = {
  version: "1.0.0",
  coherence: {
    indexVsManifest: true,
    manifestVsRegistry: true,
    registryVsCapabilities: true,
    capabilitiesVsGovernance: true,
    governanceVsCompliance: true,
    complianceVsNarrative: true,
    issues: []
  }
};