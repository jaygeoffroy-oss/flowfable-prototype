import type { EngineInspectorAutonomousStability } from "./engineInspectorAutonomousStability";
import type { EngineInspectorAutonomousMaintenance } from "./engineInspectorAutonomousMaintenance";
import type { EngineInspectorAutonomousEvolutionSeal } from "./engineInspectorAutonomousEvolutionSeal";
import type { EngineInspectorAutonomousVersioning } from "./engineInspectorAutonomousVersioning";
import type { EngineInspectorAutonomousGovernanceRewriteSeal } from "./engineInspectorAutonomousGovernanceRewriteSeal";
import type { EngineInspectorAutonomousGovernanceRewriteMetaSeal } from "./engineInspectorAutonomousGovernanceRewriteMetaSeal";

export type EngineInspectorGlobalAutonomySeal = {
  version: string;
  globalAutonomySeal: {
    seal: string;
    stabilityTrend: string;
    maintenancePriority: string;
    evolutionSeal: string;
    governanceSeal: string;
    governanceMetaSeal: string;
    issues: string[];
  };
};

export function buildInspectorGlobalAutonomySeal({
  inspectorAutonomousStability,
  inspectorAutonomousMaintenance,
  inspectorAutonomousEvolutionSeal,
  inspectorAutonomousVersioning,
  inspectorAutonomousGovernanceRewriteSeal,
  inspectorAutonomousGovernanceRewriteMetaSeal
}: {
  inspectorAutonomousStability: EngineInspectorAutonomousStability;
  inspectorAutonomousMaintenance: EngineInspectorAutonomousMaintenance;
  inspectorAutonomousEvolutionSeal: EngineInspectorAutonomousEvolutionSeal;
  inspectorAutonomousVersioning: EngineInspectorAutonomousVersioning;
  inspectorAutonomousGovernanceRewriteSeal: EngineInspectorAutonomousGovernanceRewriteSeal;
  inspectorAutonomousGovernanceRewriteMetaSeal: EngineInspectorAutonomousGovernanceRewriteMetaSeal;
}): EngineInspectorGlobalAutonomySeal {
  const stability = inspectorAutonomousStability.autonomousStability;
  const maintenance =
    inspectorAutonomousMaintenance.autonomousMaintenance;
  const evolutionSeal =
    inspectorAutonomousEvolutionSeal.autonomousEvolutionSeal;
  const versioning = inspectorAutonomousVersioning.autonomousVersioning;
  const governanceSeal =
    inspectorAutonomousGovernanceRewriteSeal.autonomousGovernanceRewriteSeal;
  const governanceMeta =
    inspectorAutonomousGovernanceRewriteMetaSeal
      .autonomousGovernanceRewriteMetaSeal;

  let seal = "Platinum";
  const issues = [
    ...stability.issues,
    ...maintenance.issues,
    ...evolutionSeal.issues,
    ...governanceSeal.issues
  ];

  const degrading =
    stability.trend === "Degrading" ||
    evolutionSeal.seal === "Gold" ||
    governanceMeta.metaSeal === "Degrading";

  const critical =
    stability.trend === "Critical" ||
    evolutionSeal.seal === "Red" ||
    governanceMeta.metaSeal === "Critical";

  if (critical) {
    seal = "Red";
  } else if (degrading) {
    seal = "Gold";
  } else if (issues.length > 0) {
    seal = "Silver";
  }

  return {
    version: versioning.newVersion,
    globalAutonomySeal: {
      seal,
      stabilityTrend: stability.trend,
      maintenancePriority: maintenance.priority,
      evolutionSeal: evolutionSeal.seal,
      governanceSeal: governanceSeal.seal,
      governanceMetaSeal: governanceMeta.metaSeal,
      issues
    }
  };
}