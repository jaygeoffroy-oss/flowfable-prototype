import type {
  EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta,
  EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta
} from "./engineInspectorHyperDeltaFieldEpochIntegrationSealDelta";

type HyperDeltaFieldEpochIntegrationSealDelta =
  | EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta
  | EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta;

export function buildInspectorHyperDeltaFieldEpochIntegrationSealDeltaEngineSummary(
  inspectorHyperDeltaFieldEpochIntegrationSealDelta: HyperDeltaFieldEpochIntegrationSealDelta
): string {
  const d =
    inspectorHyperDeltaFieldEpochIntegrationSealDelta
      .hyperDeltaFieldEpochIntegrationSealDelta;

  const classification = d.deltaClassification;

  if (classification === "Improving") {
    return `The hyper‑epoch delta engine reports strengthening structural coherence. Reinforcement patterns increased across hyper‑epochs, contradiction patterns diminished, and the system exhibits an upward long‑range trajectory.`;
  }

  if (classification === "Degrading") {
    return `The hyper‑epoch delta engine reports weakening structural coherence. Reinforcement signals faded across hyper‑epochs, contradiction patterns increased, and the system exhibits a downward long‑range trajectory.`;
  }

  if (classification === "Critical") {
    return `The hyper‑epoch delta engine reports collapse‑direction structural behavior. Structural coherence failed across hyper‑epochs, contradiction patterns dominated, and the system exhibits collapse‑level long‑range trajectory. Immediate corrective action is recommended.`;
  }

  if (classification === "Mixed") {
    return `The hyper‑epoch delta engine reports oscillating structural coherence. Reinforcement and contradiction patterns fluctuated unevenly across hyper‑epochs, producing inconsistent long‑range evolution.`;
  }

  if (classification === "Initial") {
    return `The hyper‑epoch delta engine has produced its first delta. Long‑range structural trends will emerge once additional hyper‑epochs are available.`;
  }

  return `The hyper‑epoch delta engine reports stable structural coherence. Reinforcement and contradiction patterns balanced out across hyper‑epochs, producing a flat long‑range trajectory.`;
}