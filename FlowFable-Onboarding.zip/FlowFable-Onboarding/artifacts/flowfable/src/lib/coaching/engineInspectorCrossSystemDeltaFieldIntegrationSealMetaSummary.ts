export function buildInspectorCrossSystemDeltaFieldIntegrationSealMetaSummary(
  inspectorCrossSystemDeltaFieldIntegrationSealSummary: string,
  previousCrossSystemDeltaFieldIntegrationSealSummary?: string
): string {
  const current =
    inspectorCrossSystemDeltaFieldIntegrationSealSummary;
  const previous =
    previousCrossSystemDeltaFieldIntegrationSealSummary;

  if (!previous) {
    return `The global delta seal meta‑summary has been generated for the first time. Cross‑cycle global seal trends will begin once a second meta‑summary is available.`;
  }

  const improving =
    current.includes("strong") &&
    !previous.includes("strong");

  const degrading =
    current.includes("misaligned") &&
    !previous.includes("misaligned");

  const stabilizing =
    current === previous;

  const mixed =
    current.includes("partial") &&
    !previous.includes("partial");

  if (improving) {
    return `Cross‑cycle analysis shows improving global delta coherence. Reinforcing signals across autonomy, harmonization, unified integration, and unified‑seal deltas have strengthened, reducing contradictions and elevating the global delta seal.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows degrading global delta coherence. Contradictions across autonomy, harmonization, unified integration, and unified‑seal deltas have increased, weakening the global delta seal and destabilizing the merged delta ecosystem.`;
  }

  if (mixed) {
    return `Cross‑cycle analysis shows mixed global delta behavior. Reinforcing and contradictory elements shifted unevenly across the merged delta ecosystem, producing an ambiguous global seal trajectory.`;
  }

  if (stabilizing) {
    return `Cross‑cycle global delta seal behavior remains stable. The merged autonomy‑harmonization‑unified delta ecosystem continues to evolve consistently across cycles, with no major shifts in global coherence.`;
  }

  return `Cross‑cycle global delta signals do not clearly indicate improvement or degradation. Partial shifts across the merged delta ecosystem produce an indeterminate global seal trajectory.`;
}