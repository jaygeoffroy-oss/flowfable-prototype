import type { EngineInspectorHyperDeltaFieldEpochIntegrationSeal } from "./engineInspectorHyperDeltaFieldEpochIntegrationSeal";

export type EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta = {
  version: string;
  hyperDeltaFieldEpochIntegrationSealDelta: {
    previousSeal: string | null;
    currentSeal: string;
    deltaClassification: string;
    contributingFactors: string[];
    trajectory: string;
  };
};

export type EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta =
  {
    version: string;
    hyperDeltaFieldEpochIntegrationSealDelta: {
      previousHyperEpochSeal: string | null;
      currentHyperEpochSeal: string;
      deltaClassification: string;
      contributingFactors: string[];
      trajectory: string;
    };
  };

export function buildInspectorHyperDeltaFieldEpochIntegrationSealDelta(
  inspectorHyperDeltaFieldEpochIntegrationSeal: EngineInspectorHyperDeltaFieldEpochIntegrationSeal,
  previousHyperDeltaFieldEpochIntegrationSeal?: EngineInspectorHyperDeltaFieldEpochIntegrationSeal
): EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta;
export function buildInspectorHyperDeltaFieldEpochIntegrationSealDelta(
  inspectorHyperDeltaFieldEpochIntegrationSealMetaSummary: string,
  previousInspectorHyperDeltaFieldEpochIntegrationSealMetaSummary?: string
): EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta;
export function buildInspectorHyperDeltaFieldEpochIntegrationSealDelta(
  inspectorHyperDeltaFieldEpochIntegrationSeal:
    | EngineInspectorHyperDeltaFieldEpochIntegrationSeal
    | string,
  previousHyperDeltaFieldEpochIntegrationSeal?:
    | EngineInspectorHyperDeltaFieldEpochIntegrationSeal
    | string
):
  | EngineInspectorHyperDeltaFieldEpochIntegrationSealDelta
  | EngineInspectorHyperDeltaFieldEpochIntegrationSealMetaSummaryDelta {
  if (typeof inspectorHyperDeltaFieldEpochIntegrationSeal === "string") {
    const current = inspectorHyperDeltaFieldEpochIntegrationSeal;
    const previous =
      typeof previousHyperDeltaFieldEpochIntegrationSeal === "string"
        ? previousHyperDeltaFieldEpochIntegrationSeal
        : undefined;

    if (!previous) {
      return {
        version: "1.0.0",
        hyperDeltaFieldEpochIntegrationSealDelta: {
          previousHyperEpochSeal: null,
          currentHyperEpochSeal: current,
          deltaClassification: "Initial",
          contributingFactors: [],
          trajectory: "Stable"
        }
      };
    }

    let deltaClassification = "Stable";
    const contributingFactors: string[] = [];

    const improving =
      current.includes("strong") &&
      !previous.includes("strong");

    const degrading =
      current.includes("compromised") &&
      !previous.includes("compromised");

    const critical =
      current.includes("collapsed") &&
      !previous.includes("collapsed");

    const mixed =
      current.includes("moderate") &&
      !previous.includes("moderate");

    if (improving) {
      deltaClassification = "Improving";
      contributingFactors.push(
        "Reinforcement patterns increased across hyper‑epochs",
        "Contradiction patterns diminished"
      );
    }

    if (degrading) {
      deltaClassification = "Degrading";
      contributingFactors.push(
        "Reinforcement signals weakened",
        "Contradiction patterns increased"
      );
    }

    if (critical) {
      deltaClassification = "Critical";
      contributingFactors.push(
        "Structural coherence collapsed across hyper‑epochs",
        "Contradiction patterns dominated the system"
      );
    }

    if (mixed) {
      deltaClassification = "Mixed";
      contributingFactors.push(
        "Structural coherence fluctuated unevenly",
        "Reinforcement and contradiction patterns oscillated"
      );
    }

    const trajectory =
      deltaClassification === "Improving"
        ? "Upward"
        : deltaClassification === "Degrading"
          ? "Downward"
          : deltaClassification === "Critical"
            ? "Collapse"
            : deltaClassification === "Mixed"
              ? "Oscillating"
              : "Stable";

    return {
      version: "1.0.0",
      hyperDeltaFieldEpochIntegrationSealDelta: {
        previousHyperEpochSeal: previous,
        currentHyperEpochSeal: current,
        deltaClassification,
        contributingFactors,
        trajectory
      }
    };
  }

  const current =
    inspectorHyperDeltaFieldEpochIntegrationSeal
      .hyperDeltaFieldEpochIntegrationSeal;

  const previous =
    typeof previousHyperDeltaFieldEpochIntegrationSeal !== "string"
      ? previousHyperDeltaFieldEpochIntegrationSeal
        ?.hyperDeltaFieldEpochIntegrationSeal
      : undefined;

  if (!previous) {
    return {
      version: inspectorHyperDeltaFieldEpochIntegrationSeal.version,
      hyperDeltaFieldEpochIntegrationSealDelta: {
        previousSeal: null,
        currentSeal: current.seal,
        deltaClassification: "Initial",
        contributingFactors: [],
        trajectory: "Stable"
      }
    };
  }

  let deltaClassification = "Stable";
  const contributingFactors: string[] = [];

  if (current.seal !== previous.seal) {
    if (current.seal === "Epoch‑Gold") {
      deltaClassification = "Improving";
      contributingFactors.push(
        "Long‑range reinforcement patterns accumulated",
        "Contradiction patterns diminished across epochs"
      );
    } else if (
      current.seal === "Epoch‑Silver" &&
      previous.seal === "Epoch‑Gold"
    ) {
      deltaClassification = "Degrading";
      contributingFactors.push("Reinforcement signals weakened across epochs");
    } else if (current.seal === "Epoch‑Bronze") {
      deltaClassification = "Degrading";
      contributingFactors.push(
        "Contradiction patterns accumulated across epochs"
      );
    } else if (current.seal === "Epoch‑Red") {
      deltaClassification = "Critical";
      contributingFactors.push(
        "Severe multi‑epoch misalignment",
        "Persistent contradictions dominated structural evolution"
      );
    }
  }

  const trajectory =
    deltaClassification === "Improving"
      ? "Upward"
      : deltaClassification === "Degrading"
        ? "Downward"
        : deltaClassification === "Critical"
          ? "Collapse"
          : "Stable";

  return {
    version: inspectorHyperDeltaFieldEpochIntegrationSeal.version,
    hyperDeltaFieldEpochIntegrationSealDelta: {
      previousSeal: previous.seal,
      currentSeal: current.seal,
      deltaClassification,
      contributingFactors,
      trajectory
    }
  };
}