import type { EngineInspectorHarmonizationDeltaIntegrationSealDelta } from "./engineInspectorHarmonizationDeltaIntegrationSealDelta";

export function buildInspectorHarmonizationDeltaIntegrationSealDeltaSummary(
  inspectorHarmonizationDeltaIntegrationSealDelta: EngineInspectorHarmonizationDeltaIntegrationSealDelta
): string {
  const d =
    inspectorHarmonizationDeltaIntegrationSealDelta
      .harmonizationDeltaIntegrationSealDelta;

  if (d.deltaClassification === "Improving") {
    return `The global delta seal improved this cycle, indicating stronger cross‑system coherence. Reinforcement signals increased across autonomy, harmonization, unified integration, and unified‑seal deltas, reducing contradictions and producing an upward global delta trajectory.`;
  }

  if (d.deltaClassification === "Degrading") {
    return `The global delta seal degraded this cycle, reflecting increased cross‑system contradictions or weakened reinforcement across the merged delta ecosystem. Global delta coherence declined, resulting in a downward trajectory.`;
  }

  if (d.deltaClassification === "Critical") {
    return `The global delta seal entered a critical state. Severe cross‑system misalignment destabilized the merged autonomy‑harmonization‑unified delta field, with contradictions dominating global delta behavior. Immediate corrective action is recommended.`;
  }

  if (d.deltaClassification === "Initial") {
    return `This is the first global delta seal delta. Cross‑cycle global delta trends will begin once additional cycles are available for comparison.`;
  }

  return `The global delta seal remained stable this cycle. Cross‑system delta alignment did not significantly change, and the merged delta ecosystem maintained its previous trajectory.`;
}