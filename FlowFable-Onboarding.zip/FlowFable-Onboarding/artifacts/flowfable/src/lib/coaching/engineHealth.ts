export type EngineHealthStatus = {
  status: "healthy" | "warning" | "error";
  issues: string[];
};

export type EngineHealth = EngineHealthStatus;

export function assessEngineHealth(flow: any): EngineHealthStatus {
  const issues: string[] = [];
  const {
    riskMaps,
    synergyMaps,
    strategies,
    optimizedScenarios,
    confidence,
    personalizedGuidance
  } = flow ?? {};

  if (!Array.isArray(riskMaps) || riskMaps.length === 0) {
    issues.push("Risk maps are missing or empty.");
  } else {
    const anyNaN = riskMaps.some(
      (projection: any) =>
        !Array.isArray(projection) ||
        projection.some((point: any) => Number.isNaN(point?.risk))
    );
    if (anyNaN) issues.push("Risk maps contain NaN values.");
  }

  if (!Array.isArray(synergyMaps) || synergyMaps.length === 0) {
    issues.push("Synergy maps are missing or empty.");
  }

  if (!Array.isArray(strategies) || strategies.length === 0) {
    issues.push("Strategies are missing or empty.");
  } else if (strategies.some((strategy: any) => strategy.score < 0)) {
    issues.push("Some strategy scores are negative.");
  }

  if (!Array.isArray(optimizedScenarios) || optimizedScenarios.length === 0) {
    issues.push("Optimized scenarios are missing or empty.");
  }

  if (confidence < 0 || confidence > 1.5) {
    issues.push("Confidence value is out of expected bounds.");
  }

  if (
    !Array.isArray(personalizedGuidance) ||
    personalizedGuidance.length === 0
  ) {
    issues.push("Personalized guidance is missing or empty.");
  }

  let status: EngineHealthStatus["status"] = "healthy";
  if (issues.length > 0) {
    status = issues.some(issue => {
      const normalized = issue.toLowerCase();
      return normalized.includes("missing") || normalized.includes("nan");
    })
      ? "error"
      : "warning";
  }

  return { status, issues };
}