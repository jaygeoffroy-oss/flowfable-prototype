export function buildInspectorHyperDeltaFieldEpochIntegrationSealAbsolutePrimeMetaSummary(
  currentAbsolutePrimeSummary: string,
  previousAbsolutePrimeSummary?: string
): string {
  if (!previousAbsolutePrimeSummary) {
    return `Cross‑hyper‑epoch sixth‑order reliability trends cannot yet be determined. A second Absolute‑Prime summary is required to establish long‑range Absolute‑Prime behavior.`;
  }

  const improving =
    currentAbsolutePrimeSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousAbsolutePrimeSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const degrading =
    currentAbsolutePrimeSummary.includes(
      "medium meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousAbsolutePrimeSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const collapsing =
    currentAbsolutePrimeSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousAbsolutePrimeSummary.includes(
      "low meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const fluctuating =
    currentAbsolutePrimeSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    !previousAbsolutePrimeSummary.includes(
      "variable meta‑meta‑meta‑meta‑meta‑reliability"
    );

  const stable =
    currentAbsolutePrimeSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑reliability"
    ) &&
    previousAbsolutePrimeSummary.includes(
      "high meta‑meta‑meta‑meta‑meta‑reliability"
    );

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Absolute‑Prime meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the sixth‑order meta‑layer, contradiction patterns diminish, and long‑range Absolute‑Prime coherence strengthens.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Absolute‑Prime meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the sixth‑order meta‑layer, contradiction signals increase, and long‑range Absolute‑Prime coherence declines.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Absolute‑Prime meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the sixth‑order meta‑layer, contradiction patterns dominate, and long‑range Absolute‑Prime coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Absolute‑Prime meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the sixth‑order meta‑layer, producing unstable long‑range Absolute‑Prime coherence.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Absolute‑Prime meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the sixth‑order meta‑layer, producing a flat long‑range Absolute‑Prime trajectory.`;
  }

  return `Cross‑hyper‑epoch Absolute‑Prime trends are inconclusive. Reinforcement and contradiction patterns do not clearly indicate improvement, degradation, collapse, or stability.`;
}