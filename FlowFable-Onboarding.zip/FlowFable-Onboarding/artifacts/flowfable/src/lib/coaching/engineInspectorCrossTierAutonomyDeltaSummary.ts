import type { EngineInspectorCrossTierAutonomyDelta } from "./engineInspectorCrossTierAutonomyDelta";

export function buildInspectorCrossTierAutonomyDeltaSummary(
  inspectorCrossTierAutonomyDelta: EngineInspectorCrossTierAutonomyDelta
): string {
  const delta = inspectorCrossTierAutonomyDelta.crossTierAutonomyDelta;

  if (delta.deltaClassification === "Improving") {
    return `The Inspector’s unified autonomy trajectory improved this cycle. Cross‑tier signals indicate stronger stability, healthier evolution, and reduced governance risks. Improvements include: ${delta.crossTierImprovements.join(", ")}. Risks remain minimal: ${delta.crossTierRisks.join(", ")}.`;
  }

  if (delta.deltaClassification === "Degrading") {
    return `The Inspector’s unified autonomy trajectory degraded this cycle. Cross‑tier signals show weakening evolution, emerging governance concerns, or declining stability. Notable risks include: ${delta.crossTierRisks.join(", ")}. Improvements detected: ${delta.crossTierImprovements.join(", ")}.`;
  }

  if (delta.deltaClassification === "Critical") {
    return `The Inspector’s unified autonomy trajectory entered a critical state. Multiple autonomy tiers show severe degradation, requiring immediate intervention. Critical risks include: ${delta.crossTierRisks.join(", ")}. Improvements are insufficient to offset the decline: ${delta.crossTierImprovements.join(", ")}.`;
  }

  return `The Inspector’s unified autonomy trajectory remained stable this cycle. No major cross‑tier changes were detected. Minor improvements include: ${delta.crossTierImprovements.join(", ")}. Risks remain: ${delta.crossTierRisks.join(", ")}.`;
}