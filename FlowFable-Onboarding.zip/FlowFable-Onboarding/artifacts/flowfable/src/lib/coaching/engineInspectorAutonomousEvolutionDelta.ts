import type { EngineInspectorAutonomousEvolutionSeal } from "./engineInspectorAutonomousEvolutionSeal";

export type EngineInspectorAutonomousEvolutionDelta = {
  version: string;
  autonomousEvolutionDelta: {
    cycle: number;
    previousSeal: string | null;
    currentSeal: string;
    deltaClassification: string;
    changes: string[];
    pendingEvolution: string[];
    regressionRisks: string[];
  };
};

export function buildInspectorAutonomousEvolutionDelta({
  inspectorAutonomousEvolutionSeal,
  previousAutonomousEvolutionSeal,
  cycleNumber
}: {
  inspectorAutonomousEvolutionSeal: EngineInspectorAutonomousEvolutionSeal;
  previousAutonomousEvolutionSeal?: EngineInspectorAutonomousEvolutionSeal;
  cycleNumber: number;
}): EngineInspectorAutonomousEvolutionDelta {
  const current = inspectorAutonomousEvolutionSeal.autonomousEvolutionSeal;
  const previous = previousAutonomousEvolutionSeal?.autonomousEvolutionSeal;
  let deltaClassification = "Neutral";
  const changes: string[] = [];
  const pendingEvolution: string[] = [];
  const regressionRisks: string[] = [];

  if (previous && current.seal !== previous.seal) {
    if (current.seal === "Platinum" && previous.seal === "Gold") {
      deltaClassification = "Positive";
      changes.push("Evolution readiness improved");
    } else if (current.seal === "Gold" && previous.seal === "Platinum") {
      deltaClassification = "Negative";
      changes.push("Evolution readiness degraded");
    } else if (current.seal === "Red") {
      deltaClassification = "Critical";
      changes.push("Evolution readiness collapsed");
    }
  }

  if (current.evolutionPriority === "Medium") {
    pendingEvolution.push(
      "Adaptive governance thresholds",
      "Predictive coherence modeling"
    );
  }

  if (current.evolutionPriority === "High") {
    pendingEvolution.push(
      "Rebuild governance-rule hierarchy",
      "Multi-layer coherence recalibration"
    );
    regressionRisks.push("Governance mismatch", "Coherence mismatch");
  }

  return {
    version: inspectorAutonomousEvolutionSeal.version,
    autonomousEvolutionDelta: {
      cycle: cycleNumber,
      previousSeal: previous?.seal ?? null,
      currentSeal: current.seal,
      deltaClassification,
      changes,
      pendingEvolution,
      regressionRisks
    }
  };
}