import type { EngineInspectorAutonomousStability } from "./engineInspectorAutonomousStability";
import type { EngineInspectorAutonomousMaintenance } from "./engineInspectorAutonomousMaintenance";
import type { EngineInspectorAutonomousEvolution } from "./engineInspectorAutonomousEvolution";
import type { EngineInspectorMetaGovernanceIntegrity } from "./engineInspectorMetaGovernanceIntegrity";

export type EngineInspectorAutonomousEvolutionSeal = {
  version: string;
  autonomousEvolutionSeal: {
    seal: string;
    stabilityTrend: string;
    maintenancePriority: string;
    evolutionPriority: string;
    governanceIntegrity: boolean;
    issues: string[];
  };
};

export function buildInspectorAutonomousEvolutionSeal({
  inspectorAutonomousStability,
  inspectorAutonomousMaintenance,
  inspectorAutonomousEvolution,
  inspectorMetaGovernanceIntegrityReport
}: {
  inspectorAutonomousStability: EngineInspectorAutonomousStability;
  inspectorAutonomousMaintenance: EngineInspectorAutonomousMaintenance;
  inspectorAutonomousEvolution: EngineInspectorAutonomousEvolution;
  inspectorMetaGovernanceIntegrityReport: EngineInspectorMetaGovernanceIntegrity;
}): EngineInspectorAutonomousEvolutionSeal {
  const stability = inspectorAutonomousStability.autonomousStability;
  const maintenance = inspectorAutonomousMaintenance.autonomousMaintenance;
  const evolution = inspectorAutonomousEvolution.autonomousEvolution;
  const metaGovInt =
    inspectorMetaGovernanceIntegrityReport.metaGovernanceIntegrity;

  const issues = [
    ...stability.issues,
    ...maintenance.issues,
    ...evolution.issues,
    ...metaGovInt.issues
  ];

  const stable = stability.trend === "Stable";
  const degrading = stability.trend === "Degrading";
  const critical = stability.trend === "Critical";
  const maintenanceLow = maintenance.priority === "Low";
  const maintenanceMedium = maintenance.priority === "Medium";
  const maintenanceHigh = maintenance.priority === "High";
  const evolutionLow = evolution.priority === "Low";
  const evolutionMedium = evolution.priority === "Medium";
  const evolutionHigh = evolution.priority === "High";
  const governanceStable =
    metaGovInt.stableAcrossVersions &&
    metaGovInt.durableAcrossChanges &&
    metaGovInt.resilientToExtensions &&
    metaGovInt.internallyRobust;

  let seal = "Platinum";
  if (stable && maintenanceLow && evolutionLow && governanceStable) {
    seal = "Platinum";
  } else if (degrading || maintenanceMedium || evolutionMedium) {
    seal = "Gold";
  } else if (critical || maintenanceHigh || evolutionHigh) {
    seal = "Red";
  } else {
    seal = "Silver";
  }

  return {
    version: inspectorAutonomousEvolution.version,
    autonomousEvolutionSeal: {
      seal,
      stabilityTrend: stability.trend,
      maintenancePriority: maintenance.priority,
      evolutionPriority: evolution.priority,
      governanceIntegrity: governanceStable,
      issues
    }
  };
}