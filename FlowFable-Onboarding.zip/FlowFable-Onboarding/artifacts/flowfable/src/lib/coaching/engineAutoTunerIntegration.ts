import { buildAdaptiveTuningAdvice } from "./adaptiveTuningAdvisorEngine";
import { analyzeEngineStability } from "./engineStabilityAnalyzer";
import { runEngineAutoTuner } from "./engineAutoTuner";

export function integrateAutoTuner(flow: any) {
  const engineStability = analyzeEngineStability(flow.engineHistory ?? []);
  const advice = buildAdaptiveTuningAdvice({
    engineHealth: flow.engineHealth,
    engineStability,
    params: flow.params
  });

  const { updatedParams, autoTunerLog } = runEngineAutoTuner({
    params: flow.params,
    engineHealth: flow.engineHealth,
    engineStability,
    advice
  });

  return {
    ...flow,
    nextRunParams: updatedParams,
    autoTunerLog
  };
}