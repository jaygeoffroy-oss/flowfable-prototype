export function buildInspectorHyperDeltaFieldEpochIntegrationMetaSummarySummary(
  inspectorHyperDeltaFieldEpochIntegrationMetaSummary: string
): string {
  const m = inspectorHyperDeltaFieldEpochIntegrationMetaSummary;

  if (m.includes("exceptionally high")) {
    return `Hyper‑epoch structural coherence is extremely strong. Reinforcement patterns dominate across hyper‑epochs, contradiction patterns remain minimal, and the delta ecosystem exhibits sustained upward long‑range evolution.`;
  }

  if (m.includes("strong across hyper‑epochs")) {
    return `Hyper‑epoch structural coherence is strong. Reinforcement patterns outweigh contradictions, producing a stable upward or stable‑flat long‑range trajectory.`;
  }

  if (m.includes("moderate across hyper‑epochs")) {
    return `Hyper‑epoch structural coherence is moderate. Reinforcement and contradiction patterns fluctuate, producing oscillating or uneven long‑range structural evolution.`;
  }

  if (m.includes("severely compromised")) {
    return `Hyper‑epoch structural coherence is severely compromised. Contradiction patterns dominate, reinforcement signals collapse, and the delta ecosystem exhibits downward or collapse‑level long‑range evolution. Immediate corrective action is recommended.`;
  }

  if (m.includes("failed across hyper‑epochs")) {
    return `Hyper‑epoch structural coherence has collapsed. Contradiction patterns overwhelm reinforcement signals, and the delta ecosystem is in a state of long‑range structural failure. Emergency corrective action is required.`;
  }

  return `Hyper‑epoch structural coherence cannot yet be determined. Additional hyper‑epochs are required to establish a clear long‑range structural trend.`;
}