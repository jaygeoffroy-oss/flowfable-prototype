import type { GuidanceEngineParams } from "./guidanceEngineParameters";
import type { EngineHealth } from "./engineHealth";
import type { EngineStability } from "./engineStability";
import type { EngineParameterSnapshot } from "./engineParameterSnapshotLogger";

export type EngineConsistencyResult = {
  parameterConsistency: boolean;
  stabilityConsistency: boolean;
  healthConsistency: boolean;
  historyConsistency: boolean;
  autoTunerConsistency: boolean;
  summaryConsistency: boolean;
  issues: string[];
};

export function computeEngineConsistency({
  params,
  nextRunParams,
  engineStability,
  engineHealth,
  engineHistory,
  parameterDelta,
  engineSummary
}: {
  params: GuidanceEngineParams;
  nextRunParams?: GuidanceEngineParams;
  engineStability?: EngineStability;
  engineHealth?: EngineHealth;
  engineHistory?: EngineParameterSnapshot[];
  parameterDelta?: Record<string, any>;
  engineSummary?: Record<string, any>;
}): EngineConsistencyResult {
  const issues: string[] = [];

  const parameterConsistency =
    nextRunParams &&
    Object.keys(params).every(
      key =>
        typeof nextRunParams[key as keyof GuidanceEngineParams] !== "undefined"
    );

  if (!parameterConsistency) {
    issues.push("Next-run parameters missing keys from current parameters.");
  }

  const stabilityStatus =
    (engineStability as EngineStability & { status?: string } | undefined)
      ?.status ?? engineStability?.stability;
  const stabilityConsistency =
    engineStability && stabilityStatus !== "unknown";

  if (!stabilityConsistency) {
    issues.push("Engine stability status is unknown.");
  }

  const healthStatus = (
    engineHealth as unknown as { status?: string } | undefined
  )?.status;
  const healthConsistency = engineHealth && healthStatus !== "unknown";

  if (!healthConsistency) {
    issues.push("Engine health status is unknown.");
  }

  const historyConsistency = engineHistory && engineHistory.length > 0;

  if (!historyConsistency) {
    issues.push("Engine history is empty.");
  }

  const autoTunerConsistency = parameterDelta && nextRunParams;

  if (!autoTunerConsistency) {
    issues.push("Parameter delta or next-run parameters missing.");
  }

  const summaryConsistency =
    engineSummary &&
    typeof engineSummary.currentParams !== "undefined";

  if (!summaryConsistency) {
    issues.push("Engine summary missing required fields.");
  }

  return {
    parameterConsistency: Boolean(parameterConsistency),
    stabilityConsistency: Boolean(stabilityConsistency),
    healthConsistency: Boolean(healthConsistency),
    historyConsistency: Boolean(historyConsistency),
    autoTunerConsistency: Boolean(autoTunerConsistency),
    summaryConsistency: Boolean(summaryConsistency),
    issues
  };
}