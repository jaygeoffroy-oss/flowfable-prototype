import type { EngineInspectorAutonomousGovernanceRewriteMetaSeal } from "./engineInspectorAutonomousGovernanceRewriteMetaSeal";

export function buildInspectorAutonomousGovernanceRewriteMetaSealSummary(
  inspectorAutonomousGovernanceRewriteMetaSeal: EngineInspectorAutonomousGovernanceRewriteMetaSeal
): string {
  const meta =
    inspectorAutonomousGovernanceRewriteMetaSeal.autonomousGovernanceRewriteMetaSeal;

  if (meta.metaSeal === "Improving") {
    return `The Inspector’s governance rewrite readiness improved this cycle. The governance model shows stronger resilience, fewer issues, and a more stable rewrite trajectory. Positive changes include: ${meta.changes.join(", ")}. Issue trend: ${meta.issuesTrend.join(", ")}.`;
  }

  if (meta.metaSeal === "Degrading") {
    return `The Inspector’s governance rewrite readiness degraded this cycle. Governance stability weakened or rewrite issues increased. Notable changes include: ${meta.changes.join(", ")}. Issue trend: ${meta.issuesTrend.join(", ")}.`;
  }

  if (meta.metaSeal === "Critical") {
    return `The Inspector’s governance rewrite readiness entered a critical state. Governance integrity is compromised and high‑priority rewrite actions are required. Critical changes include: ${meta.changes.join(", ")}. Issue trend: ${meta.issuesTrend.join(", ")}.`;
  }

  return `The Inspector’s governance rewrite readiness remained stable across cycles. No major changes were detected. Issue trend: ${meta.issuesTrend.join(", ")}.`;
}