import type { EngineInspectorAutonomousEvolutionSeal } from "./engineInspectorAutonomousEvolutionSeal";

export function buildInspectorAutonomousEvolutionSummary(
  inspectorAutonomousEvolutionSeal: EngineInspectorAutonomousEvolutionSeal
): string {
  const seal =
    inspectorAutonomousEvolutionSeal.autonomousEvolutionSeal;

  if (seal.seal === "Platinum") {
    return `The Inspector is fully future-ready. Stability is strong, maintenance needs are minimal, evolution proposals are low-priority, and governance integrity is robust. No evolutionary risks were detected.`;
  }

  if (seal.seal === "Gold") {
    return `The Inspector is evolution-ready with minor concerns. Stability shows early signs of degradation or maintenance needs are moderate. Evolution proposals are meaningful but not urgent. Issues requiring attention: ${seal.issues.join(", ")}.`;
  }

  if (seal.seal === "Silver") {
    return `The Inspector requires evolutionary improvement. Stability or governance integrity is partially compromised, and evolution proposals carry medium to high priority. Issues detected: ${seal.issues.join(", ")}.`;
  }

  return `The Inspector requires critical evolutionary intervention. Stability is degrading severely or governance integrity is compromised. Evolution proposals are high-priority and essential. Issues detected: ${seal.issues.join(", ")}.`;
}