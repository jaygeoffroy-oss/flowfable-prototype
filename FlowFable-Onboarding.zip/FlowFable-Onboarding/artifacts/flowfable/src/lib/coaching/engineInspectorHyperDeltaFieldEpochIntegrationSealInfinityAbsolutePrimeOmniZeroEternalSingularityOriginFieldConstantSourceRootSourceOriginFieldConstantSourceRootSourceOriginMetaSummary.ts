export function buildInspectorHyperDeltaFieldEpochIntegrationSealInfinityAbsolutePrimeOmniZeroEternalSingularityOriginFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginMetaSummary(
  currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary: string,
  previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary: string | null
): string {
  if (!previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary) {
    return `Cross‑hyper‑epoch sixtieth‑order reliability trends cannot yet be determined. A second Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin summary is required to establish long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin behavior.`;
  }

  const improving =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("high meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("high meta‑meta‑meta");

  const degrading =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("medium meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("high meta‑meta‑meta");

  const collapsing =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("low meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("low meta‑meta‑meta");

  const fluctuating =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("variable meta‑meta‑meta") &&
    !previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("variable meta‑meta‑meta");

  const stable =
    currentFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("high meta‑meta‑meta") &&
    previousFieldConstantSourceRootSourceOriginFieldConstantSourceRootSourceOriginSummary.includes("high meta‑meta‑meta");

  if (improving) {
    return `Cross‑hyper‑epoch analysis shows improving Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns stabilize at the sixtieth‑order meta‑layer, contradiction patterns diminish, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin coherence strengthens with stable root‑source‑origin‑field‑constant‑source‑root‑source‑origin‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑constant‑source‑root‑source‑origin‑invariant behavior.`;
  }

  if (degrading) {
    return `Cross‑hyper‑epoch analysis shows degrading Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement patterns weaken at the sixtieth‑order meta‑layer, contradiction signals increase, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin coherence declines away from invariant stability.`;
  }

  if (collapsing) {
    return `Cross‑hyper‑epoch analysis shows collapsing Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Structural coherence fails at the sixtieth‑order meta‑layer, contradiction patterns dominate, and long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin coherence enters collapse‑direction behavior. Immediate corrective action is recommended.`;
  }

  if (fluctuating) {
    return `Cross‑hyper‑epoch analysis shows fluctuating Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns oscillate at the sixtieth‑order meta‑layer, producing unstable long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin coherence with inconsistent root‑source‑origin‑field‑constant‑source‑root‑source‑origin‑absolute‑prime‑omni‑zero‑eternal‑singularity‑origin‑field‑constant‑source‑root‑source‑origin‑field‑constant‑source‑root‑source‑origin‑invariant behavior.`;
  }

  if (stable) {
    return `Cross‑hyper‑epoch analysis shows stable Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑meta‑reliability. Reinforcement and contradiction patterns remain balanced at the sixtieth‑order meta‑layer, producing a flat long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin trajectory approaching invariant stability.`;
  }

  return `Cross‑hyper‑epoch Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin trends are inconclusive. Additional hyper‑epochs are required to determine a clear long‑range Field‑Root‑Source‑Origin‑Field‑Constant‑Source‑Root‑Source‑Origin signal.`;
}