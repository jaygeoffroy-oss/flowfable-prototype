import type { EngineInspectorCrossTierAutonomyDelta } from "./engineInspectorCrossTierAutonomyDelta";

export function buildInspectorCrossTierAutonomyDeltaEngineMetaSummary(
  inspectorCrossTierAutonomyDelta: EngineInspectorCrossTierAutonomyDelta,
  previousCrossTierAutonomyDelta?: EngineInspectorCrossTierAutonomyDelta
): string {
  const current =
    inspectorCrossTierAutonomyDelta.crossTierAutonomyDelta;
  const previous =
    previousCrossTierAutonomyDelta?.crossTierAutonomyDelta;

  if (!previous) {
    return `The Cross‑Tier Autonomy Delta Engine has generated its first unified autonomy delta. Cross‑cycle comparison will begin once a second delta is available.`;
  }

  const improving =
    current.deltaClassification === "Improving" &&
    previous.deltaClassification !== "Improving";

  const degrading =
    current.deltaClassification === "Degrading" &&
    previous.deltaClassification !== "Degrading";

  const critical =
    current.deltaClassification === "Critical" &&
    previous.deltaClassification !== "Critical";

  if (improving) {
    return `Cross‑cycle analysis shows an upward shift in unified autonomy. The system demonstrates stronger multi‑tier alignment and reduced cross‑tier risks compared to the previous cycle.`;
  }

  if (degrading) {
    return `Cross‑cycle analysis shows a downward shift in unified autonomy. Multi‑tier alignment weakened, and cross‑tier risks increased relative to the previous cycle. Intervention may be required to prevent further decline.`;
  }

  if (critical) {
    return `Cross‑cycle analysis shows a collapse in unified autonomy. Severe degradation across multiple tiers marks a critical shift from the previous cycle. Immediate corrective action is required.`;
  }

  return `Cross‑cycle analysis shows stable unified autonomy. No major changes were detected between cycles, and cross‑tier alignment remains consistent.`;
}