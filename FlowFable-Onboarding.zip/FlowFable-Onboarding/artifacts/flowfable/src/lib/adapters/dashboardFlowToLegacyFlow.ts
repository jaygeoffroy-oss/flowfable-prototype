import type { FlowResult as DashboardFlowResult } from "@/types/FlowResult";
import type { FlowResult as LegacyFlowResult } from "@/lib/flowTypes";
import type { Insight } from "@/lib/insightTypes";

export function dashboardFlowToLegacyFlow(
  flow: DashboardFlowResult
): LegacyFlowResult {
  return {
    insights: flow.insights.items.map((item) =>
      toInsight(item.title, item.detail)
    ),
    guidance: flow.guidance.items.map((item) =>
      toInsight(item.title, item.action)
    ),
    education: flow.education.items.map((item) =>
      toInsight(item.title, item.explanation)
    ),
    trends: [
      {
        name: "Overall financial trend",
        direction: flow.trends.direction,
        strength: flow.trends.momentum,
        timestamp: new Date().toISOString()
      }
    ],
    income: flow.income.sources.map((source) => ({
      amount: source.amount,
      cadence: source.name
    })),
    bills: flow.bills.items.map((bill) => ({
      name: bill.name,
      amount: bill.amount,
      cadence: "monthly"
    })),
    budget: flow.budget.categories.map((category) => ({
      category: category.name,
      amount: category.amount
    })),
    transactions: [],
    meta: flow.meta
  };
}

function toInsight(what: string, why: string): Insight {
  return {
    what,
    why,
    options: [],
    consequences: [],
    returnToGoal: "",
    severity: "info"
  };
}