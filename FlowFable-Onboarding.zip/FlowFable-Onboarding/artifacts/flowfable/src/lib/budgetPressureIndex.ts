import type { CashFlowProjection } from "@/lib/cashFlowProjection";

export interface BudgetPressureIndex {
  score: number; // 0–100
  severity: "low" | "medium" | "high";
  message: string;
}

/**
 * Computes a Budget Pressure Index (BPI) from a 30‑day cash‑flow projection.
 *
 * Factors:
 * - number of days with negative balance
 * - lowest projected balance
 * - total upcoming charges
 *
 * Produces a 0–100 score and a severity label.
 */
export function calculateBudgetPressureIndex(
  projection: CashFlowProjection[]
): BudgetPressureIndex {
  if (!projection || projection.length === 0) {
    return {
      score: 0,
      severity: "low",
      message: "No financial pressure detected.",
    };
  }

  // Count days where projected balance dips below zero
  const negativeDays = projection.filter((d) => d.projectedBalance < 0).length;

  // Lowest projected balance
  const lowestBalance = Math.min(
    ...projection.map((d) => d.projectedBalance)
  );

  // Total upcoming charges
  const totalCharges = projection.reduce((sum, d) => {
    return (
      sum +
      d.upcomingCharges.reduce((s, c) => s + c.amount, 0)
    );
  }, 0);

  // Score calculation (0–100)
  let score = 0;

  // Negative days contribute heavily
  score += negativeDays * 3;

  // Low balance contributes moderately
  if (lowestBalance < 0) {
    score += Math.min(Math.abs(lowestBalance) * 0.5, 40);
  }

  // Total charges contribute lightly
  score += Math.min(totalCharges * 0.1, 30);

  // Clamp score
  score = Math.min(100, Math.max(0, Math.round(score)));

  // Severity
  let severity: "low" | "medium" | "high" = "low";
  if (score >= 70) severity = "high";
  else if (score >= 40) severity = "medium";

  const message =
    severity === "high"
      ? "High financial pressure expected in the next 30 days."
      : severity === "medium"
      ? "Moderate financial pressure expected."
      : "Low financial pressure expected.";

  return {
    score,
    severity,
    message,
  };
}
