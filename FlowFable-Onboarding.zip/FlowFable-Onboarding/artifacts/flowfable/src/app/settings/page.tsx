"use client";

import { go } from "@/lib/redirect";

export default function SettingsPage() {
  return (
    <div className="max-w-xl mx-auto p-6 bg-white text-black">
      <h1 className="text-3xl ff-heading-serif-rainy mb-6">
        Settings
      </h1>

      <p className="leading-relaxed mb-8">
        Adjust your FlowFable experience. More options will be added as the
        product grows.
      </p>

      <div className="flex flex-col gap-6 mb-10">
        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">Theme</p>
          <p className="leading-relaxed mb-4">
            Choose how FlowFable looks. (Coming soon)
          </p>
          <button
            type="button"
            disabled
            className="
              w-full py-3 rounded-lg
              border border-black
              text-black opacity-50
            "
          >
            Change theme
          </button>
        </div>

        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">Language</p>
          <p className="leading-relaxed mb-4">
            Select your preferred language. (Coming soon)
          </p>
          <button
            type="button"
            disabled
            className="
              w-full py-3 rounded-lg
              border border-black
              text-black opacity-50
            "
          >
            Change language
          </button>
        </div>

      </div>

      <button
        type="button"
        onClick={() => go("/")}
        className="
          w-full py-3 rounded-lg
          bg-[var(--ff-seafoam)] text-black
          font-medium
        "
      >
        Go home
      </button>
    </div>
  );
}