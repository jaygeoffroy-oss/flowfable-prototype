"use client";

import { useEffect, useState } from "react";
import { Link, useRoute } from "wouter";
import { fetchHistoryItem } from "@/lib/historyClient";
import { compareSnapshots } from "@/lib/compare/compareEngine";
import type { FlowResult } from "@/types/FlowResult";

function parseSnapshotIndex(value: string | undefined): number | null {
  const index = Number(value);
  return Number.isInteger(index) && index >= 0 ? index : null;
}

export default function ComparisonPage() {
  const [, params] = useRoute("/compare/:left/:right");
  const [left, setLeft] = useState<FlowResult | null>(null);
  const [right, setRight] = useState<FlowResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const leftIndex = parseSnapshotIndex(params?.left);
    const rightIndex = parseSnapshotIndex(params?.right);

    async function loadSnapshots() {
      if (leftIndex === null || rightIndex === null) {
        setError("Comparison unavailable.");
        setLoading(false);
        return;
      }

      try {
        const [leftSnapshot, rightSnapshot] = await Promise.all([
          fetchHistoryItem(leftIndex),
          fetchHistoryItem(rightIndex)
        ]);

        if (!cancelled) {
          setLeft(leftSnapshot);
          setRight(rightSnapshot);
          setError(leftSnapshot && rightSnapshot ? null : "Comparison unavailable.");
        }
      } catch (err) {
        console.error("Snapshot comparison load error:", err);
        if (!cancelled) {
          setError("Comparison unavailable.");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    setLoading(true);
    void loadSnapshots();

    return () => {
      cancelled = true;
    };
  }, [params?.left, params?.right]);

  if (loading) {
    return <div className="text-gray-300">Loading comparison…</div>;
  }

  if (error || !left || !right) {
    return (
      <div className="space-y-4 text-gray-300">
        <p>Comparison unavailable.</p>
        <Link
          href="/history"
          className="text-[#FF6A00] transition-colors hover:text-white"
        >
          ← Back to Timeline
        </Link>
      </div>
    );
  }

  const result = compareSnapshots(left, right);

  return (
    <div className="min-h-screen w-full bg-black px-6 py-10 text-white">
      <h1 className="mb-10 text-3xl font-semibold ff-heading-serif-rainy">
        Snapshot Comparison
      </h1>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2">
        <div className="ff-card border-[var(--ff-sky)]">
          <h3 className="text-lg font-semibold ff-heading-serif-rainy">
            Snapshot A
          </h3>
          <p className="mt-2 text-gray-300">
            {left.meta?.timestamp ?? "No timestamp available"}
          </p>
          <p className="mt-1 text-gray-400">
            {left.meta?.filePath ?? "Uploaded File"}
          </p>
        </div>

        <div className="ff-card border-[var(--ff-sky)]">
          <h3 className="text-lg font-semibold ff-heading-serif-rainy">
            Snapshot B
          </h3>
          <p className="mt-2 text-gray-300">
            {right.meta?.timestamp ?? "No timestamp available"}
          </p>
          <p className="mt-1 text-gray-400">
            {right.meta?.filePath ?? "Uploaded File"}
          </p>
        </div>
      </div>

      <div className="ff-card mt-10">
        <h3 className="mb-4 text-lg font-semibold ff-heading-serif-rainy">
          Differences
        </h3>

        <div className="space-y-1 text-gray-300">
          <p>
            Income change:{" "}
            <span className="font-[var(--ff-font-serif)] text-[var(--ff-coral)]">
              {result.deltas.income}
            </span>
          </p>
          <p>
            Bills change:{" "}
            <span className="text-[#FF6A00]">{result.deltas.bills}</span>
          </p>
          <p>
            Budget change:{" "}
            <span className="text-[#FF6A00]">{result.deltas.budget}</span>
          </p>
          <p>
            Pressure change:{" "}
            <span className="text-[#FF6A00]">{result.deltas.pressure}</span>
          </p>
          <p>
            Stability change:{" "}
            <span className="text-[#FF6A00]">{result.deltas.stability}</span>
          </p>
          <p className="text-sm ff-heading-serif-rainy">
            Trend direction:{" "}
            <span className="text-[var(--ff-seafoam)] font-[var(--ff-font-serif)]">
              {result.deltas.directionChange}
            </span>
          </p>
        </div>
      </div>

      <Link
        href="/history"
        className="mt-6 inline-block text-[#FF6A00] transition-colors hover:text-white"
      >
        ← Back to Timeline
      </Link>
    </div>
  );
}