"use client";

import { go } from "@/lib/redirect";

export default function AboutPage() {
  return (
    <div className="max-w-xl mx-auto p-6 bg-white text-black">
      <h1 className="text-3xl ff-heading-serif-rainy mb-6">
        About FlowFable
      </h1>

      <p className="leading-relaxed mb-6">
        FlowFable is built on a simple idea: financial learning should feel
        calm, structured, and clear. Instead of overwhelming you with charts
        or jargon, FlowFable breaks your financial information into small,
        meaningful insights you can understand at a glance.
      </p>

      <p className="leading-relaxed mb-6">
        Each insight follows a learning pattern inspired by modern L&amp;D
        practice: what’s happening, why it matters, and what to do next.
        This keeps the experience predictable, supportive, and focused on
        real understanding.
      </p>

      <p className="leading-relaxed mb-10">
        FlowFable isn’t a dashboard. It’s a learning companion — designed to
        help you build clarity, confidence, and better financial habits one
        insight at a time.
      </p>

      <button
        type="button"
        onClick={() => go("/")}
        className="
          w-full py-3 rounded-lg
          bg-[var(--ff-seafoam)] text-black
          font-medium
        "
      >
        Go home
      </button>
    </div>
  );
}