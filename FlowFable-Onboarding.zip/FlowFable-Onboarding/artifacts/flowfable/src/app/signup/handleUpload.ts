import { parseCSVStatement } from "@/lib/parseStatements";
import { normalizeTransactions } from "@/lib/normalizeBatch";
import { detectSpendingPatterns } from "@/lib/spendingPatterns";
import { generateInsights } from "@/lib/insightEngine";
import { generateDecision } from "@/lib/decisionEngine";

import { saveNormalized } from "@/lib/saveNormalized";
import { savePatterns } from "@/lib/savePatterns";
import { saveInsights } from "@/lib/saveInsights";
import { saveDecision } from "@/lib/saveDecision";

export async function handleUpload(file: File, userId: string, statementId?: string) {
  // 1. Parse raw CSV → Transaction[]
  const { transactions } = await parseCSVStatement(file);

  // 2. Normalize → NormalizedTransaction[]
  const normalized = normalizeTransactions(transactions);

  // 3. Behaviour detection → SpendingPatterns
  const patterns = detectSpendingPatterns(normalized);

  // 4. Insight generation → Insight[]
  const insights = generateInsights(patterns);

  // 5. Decision engine → DecisionPair
  const decision = generateDecision(insights);

  // 6. Persist everything
  await saveNormalized(userId, statementId ?? null, normalized);
  await savePatterns(userId, patterns);
  await saveInsights(userId, insights);
  if (decision) await saveDecision(userId, decision);

  // 7. Return everything for UI or debugging
  return {
    normalized,
    patterns,
    insights,
    decision,
  };
}
