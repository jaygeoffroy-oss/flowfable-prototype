"use client";

import { go } from "@/lib/redirect";

export default function ContactPage() {
  return (
    <div className="max-w-xl mx-auto p-6 bg-white text-black">
      <h1 className="text-3xl ff-heading-serif-rainy mb-6">
        Contact
      </h1>

      <p className="leading-relaxed mb-8">
        If you have questions, feedback, or ideas for FlowFable, you can leave
        a message below. More contact options will be added as the product
        grows.
      </p>

      <div className="flex flex-col gap-4 mb-10">
        <input
          type="text"
          placeholder="Your name (optional)"
          className="
            w-full p-3 border border-black rounded-lg
            text-black
          "
        />

        <input
          type="email"
          placeholder="Your email (optional)"
          className="
            w-full p-3 border border-black rounded-lg
            text-black
          "
        />

        <textarea
          placeholder="Your message"
          rows={5}
          className="
            w-full p-3 border border-black rounded-lg
            text-black
          "
        />

        <button
          type="button"
          disabled
          className="
            w-full py-3 rounded-lg
            bg-[var(--ff-seafoam)] text-black
            opacity-50
            font-medium
          "
        >
          Send message (coming soon)
        </button>
      </div>

      <button
        type="button"
        onClick={() => go("/")}
        className="
          w-full py-3 rounded-lg
          border border-black
          text-black
          font-medium
        "
      >
        Go home
      </button>
    </div>
  );
}