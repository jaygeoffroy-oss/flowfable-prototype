export default function ProfilePage() {
  return (
    <div>
      <h1 className="text-3xl font-semibold ff-heading-serif-rainy">
        Profile
      </h1>
      <p className="mt-2 text-gray-300">
        Your preferences and personal settings will appear here.
      </p>
      <div className="mt-10 space-y-6">
        <h2 className="text-xl font-semibold ff-heading-serif-rainy">
          Account
        </h2>
        <h2 className="text-xl font-semibold ff-heading-serif-rainy">
          Preferences
        </h2>
        <h2 className="text-xl font-semibold ff-heading-serif-rainy">
          Security
        </h2>
      </div>
    </div>
  );
}