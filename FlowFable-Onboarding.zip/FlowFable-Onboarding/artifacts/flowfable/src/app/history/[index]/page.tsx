"use client";

import { useEffect, useState } from "react";
import { Link, useRoute } from "wouter";
import DashboardPage from "@/components/DashboardPage";
import { fetchHistoryItem } from "@/lib/historyClient";
import type { FlowResult } from "@/types/FlowResult";

export default function HistoryDetailPage() {
  const [, params] = useRoute("/history/:id");
  const [flow, setFlow] = useState<FlowResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    const index = Number(params?.id);

    async function loadHistoryItem() {
      if (!Number.isInteger(index) || index < 0) {
        setLoading(false);
        return;
      }

      try {
        const historyItem = await fetchHistoryItem(index);
        if (!cancelled) {
          setFlow(historyItem);
          setError(null);
        }
      } catch (err) {
        console.error("History item load error:", err);
        if (!cancelled) {
          setError("Failed to load history item");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadHistoryItem();

    return () => {
      cancelled = true;
    };
  }, [params?.id]);

  if (!loading && !error && flow) {
    return (
      <div className="min-h-screen w-full bg-black px-6 py-10 text-white">
        <div className="ff-card mb-8 border-[var(--ff-coral)]">
          <h1 className="text-2xl font-bold ff-heading-serif-rainy">
            Snapshot Replay
          </h1>
          <p className="mt-1 text-[var(--ff-fog-gray)]">
            You are viewing a historical FlowResult snapshot.
          </p>
        </div>

        <div className="ff-card mb-10">
          <p className="text-gray-300">
            File:{" "}
            <span className="text-white">
              {flow.meta?.filePath ?? "Uploaded File"}
            </span>
          </p>
          <p className="mt-1 text-gray-300">
            Timestamp:{" "}
            <span className="text-white">
              {flow.meta?.timestamp ?? "No timestamp available"}
            </span>
          </p>
          <p className="mt-1 text-gray-300">
            Source:{" "}
            <span className="text-white">
              {flow.meta?.source ?? "unknown"}
            </span>
          </p>

          <Link href="/" className="ff-btn-primary mt-4 inline-block">
            Return to Live Dashboard
          </Link>
          <Link
            href={`/compare/${params?.id}/${Number(params?.id) + 1}`}
            className="ff-btn-secondary mt-4 inline-block"
          >
            Compare with previous snapshot
          </Link>
        </div>

        <DashboardPage flow={flow} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Link
        href="/history"
        className="text-sm text-gray-300 transition-colors hover:text-[#FF6A00]"
      >
        ← Back to History
      </Link>

      <h1 className="text-2xl font-bold text-[#FF6A00]">History Detail</h1>

      {loading && <p className="text-gray-300">Loading history item…</p>}
      {error && <p className="text-red-400">{error}</p>}
      {!loading && !error && !flow && (
        <div className="text-gray-300">No history found.</div>
      )}
    </div>
  );
}