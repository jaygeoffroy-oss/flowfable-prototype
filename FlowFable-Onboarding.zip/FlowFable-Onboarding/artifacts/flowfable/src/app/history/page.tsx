"use client";

import { useEffect, useState } from "react";
import { Link } from "wouter";
import { fetchHistory } from "@/lib/historyClient";
import type { FlowHistoryItem } from "@/types/FlowHistory";
import { computeTimelineAnalytics } from "@/lib/history/timelineAnalyticsEngine";

export default function HistoryPage() {
  const [history, setHistory] = useState<FlowHistoryItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadHistory() {
      try {
        const items = await fetchHistory();
        if (!cancelled) {
          setHistory(items);
          setError(null);
        }
      } catch (err) {
        console.error("History load error:", err);
        if (!cancelled) {
          setError("Failed to load history");
        }
      }
    }

    void loadHistory();

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="min-h-screen w-full bg-black px-6 py-10 text-white">
      <h1 className="mb-10 text-3xl font-semibold ff-heading-serif-rainy">
        Timeline
      </h1>

      {error && <p className="mb-6 text-red-400">{error}</p>}

      {!error && history.length === 0 ? (
        <p className="text-gray-300">No history snapshots yet.</p>
      ) : (
        <div className="relative pl-6">
           <div className="absolute bottom-0 left-2 top-0 w-1 rounded-full bg-[var(--ff-rain-blue)]/40" />

          <div className="flex flex-col gap-10">
            {history.map((item, index) => (
              <div key={index} className="relative">
                <div className="absolute -left-1 top-2 h-4 w-4 rounded-full bg-[var(--ff-seafoam)] shadow-lg" />

                <div className="ff-card border-[var(--ff-rain-blue)] transition-colors hover:border-[var(--ff-seafoam)]">
                  <p className="text-xs font-[var(--ff-font-serif)] text-[var(--ff-fog-gray)]">
                    {item.meta?.filePath ?? "Uploaded File"}
                  </p>

                  <p className="mt-1 text-sm ff-heading-serif-rainy">
                    {item.meta?.timestamp ?? "No timestamp available"}
                  </p>

                  <p className="mt-2 text-gray-400">
                    Source: {item.meta?.source ?? "unknown"}
                  </p>

                  <div className="mt-3 flex flex-col items-start gap-2">
                    <Link
                      href={`/history/${index}`}
                      className="text-sm font-medium text-[#FF6A00]"
                    >
                      View Snapshot →
                    </Link>
                    {index < history.length - 1 && (
                      <Link
                        href={`/compare/${index}/${index + 1}`}
                        className="mt-2 block text-sm text-[#FF6A00]"
                      >
                        Compare with previous →
                      </Link>
                    )}
                  </div>

                  {(() => {
                    const previous = history[index + 1] ?? null;
                    const analytics = computeTimelineAnalytics(item, previous);

                    return (
                      <div className="mt-3 text-sm text-gray-300">
                        <p className="text-sm ff-heading-serif-rainy">
                          Income change:{" "}
                          <span className="text-[var(--ff-coral)]">
                            {analytics.incomeDelta}
                          </span>
                        </p>
                        <p>
                          Bills change:{" "}
                          <span className="text-[#FF6A00]">
                            {analytics.billsDelta}
                          </span>
                        </p>
                        <p>
                          Budget change:{" "}
                          <span className="text-[#FF6A00]">
                            {analytics.budgetDelta}
                          </span>
                        </p>
                        <p>
                          Pressure change:{" "}
                          <span className="text-[#FF6A00]">
                            {analytics.pressureDelta}
                          </span>
                        </p>
                        <p>
                          Stability change:{" "}
                          <span className="text-[#FF6A00]">
                            {analytics.stabilityDelta}
                          </span>
                        </p>
                        <p>
                          Trend direction:{" "}
                          <span className="text-[#FF6A00]">
                            {analytics.directionChange}
                          </span>
                        </p>
                      </div>
                    );
                  })()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}