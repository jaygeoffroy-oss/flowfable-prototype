"use client";

import { go } from "@/lib/redirect";

export default function HelpPage() {
  return (
    <div className="max-w-xl mx-auto p-6 bg-white text-black">
      <h1 className="text-3xl ff-heading-serif-rainy mb-6">
        Help &amp; Support
      </h1>

      <p className="leading-relaxed mb-8">
        FlowFable is designed to be simple and calm. If you need help, the
        answers below cover the most common questions.
      </p>

      <div className="flex flex-col gap-6 mb-10">
        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">How does FlowFable work?</p>
          <p className="leading-relaxed">
            You upload a financial document. FlowFable reads it and creates
            clear learning insights using a structured pattern: what’s
            happening, why it matters, and what to do next.
          </p>
        </div>

        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">Why are insights structured?</p>
          <p className="leading-relaxed">
            The structure comes from modern learning design. It keeps each
            insight predictable, easy to understand, and focused on real
            improvement.
          </p>
        </div>

        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">How do I restart learning?</p>
          <p className="leading-relaxed mb-4">
            You can restart from the Settings page or from the first insight.
          </p>
          <button
            type="button"
            onClick={() => go("/settings")}
            className="
              w-full py-3 rounded-lg
              border border-black
              text-black
              font-medium
            "
          >
            Go to Settings
          </button>
        </div>

        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">What documents can I upload?</p>
          <p className="leading-relaxed">
            Any simple financial summary: income, bills, savings, or monthly
            statements. FlowFable extracts only what it needs to generate
            insights.
          </p>
        </div>

        <div className="border border-black p-4 rounded-lg">
          <p className="font-medium mb-2">How do I navigate insights?</p>
          <p className="leading-relaxed">
            Use Continue to move forward, Back to revisit earlier insights,
            and Restart to begin again.
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => go("/")}
        className="
          w-full py-3 rounded-lg
          bg-[var(--ff-seafoam)] text-black
          font-medium
        "
      >
        Go home
      </button>
    </div>
  );
}