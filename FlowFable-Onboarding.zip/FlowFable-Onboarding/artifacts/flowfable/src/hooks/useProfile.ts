import { useEffect, useState } from "react";
import type { CoachingStyle, UserProfile } from "@/lib/userProfileTypes";

type ProfileState = Partial<UserProfile> & {
  coachingStyle?: CoachingStyle;
};

export function useProfile() {
  const [profile, setProfile] = useState<ProfileState>({});

  useEffect(() => {
    let active = true;

    fetch("/api/profile")
      .then(response => {
        if (!response.ok) {
          throw new Error(`Failed to load profile (${response.status})`);
        }
        return response.json() as Promise<ProfileState>;
      })
      .then(data => {
        if (active) {
          setProfile(data);
        }
      })
      .catch(error => {
        console.error("Unable to load profile", error);
      });

    return () => {
      active = false;
    };
  }, []);

  async function updateProfile(updated: ProfileState) {
    setProfile(updated);

    const response = await fetch("/api/profile", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updated)
    });

    if (!response.ok) {
      throw new Error(`Failed to update profile (${response.status})`);
    }

    const saved = (await response.json()) as ProfileState;
    setProfile(saved);
  }

  return { profile, updateProfile };
}