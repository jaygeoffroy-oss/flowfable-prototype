import { useCallback, useEffect, useState } from "react";
import type { ScenarioRecord } from "@/lib/goalProgress";

type ScenarioRecordInput = Omit<ScenarioRecord, "id" | "timestamp">;

export function useScenarioHistory() {
  const [history, setHistory] = useState<ScenarioRecord[]>([]);

  const refresh = useCallback(async () => {
    const response = await fetch("/api/scenario-history");
    if (!response.ok) {
      throw new Error(
        `Failed to load scenario history (${response.status})`
      );
    }

    const data = (await response.json()) as ScenarioRecord[];
    setHistory(data);
  }, []);

  useEffect(() => {
    void refresh().catch(error => {
      console.error("Unable to load scenario history", error);
    });
  }, [refresh]);

  async function saveScenario(record: ScenarioRecordInput) {
    const response = await fetch("/api/scenario-history", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(record)
    });

    if (!response.ok) {
      throw new Error(
        `Failed to save scenario history (${response.status})`
      );
    }

    const saved = (await response.json()) as ScenarioRecord;
    setHistory(previous => [saved, ...previous]);
  }

  return { history, refresh, saveScenario };
}