import { useState } from "react";

export function useConsent() {
  const [accepted, setAccepted] = useState(false);
  return { accepted, setAccepted };
}