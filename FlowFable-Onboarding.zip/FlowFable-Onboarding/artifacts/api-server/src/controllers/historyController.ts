import type { Request, Response } from "express";
import { getHistory, getHistoryItem } from "@/lib/historyStore";

export async function historyController(_req: Request, res: Response) {
  const history = await getHistory();
  return res.status(200).json({ history });
}

export async function historyItemController(req: Request, res: Response) {
  const index = Number(req.params.id);

  if (!Number.isInteger(index) || index < 0) {
    return res.status(400).json({ error: "Invalid history id" });
  }

  const flow = await getHistoryItem(index);
  if (!flow) {
    return res.status(404).json({ error: "No history found." });
  }

  return res.status(200).json({ flow });
}