import { generateFlow } from "@/lib/flowEngine";
import type { FlowResult } from "@/lib/flowTypes";
import { logger } from "@/lib/logger";
import { saveFlowToHistory } from "@/lib/historyStore";
import { ingestDocumentAndGenerateFlow } from "@/lib/upload/ingestionPipeline";
import type { Request, Response } from "express";

/**
 * API controller for the FlowResult pipeline.
 * Returns the unified FlowResult for the given userId.
 */
export async function flowController(req: Request, res: Response) {
  try {
    const requestedUserId = req.query.userId;

    if (
      requestedUserId !== undefined &&
      typeof requestedUserId !== "string"
    ) {
      return res.status(400).json({ error: "Invalid userId" });
    }
    const userId =
      typeof requestedUserId === "string" && requestedUserId.trim() !== ""
        ? requestedUserId
        : "demo-user";

    const requestedFilePath = req.query.filePath;
    if (
      requestedFilePath !== undefined &&
      typeof requestedFilePath !== "string"
    ) {
      return res.status(400).json({ error: "Invalid filePath" });
    }
    const filePath = requestedFilePath;

    const result: FlowResult = filePath && filePath.trim() !== ""
      ? await ingestDocumentAndGenerateFlow(filePath, userId)
      : await generateFlow(userId);

    await saveFlowToHistory(result);

    return res.status(200).json(result);
  } catch (err) {
    logger.error({ err }, "Flow API error");
    return res.status(500).json({ error: "Failed to generate flow" });
  }
}
