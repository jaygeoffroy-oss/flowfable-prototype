import express from "express";
import cors from "cors";
import routes from "@/routes/index";

const app = express();

app.use(cors());
app.use(express.json());

// Mount all routes
app.use("/api", routes);

// Health check
app.get("/health", (_req, res) => {
  res.status(200).json({ status: "ok" });
});

export default app;
