import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL ?? "";
const supabaseKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY ??
  process.env.SUPABASE_ANON_KEY ??
  process.env.VITE_SUPABASE_ANON_KEY ??
  "";

if (!supabaseUrl || !supabaseKey) {
  console.warn(
    "[supabase] Missing SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY — flow route will return empty results"
  );
}

const emptyQuery = () => ({
  select: () => emptyQuery(),
  eq: () => emptyQuery(),
  order: async () => ({ data: [], error: null })
});

export const supabase =
  supabaseUrl && supabaseKey
    ? createClient(supabaseUrl, supabaseKey)
    : ({
        from: () => emptyQuery()
      } as unknown as ReturnType<typeof createClient>);
