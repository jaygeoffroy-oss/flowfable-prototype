import { readFile } from "node:fs/promises";
import { PDFParse } from "pdf-parse";

export interface ParsedPDFDocument {
  type: "pdf";
  text: string;
}

export async function parsePDF(
  filePath: string
): Promise<ParsedPDFDocument> {
  const buffer = await readFile(filePath);
  const parser = new PDFParse({ data: buffer });

  try {
    const data = await parser.getText();

    return {
      type: "pdf",
      text: data.text
    };
  } finally {
    await parser.destroy();
  }
}