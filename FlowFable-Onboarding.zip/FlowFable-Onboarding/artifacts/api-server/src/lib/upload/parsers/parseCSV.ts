export interface ParsedCSVDocument {
  type: "csv";
  rows: Record<string, string>[];
}

export async function parseCSV(filePath: string): Promise<ParsedCSVDocument> {
  const fs = await import("fs/promises");
  const raw = await fs.readFile(filePath, "utf8");

  const lines = raw.split("\n").filter((line) => line.trim().length > 0);
  const header = lines[0].split(",").map((value) => value.trim());
  const rows = lines.slice(1);

  const parsed = rows.map((line) => {
    const parts = line.match(/(".*?"|[^",]+)(?=\s*,|\s*$)/g) || [];
    const object: Record<string, string> = {};

    header.forEach((key, index) => {
      object[key] = parts[index]?.replace(/^"|"$/g, "") ?? "";
    });

    return object;
  });

  return {
    type: "csv",
    rows: parsed
  };
}