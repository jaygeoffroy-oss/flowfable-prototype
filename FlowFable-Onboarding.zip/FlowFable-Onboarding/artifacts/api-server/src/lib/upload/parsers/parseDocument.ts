import path from "node:path";
import { parseCSV, type ParsedCSVDocument } from "@/lib/upload/parsers/parseCSV";
import {
  parsePDF,
  type ParsedPDFDocument
} from "@/lib/upload/parsers/parsePDF";
import {
  parseOCR,
  type ParsedOCRDocument
} from "@/lib/upload/parsers/parseOCR";

export type ParsedDocument =
  | ParsedCSVDocument
  | ParsedPDFDocument
  | ParsedOCRDocument
  | { error: string };

export async function parseDocument(filePath: string): Promise<ParsedDocument> {
  const extension = path.extname(filePath).replace(/^\./, "").toLowerCase();

  if (!extension) {
    return { error: "Unknown file type" };
  }

  if (extension === "csv") {
    return await parseCSV(filePath);
  }

  if (extension === "pdf") {
    return await parsePDF(filePath);
  }

  if (["png", "jpg", "jpeg", "webp"].includes(extension)) {
    return await parseOCR(filePath);
  }

  return {
    error: `Unsupported file type: ${extension}`
  };
}