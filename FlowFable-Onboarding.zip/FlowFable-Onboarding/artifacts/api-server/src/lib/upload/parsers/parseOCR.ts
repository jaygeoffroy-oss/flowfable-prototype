import { createRequire } from "node:module";
import Tesseract from "tesseract.js";

const moduleRequire = createRequire(import.meta.url);

export interface ParsedOCRDocument {
  type: "ocr";
  text: string;
}

export async function parseOCR(
  filePath: string
): Promise<ParsedOCRDocument> {
  const result = await Tesseract.recognize(filePath, "eng", {
    workerPath: moduleRequire.resolve(
      "tesseract.js/src/worker-script/node/index.js"
    )
  });

  return {
    type: "ocr",
    text: result.data.text
  };
}