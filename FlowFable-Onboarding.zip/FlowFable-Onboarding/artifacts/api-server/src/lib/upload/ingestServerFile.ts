import type { FlowResult } from "@/lib/flowTypes";
import { ingestDocumentAndGenerateFlow } from "@/lib/upload/ingestionPipeline";

export async function ingestServerFile(
  filePath: string
): Promise<FlowResult> {
  return ingestDocumentAndGenerateFlow(filePath);
}