import { rm } from "node:fs/promises";
import type { Request, Response } from "express";
import { processUploadedDocument } from "@/lib/upload/processUploadedDocument";
import { saveUploadedFile } from "@/lib/upload/saveUploadedFile";

async function readMultipartFormData(req: Request): Promise<FormData> {
  const protocolHeader = req.headers["x-forwarded-proto"];
  const protocol = Array.isArray(protocolHeader)
    ? protocolHeader[0]
    : protocolHeader ?? "http";
  const host = req.headers.host ?? "localhost";

  const request = new globalThis.Request(
    `${protocol}://${host}${req.originalUrl}`,
    {
      method: req.method,
      headers: req.headers as Record<string, string>,
      body: req as any,
      duplex: "half"
    } as RequestInit & { duplex: "half" }
  );

  return request.formData();
}

export async function uploadController(req: Request, res: Response) {
  let savedPath: string | undefined;

  try {
    const formData = await readMultipartFormData(req);
    const formFile = formData.get("file");

    if (
      !formFile ||
      typeof formFile !== "object" ||
      typeof (formFile as File).arrayBuffer !== "function"
    ) {
      res.status(400).json({ error: "No file provided" });
      return;
    }

    savedPath = await saveUploadedFile(formFile as File);
    const processed = await processUploadedDocument(savedPath);

    res.status(200).json({
      status: "success",
      path: savedPath,
      processed
    });
  } catch (err) {
    console.error("Upload API error", err);

    if (savedPath) {
      await rm(savedPath, { force: true }).catch(() => undefined);
    }

    const message =
      err instanceof Error ? err.message : "Failed to process upload";
    const status =
      message.startsWith("Unsupported") ||
      message.startsWith("This upload") ||
      message.startsWith("CSV") ||
      message.startsWith("Content-Type was not")
        ? 400
        : 500;

    res.status(status).json({ error: message });
  }
}