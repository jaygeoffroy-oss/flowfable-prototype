import type { FlowTrend } from "@/lib/flowTypes";
import {
  directionForDelta,
  getRowAmount,
  getRowDate,
  isExpenseRow,
  isIncomeRow,
  type MappingRow
} from "@/lib/upload/mapping/utils";

export function mapTrends(rows: MappingRow[]): FlowTrend[] {
  if (rows.length < 2) return [];

  const midpoint = Math.ceil(rows.length / 2);
  const first = rows.slice(0, midpoint);
  const second = rows.slice(midpoint);
  const timestamp = getRowDate(rows[rows.length - 1]);

  const metrics = [
    {
      name: "Income",
      value: (group: MappingRow[]) =>
        group.reduce(
          (total, row) =>
            total + (isIncomeRow(row) ? Math.abs(getRowAmount(row)) : 0),
          0
        )
    },
    {
      name: "Bills",
      value: (group: MappingRow[]) =>
        group.reduce(
          (total, row) =>
            total + (isExpenseRow(row) ? Math.abs(getRowAmount(row)) : 0),
          0
        )
    }
  ];

  return metrics.map(({ name, value }) => {
    const delta = value(second) - value(first);

    return {
      name,
      direction: directionForDelta(delta),
      strength: Math.abs(delta),
      timestamp
    };
  });
}