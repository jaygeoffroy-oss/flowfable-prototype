import type { FlowIncome } from "@/lib/flowTypes";
import {
  getRowAmount,
  getRowCadence,
  getRowName,
  isIncomeRow,
  type MappingRow
} from "@/lib/upload/mapping/utils";

export function mapIncome(rows: MappingRow[]): FlowIncome[] {
  return rows
    .filter(isIncomeRow)
    .map((row) => ({
      amount: Math.abs(getRowAmount(row)),
      cadence: getRowCadence(row) || getRowName(row)
    }))
    .filter((income) => income.amount > 0);
}