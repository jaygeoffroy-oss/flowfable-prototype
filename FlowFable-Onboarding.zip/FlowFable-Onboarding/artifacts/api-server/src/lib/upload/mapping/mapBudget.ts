import type { FlowBudget } from "@/lib/flowTypes";
import {
  getRowAmount,
  getRowName,
  isBudgetRow,
  type MappingRow
} from "@/lib/upload/mapping/utils";

export function mapBudget(rows: MappingRow[]): FlowBudget[] {
  return rows
    .filter(isBudgetRow)
    .map((row) => ({
      category: getRowName(row),
      amount: Number(getRowAmount(row))
    }))
    .filter((budget) => budget.amount !== 0);
}