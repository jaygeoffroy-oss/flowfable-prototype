import type {
  FlowResult,
  FlowTransaction
} from "@/lib/flowTypes";
import type { ParsedDocument } from "@/lib/upload/parsers/parseDocument";
import {
  getRowAmount,
  getRowCategory,
  getRowDate,
  getRowName,
  type MappingRow
} from "@/lib/upload/mapping/utils";
import { mapBills } from "@/lib/upload/mapping/mapBills";
import { mapBudget } from "@/lib/upload/mapping/mapBudget";
import { mapIncome } from "@/lib/upload/mapping/mapIncome";
import { mapTrends } from "@/lib/upload/mapping/mapTrends";

export function mapDocumentToFlow(document: ParsedDocument): FlowResult {
  const rows = toMappingRows(document);

  if (rows.length === 0) {
    return emptyFlowResult();
  }

  return {
    insights: [],
    guidance: [],
    education: [],
    trends: mapTrends(rows),
    income: mapIncome(rows),
    bills: mapBills(rows),
    budget: mapBudget(rows),
    transactions: rows.map(mapTransaction)
  };
}

function toMappingRows(document: ParsedDocument): MappingRow[] {
  if ("rows" in document) {
    return document.rows as MappingRow[];
  }

  if ("text" in document) {
    return document.text
      .split(/\r?\n/)
      .flatMap((line): MappingRow[] => {
        const normalizedLine = line.toLowerCase();
        const category = normalizedLine.includes("income")
          ? "income"
          : normalizedLine.includes("bill")
            ? "bill"
            : normalizedLine.includes("budget")
              ? "budget"
              : undefined;

        if (!category) return [];

        return [{
          category,
          name:
            category === "income"
              ? "Income"
              : category === "bill"
                ? "Bill"
                : "Budget",
          amount: line.replace(/[^\d.]/g, "") || "0"
        }];
      });
  }

  return [];
}

function mapTransaction(row: MappingRow): FlowTransaction {
  return {
    name: getRowName(row),
    amount: getRowAmount(row),
    category: getRowCategory(row) || "Uncategorized",
    date: getRowDate(row)
  };
}

function emptyFlowResult(): FlowResult {
  return {
    insights: [],
    guidance: [],
    education: [],
    trends: [],
    income: [],
    bills: [],
    budget: [],
    transactions: []
  };
}