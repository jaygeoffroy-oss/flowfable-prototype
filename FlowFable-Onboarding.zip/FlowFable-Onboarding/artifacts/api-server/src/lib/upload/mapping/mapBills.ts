import type { FlowBill } from "@/lib/flowTypes";
import {
  getRowAmount,
  getRowCadence,
  getRowName,
  isExpenseRow,
  type MappingRow
} from "@/lib/upload/mapping/utils";

export function mapBills(rows: MappingRow[]): FlowBill[] {
  return rows
    .filter(isExpenseRow)
    .map((row) => ({
      name: getRowName(row),
      amount: Math.abs(getRowAmount(row)),
      cadence: getRowCadence(row)
    }))
    .filter((bill) => bill.amount > 0);
}