export type MappingRow = Record<string, unknown>;

const incomeKeywords = [
  "income",
  "salary",
  "payroll",
  "wage",
  "deposit",
  "dividend",
  "interest",
  "refund"
];

const expenseKeywords = [
  "expense",
  "bill",
  "rent",
  "mortgage",
  "utility",
  "subscription",
  "insurance",
  "loan",
  "payment",
  "grocery",
  "restaurant",
  "transport"
];

export function getValue(
  row: MappingRow,
  keys: string[]
): string {
  const normalized = new Map(
    Object.entries(row).map(([key, value]) => [
      normalizeKey(key),
      value == null ? "" : String(value).trim()
    ])
  );

  for (const key of keys) {
    const value = normalized.get(normalizeKey(key));
    if (value) return value;
  }

  return "";
}

export function toAmount(value: string): number {
  const normalized = value
    .replace(/[$,\s]/g, "")
    .replace(/^\((.*)\)$/, "-$1");
  const amount = Number(normalized);
  return Number.isFinite(amount) ? amount : 0;
}

export function getRowAmount(row: MappingRow): number {
  return toAmount(
    getValue(row, [
      "amount",
      "value",
      "total",
      "income",
      "expense",
      "debit",
      "credit"
    ])
  );
}

export function getRowName(row: MappingRow): string {
  return (
    getValue(row, [
      "description",
      "name",
      "merchant",
      "payee",
      "memo",
      "category"
    ]) || "Uncategorized"
  );
}

export function getRowCategory(row: MappingRow): string {
  return getValue(row, [
    "category",
    "type",
    "classification",
    "group"
  ]);
}

export function getRowDate(row: MappingRow): string {
  return getValue(row, [
    "date",
    "transaction_date",
    "posted_at",
    "timestamp",
    "created_at"
  ]);
}

export function getRowCadence(row: MappingRow): string {
  return (
    getValue(row, ["cadence", "frequency", "period"]) || "monthly"
  );
}

export function isIncomeRow(row: MappingRow): boolean {
  const category = getRowCategory(row).toLowerCase();
  const text = `${category} ${getRowName(row)}`.toLowerCase();

  if (category) {
    return category === "income" ||
      incomeKeywords.some((keyword) => text.includes(keyword));
  }

  return getRowAmount(row) > 0 &&
    incomeKeywords.some((keyword) => text.includes(keyword));
}

export function isExpenseRow(row: MappingRow): boolean {
  const category = getRowCategory(row).toLowerCase();
  const text = `${category} ${getRowName(row)}`.toLowerCase();

  if (category) {
    return (
      category === "bill" ||
      category === "bills" ||
      category === "expense" ||
      category === "expenses" ||
      expenseKeywords.some((keyword) => text.includes(keyword))
    );
  }

  return (
    getRowAmount(row) < 0 ||
    expenseKeywords.some((keyword) => text.includes(keyword))
  );
}

export function isBudgetRow(row: MappingRow): boolean {
  return getRowCategory(row).toLowerCase() === "budget";
}

export function directionForDelta(
  delta: number
): "up" | "down" | "flat" {
  if (delta > 0) return "up";
  if (delta < 0) return "down";
  return "flat";
}

function normalizeKey(value: string): string {
  return value.toLowerCase().replace(/[^a-z0-9]/g, "");
}