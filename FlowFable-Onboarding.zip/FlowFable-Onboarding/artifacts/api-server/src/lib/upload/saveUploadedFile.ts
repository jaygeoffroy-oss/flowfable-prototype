import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";

const allowedExtensions = new Set([
  ".csv",
  ".pdf",
  ".ofx",
  ".png",
  ".jpg",
  ".jpeg",
  ".webp"
]);

export async function saveUploadedFile(file: File): Promise<string> {
  if (!file.name || file.size === 0) {
    throw new Error("Uploaded file is empty");
  }

  const extension = path.extname(file.name).toLowerCase();

  if (!allowedExtensions.has(extension)) {
    throw new Error(
      "Unsupported file type. Use CSV, PDF, OFX, PNG, JPG, or WEBP."
    );
  }

  const uploadDirectory = path.resolve(
    process.env.UPLOAD_DIR ?? path.join(process.cwd(), "uploads")
  );
  const storedName = `${randomUUID()}${extension}`;
  const savedPath = path.join(uploadDirectory, storedName);

  await mkdir(uploadDirectory, { recursive: true });
  await writeFile(savedPath, Buffer.from(await file.arrayBuffer()));

  return savedPath;
}