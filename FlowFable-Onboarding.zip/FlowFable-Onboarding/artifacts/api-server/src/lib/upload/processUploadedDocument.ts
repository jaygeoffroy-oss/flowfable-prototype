import { parseDocument } from "@/lib/upload/parsers/parseDocument";
import { extractFinancialSignals } from "@/lib/extraction";

export async function processUploadedDocument(filePath: string) {
  const parsed = await parseDocument(filePath);
  const rawText = getRawText(parsed);

  return {
    status: "processed",
    filePath,
    parsed,
    extraction: rawText ? extractFinancialSignals(rawText) : null
  };
}

function getRawText(
  parsed: Awaited<ReturnType<typeof parseDocument>>
): string | null {
  if ("text" in parsed) {
    return parsed.text;
  }

  if ("rows" in parsed) {
    return parsed.rows
      .map((row) => Object.values(row).join(" "))
      .join("\n");
  }

  return null;
}