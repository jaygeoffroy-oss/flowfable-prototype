import { access, stat } from "node:fs/promises";
import path from "node:path";
import { generateFlow } from "@/lib/flowEngine";
import type { FlowResult } from "@/lib/flowTypes";
import { mapDocumentToFlow } from "@/lib/upload/mapping/mapDocumentToFlow";
import { processUploadedDocument } from "@/lib/upload/processUploadedDocument";

export async function ingestDocumentAndGenerateFlow(
  filePath: string,
  userId = "demo-user"
): Promise<FlowResult> {
  const safePath = await validateUploadPath(filePath);
  const processed = await processUploadedDocument(safePath);

  if ("error" in processed.parsed) {
    const fallback = await generateFlow(userId);
    return {
      ...fallback,
      meta: {
        filePath,
        source: "fallback"
      }
    };
  }

  return {
    ...mapDocumentToFlow(processed.parsed),
    extraction: processed.extraction ?? undefined,
    meta: {
      filePath,
      source: "ingestion"
    }
  };
}

async function validateUploadPath(filePath: string): Promise<string> {
  const uploadDirectory = path.resolve(
    process.env.UPLOAD_DIR ?? path.join(process.cwd(), "uploads")
  );
  const resolvedPath = path.resolve(filePath);
  const directoryPrefix = `${uploadDirectory}${path.sep}`;

  if (!resolvedPath.startsWith(directoryPrefix)) {
    throw new Error("Uploaded file path is outside the upload directory");
  }

  await access(resolvedPath);
  const fileStats = await stat(resolvedPath);

  if (!fileStats.isFile()) {
    throw new Error("Uploaded path is not a file");
  }

  return resolvedPath;
}