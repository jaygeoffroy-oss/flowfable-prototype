export type IncomeEntry = {
  amount: number;
  cadence: string;
};

export type BillEntry = {
  name: string;
  amount: number;
  cadence: string;
};

export type BudgetEntry = {
  category: string;
  amount: number;
};

export type TransactionEntry = {
  name: string;
  amount: number;
  category: string;
  date: string;
};

export const incomeStore: IncomeEntry[] = [];
export const billsStore: BillEntry[] = [];
export const budgetStore: BudgetEntry[] = [];
export const transactionStore: TransactionEntry[] = [];