import { supabase } from "@/lib/supabaseClient";
import type { FlowResult, FlowInsight, FlowTrend } from "@/lib/flowTypes";
import {
  billsStore,
  budgetStore,
  incomeStore,
  transactionStore
} from "@/lib/prototypeStores";

type Row = Record<string, unknown>;

export async function generateFlow(userId: string): Promise<FlowResult> {
  const [
    { data: stability },
    { data: runway },
    { data: rhythm },
    { data: pressure },
    { data: patterns },
    { data: recurring },
    { data: forecast }
  ] = await Promise.all([
    supabase.from("stability_snapshots").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("runway_snapshots").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("rhythm_snapshots").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("pressure_events").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("pattern_events").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("recurring_expenses").select("*").eq("user_id", userId).order("created_at", { ascending: false }),
    supabase.from("forecast_events").select("*").eq("user_id", userId).order("timestamp", { ascending: true })
  ]);

  const insights = buildInsights(stability ?? []);
  const guidance = buildGuidance(runway ?? [], recurring ?? []);
  const education = buildEducation(patterns ?? []);
  const trends = buildTrends(stability ?? [], runway ?? [], rhythm ?? [], pressure ?? []);

  return {
    insights,
    guidance,
    education,
    trends,
    income: incomeStore,
    bills: billsStore,
    budget: budgetStore,
    transactions: transactionStore
  };
}

function buildInsights(stability: Row[]): FlowInsight[] {
  if (!stability.length) return [];
  const balance = Number(stability[0].balance ?? 0);
  return [{
    severity: balance < 200 ? "warning" : "info",
    what: `Your current balance is ${balance.toFixed(2)}.`,
    why: balance < 200
      ? "Your balance is below your breathing room threshold."
      : "Your balance provides a healthy margin for upcoming obligations.",
    options: ["Add a small buffer to reinforce stability.", "Review recent spending shifts."],
    consequences: ["Higher stability expands breathing room.", "Lower stability tightens margin."],
    returnToGoal: "Use this stability snapshot to reinforce the life that matters to you."
  }];
}

function buildGuidance(runway: Row[], recurring: Row[]): FlowInsight[] {
  const items: FlowInsight[] = [];
  if (runway.length) {
    const rv = Number(runway[0].runway_value ?? 0);
    items.push({
      severity: rv < 0 ? "critical" : rv < 200 ? "warning" : "info",
      what: `Your runway is ${rv.toFixed(2)} after obligations.`,
      why: rv < 0 ? "Obligations exceed your current balance." : "Your balance covers upcoming obligations.",
      options: ["Reduce non-essential spending.", "Prepare a small buffer."],
      consequences: ["Positive runway means breathing room.", "Negative runway means immediate risk."],
      returnToGoal: "Extend your runway to stay ahead of obligations."
    });
  }
  if (recurring.length) {
    const total = recurring.reduce((s: number, r: Row) => s + Number(r.amount ?? 0), 0);
    items.push({
      severity: total > 300 ? "warning" : "info",
      what: `Your recurring load is ${total.toFixed(2)} per cycle.`,
      why: "Recurring expenses are deducted every cycle, reducing breathing room.",
      options: ["Review recurring commitments.", "Cancel or pause what no longer adds value."],
      consequences: ["Lower load frees breathing room.", "Higher load tightens pressure each cycle."],
      returnToGoal: "Each commitment should serve the life that matters to you."
    });
  }
  return items;
}

function buildEducation(patterns: Row[]): FlowInsight[] {
  if (!patterns.length) return [];
  const total = patterns.reduce((s: number, p: Row) => s + Number(p.amount ?? 0), 0);
  const avg = total / patterns.length;
  return [{
    severity: "info",
    what: `Your average transaction is ${avg.toFixed(2)}.`,
    why: "Understanding your average spend helps you spot outliers and drift.",
    options: ["Compare this to your goal.", "Identify categories driving the average up."],
    consequences: ["Awareness of averages helps course-correct earlier.", "Ignoring patterns leads to drift."],
    returnToGoal: "Pattern awareness keeps your rhythm aligned with your goals."
  }];
}

function buildTrends(stability: Row[], runway: Row[], rhythm: Row[], pressure: Row[]): FlowTrend[] {
  void rhythm; void pressure; // reserved for future use
  const trends: FlowTrend[] = [];
  if (stability.length >= 2) {
    const delta = Number(stability[0].balance ?? 0) - Number(stability[1].balance ?? 0);
    trends.push({
      name: "Stability",
      direction: delta > 0 ? "up" : delta < 0 ? "down" : "flat",
      strength: Math.abs(delta),
      timestamp: String(stability[0].timestamp ?? new Date().toISOString())
    });
  }
  if (runway.length >= 2) {
    const delta = Number(runway[0].runway_value ?? 0) - Number(runway[1].runway_value ?? 0);
    trends.push({
      name: "Runway",
      direction: delta > 0 ? "up" : delta < 0 ? "down" : "flat",
      strength: Math.abs(delta),
      timestamp: String(runway[0].timestamp ?? new Date().toISOString())
    });
  }
  return trends;
}
