export type ConfidenceLevel = "high" | "medium" | "low";

export interface FinancialSignal {
  label: string;
  amount: number;
  confidence: ConfidenceLevel;
  category:
    | "income"
    | "expense"
    | "savings"
    | "debt"
    | "recurring_bill"
    | "one_time_cost";
  rawText: string;
}

export interface ExtractionResult {
  signals: FinancialSignal[];
  cleanedText: string;
  valid: boolean;
  issues: string[];
}

/**
 * Main entry point:
 * Takes raw document text and returns structured signals.
 */
export function extractFinancialSignals(rawText: string): ExtractionResult {
  const cleaned = cleanText(rawText);
  const patternSignals = patternExtraction(cleaned);
  const semanticSignals = semanticFallback(cleaned, patternSignals);

  const merged = mergeSignals(patternSignals, semanticSignals);
  const validated = validateSignals(merged);

  return {
    signals: merged,
    cleanedText: cleaned,
    valid: validated.valid,
    issues: validated.issues
  };
}

/**
 * Step 1: Cleaning layer
 */
function cleanText(input: string): string {
  let text = input || "";

  text = text.replace(/\r\n/g, "\n");
  text = text.replace(/\s+/g, " ").trim();
  text = text.replace(/C\$|CAD/g, "$");
  text = text.replace(/[^\w\s$%.,-]/g, "");

  return text;
}

/**
 * Step 2: Pattern-based extraction
 */
function patternExtraction(cleaned: string): FinancialSignal[] {
  const signals: FinancialSignal[] = [];

  const currencyRegex =
    /(\$?\s?\d{1,3}(?:,\d{3})*(?:\.\d{2})?|\$?\s?\d+(?:\.\d{2})?)/g;

  const incomeKeywords = /(income|salary|pay|wages|earned)/i;
  const expenseKeywords =
    /(expense|spent|bill|payment|due|subscription|rent|utilities)/i;
  const savingsKeywords = /(savings|saved|put aside|emergency fund)/i;
  const debtKeywords = /(loan|credit|debt|balance|owed)/i;
  const recurringKeywords = /(monthly|per month|every month|recurring)/i;

  const chunks = cleaned.split(/(?<=[.!?])\s+/);

  for (const chunk of chunks) {
    const amounts = chunk.match(currencyRegex);
    if (!amounts) continue;

    for (const rawAmount of amounts) {
      const amount = parseCurrency(rawAmount);
      if (Number.isNaN(amount)) continue;

      let category: FinancialSignal["category"] = "one_time_cost";
      let confidence: ConfidenceLevel = "medium";

      if (incomeKeywords.test(chunk)) {
        category = "income";
        confidence = recurringKeywords.test(chunk) ? "high" : "medium";
      } else if (expenseKeywords.test(chunk)) {
        category = recurringKeywords.test(chunk)
          ? "recurring_bill"
          : "expense";
        confidence = recurringKeywords.test(chunk) ? "high" : "medium";
      } else if (savingsKeywords.test(chunk)) {
        category = "savings";
        confidence = "medium";
      } else if (debtKeywords.test(chunk)) {
        category = "debt";
        confidence = "medium";
      } else if (recurringKeywords.test(chunk)) {
        category = "recurring_bill";
        confidence = "low";
      }

      signals.push({
        label: buildLabel(category),
        amount,
        confidence,
        category,
        rawText: chunk.trim()
      });
    }
  }

  return signals;
}

/**
 * Step 3: Semantic fallback extraction
 * Uses language cues when patterns are weak or missing.
 */
function semanticFallback(
  cleaned: string,
  existing: FinancialSignal[]
): FinancialSignal[] {
  const signals: FinancialSignal[] = [];

  const hasIncome = existing.some((signal) => signal.category === "income");
  const hasExpenses = existing.some(
    (signal) =>
      signal.category === "expense" || signal.category === "recurring_bill"
  );

  if (hasIncome && hasExpenses) return signals;

  const chunks = cleaned.split(/(?<=[.!?])\s+/);

  const incomeCue = /(you received|you earned|came in)/i;
  const expenseCue = /(you spent|went out|was paid|was charged)/i;
  const savingsCue = /(remaining|left over|leftover|after saving)/i;
  const debtCue = /(balance remaining|still owed|outstanding)/i;

  for (const chunk of chunks) {
    const amount = findFirstNumber(chunk);
    if (amount == null) continue;

    let category: FinancialSignal["category"] | null = null;

    if (incomeCue.test(chunk)) category = "income";
    else if (expenseCue.test(chunk)) category = "expense";
    else if (savingsCue.test(chunk)) category = "savings";
    else if (debtCue.test(chunk)) category = "debt";

    if (!category) continue;

    signals.push({
      label: buildLabel(category),
      amount,
      confidence: "low",
      category,
      rawText: chunk.trim()
    });
  }

  return signals;
}

/**
 * Step 4: Merge pattern + semantic signals
 */
function mergeSignals(
  patternSignals: FinancialSignal[],
  semanticSignals: FinancialSignal[]
): FinancialSignal[] {
  const merged = [...patternSignals];

  for (const signal of semanticSignals) {
    const duplicate = merged.find(
      (existing) =>
        existing.category === signal.category &&
        Math.abs(existing.amount - signal.amount) < 0.01 &&
        existing.rawText === signal.rawText
    );

    if (!duplicate) merged.push(signal);
  }

  return merged;
}

/**
 * Step 5: Validation layer
 */
function validateSignals(signals: FinancialSignal[]): {
  valid: boolean;
  issues: string[];
} {
  const issues: string[] = [];

  if (!signals.length) {
    issues.push("No financial signals extracted.");
  }

  const hasIncome = signals.some((signal) => signal.category === "income");
  const hasExpenses = signals.some(
    (signal) =>
      signal.category === "expense" || signal.category === "recurring_bill"
  );
  if (!hasIncome && !hasExpenses) {
    issues.push("No income or expense detected.");
  }

  return {
    valid: issues.length === 0,
    issues
  };
}

function parseCurrency(raw: string): number {
  const cleaned = raw
    .replace(/\$/g, "")
    .replace(/\s/g, "")
    .replace(/,/g, "");

  return parseFloat(cleaned);
}

function findFirstNumber(chunk: string): number | null {
  const match = chunk.match(/\d+(?:\.\d+)?/);
  if (!match) return null;

  return parseFloat(match[0]);
}

function buildLabel(category: FinancialSignal["category"]): string {
  if (category === "income") return "Income";
  if (category === "expense") return "Expense";
  if (category === "recurring_bill") return "Recurring bill";
  if (category === "savings") return "Savings";
  if (category === "debt") return "Debt";
  return "Cost";
}