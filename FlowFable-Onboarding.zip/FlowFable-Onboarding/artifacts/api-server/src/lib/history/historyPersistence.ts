import { promises as fs } from "fs";
import path from "path";
import type { FlowResult } from "@/lib/flowTypes";

const HISTORY_PATH = path.join(process.cwd(), "data", "history.json");

export async function loadHistoryFromDisk(): Promise<FlowResult[]> {
  try {
    const file = await fs.readFile(HISTORY_PATH, "utf8");
    const parsed: unknown = JSON.parse(file);

    return Array.isArray(parsed) ? (parsed as FlowResult[]) : [];
  } catch {
    return [];
  }
}

export async function saveHistoryToDisk(history: FlowResult[]) {
  await fs.mkdir(path.dirname(HISTORY_PATH), { recursive: true });
  await fs.writeFile(HISTORY_PATH, JSON.stringify(history, null, 2), "utf8");
}