import type { FlowResult } from "@/lib/flowTypes";
import {
  loadHistoryFromDisk,
  saveHistoryToDisk
} from "@/lib/history/historyPersistence";

export { loadHistoryFromDisk, saveHistoryToDisk };

let historyStore: FlowResult[] = [];

export async function initializeHistory() {
  historyStore = await loadHistoryFromDisk();
}

export function getHistory(): FlowResult[] {
  return historyStore;
}

export async function saveFlowToHistory(flow: FlowResult) {
  const snapshot: FlowResult = {
    ...flow,
    meta: {
      ...flow.meta,
      timestamp: new Date().toISOString()
    }
  };

  historyStore.unshift(snapshot);
  await saveHistoryToDisk(historyStore);
}

export function getHistoryItem(index: number): FlowResult | null {
  return historyStore[index] ?? null;
}