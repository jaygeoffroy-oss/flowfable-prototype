import type { ExtractionResult } from "@/lib/extraction";

export type FlowInsight = {
  severity: "info" | "warning" | "critical";
  what: string;
  why: string;
  options: string[];
  consequences: string[];
  returnToGoal: string;
  timestamp?: string;
};

export type FlowTrend = {
  name: string;
  direction: "up" | "down" | "flat";
  strength: number;
  timestamp: string;
};

export type FlowIncome = {
  amount: number;
  cadence: string;
};

export type FlowBill = {
  name: string;
  amount: number;
  cadence: string;
};

export type FlowBudget = {
  category: string;
  amount: number;
};

export type FlowTransaction = {
  name: string;
  amount: number;
  category: string;
  date: string;
};

export type FlowMeta = {
  filePath?: string;
  source?: "ingestion" | "fallback";
  timestamp?: string;
};

export interface FlowResult {
  goal?: string;
  targetAmount?: number;
  currentSavings?: number;
  userProfile?: {
    name?: string;
    province?: string;
    householdSize?: number;
    incomeCadence?: string;
    financialPriority?: string;
    riskComfort?: string;
    coachingStyle?:
      | "Supportive"
      | "Direct"
      | "Analytical"
      | "Motivational";
  };
  goals?: Array<{
    id: string;
    name: string;
    targetAmount: number;
    currentSavings: number;
    monthlyNet: number;
  }>;
  insights: FlowInsight[];
  guidance: FlowInsight[];
  education: FlowInsight[];
  trends: FlowTrend[];
  income: FlowIncome[];
  bills: FlowBill[];
  budget: FlowBudget[];
  transactions: FlowTransaction[];
  extraction?: ExtractionResult;
  meta?: FlowMeta;
}
