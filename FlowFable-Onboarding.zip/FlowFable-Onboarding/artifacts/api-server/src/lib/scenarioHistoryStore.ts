export type ScenarioHistoryEntry = {
  id: number;
  timestamp: string;
  goalId: string;
  goalName: string;
  change: number;
  pause: number;
  newMonthlyNet: number;
  monthsToGoal: number | null;
};

export const scenarioHistoryStore: ScenarioHistoryEntry[] = [];