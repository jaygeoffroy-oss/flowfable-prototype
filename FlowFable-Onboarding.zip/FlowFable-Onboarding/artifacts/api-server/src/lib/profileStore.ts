export type ProfileEntry = {
  name?: string;
  province?: string;
  householdSize?: number;
  incomeCadence?: string;
  financialPriority?: string;
  riskComfort?: string;
  coachingStyle?: "Supportive" | "Direct" | "Analytical" | "Motivational";
};

export const profileStore: ProfileEntry[] = [];