import app from "@/server";
import { initializeHistory } from "@/lib/history/historyRepository";

const port = process.env.PORT || 3001;

async function startServer() {
  await initializeHistory();

  app.listen(port, () => {
    console.log(`API server running on port ${port}`);
  });
}

void startServer().catch((err) => {
  console.error("Failed to initialize history", err);
  process.exitCode = 1;
});
