import { Router } from "express";
import { flowController } from "@/lib/flowController";

const router = Router();

/**
 * GET /flow
 * Returns the unified FlowResult for the given userId.
 */
router.get("/", flowController);

export default router;
