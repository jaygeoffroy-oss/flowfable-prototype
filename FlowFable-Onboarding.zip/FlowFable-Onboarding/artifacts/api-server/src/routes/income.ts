import { Router } from "express";
import { incomeStore } from "@/lib/prototypeStores";

const router = Router();

router.post("/", (req, res) => {
  const { amount, cadence } = req.body;

  if (!amount || !cadence) {
    return res.status(400).json({ error: "Missing fields" });
  }

  incomeStore.push({ amount, cadence });

  return res.json({ success: true, income: incomeStore });
});

router.get("/", (_req, res) => {
  return res.json({ income: incomeStore });
});

export default router;