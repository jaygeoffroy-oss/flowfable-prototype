import { Router } from "express";
import { transactionStore } from "@/lib/prototypeStores";

const router = Router();

router.post("/", (req, res) => {
  const { name, amount, category, date } = req.body;

  if (!name || !amount || !category || !date) {
    return res.status(400).json({ error: "Missing fields" });
  }

  transactionStore.push({ name, amount, category, date });

  return res.json({ success: true, transactions: transactionStore });
});

router.get("/", (_req, res) => {
  return res.json({ transactions: transactionStore });
});

export default router;