import { Router } from "express";
import {
  historyController,
  historyItemController
} from "@/lib/history/historyController";

const router = Router();

router.get("/:id", historyItemController);
router.get("/", historyController);

export default router;