import { Router } from "express";
import { uploadController } from "@/lib/upload/uploadController";

const router = Router();

router.post("/", uploadController);

export default router;