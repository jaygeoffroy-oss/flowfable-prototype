import { Router } from "express";
import { billsStore } from "@/lib/prototypeStores";

const router = Router();

router.post("/", (req, res) => {
  const { name, amount, cadence } = req.body;

  if (!name || !amount || !cadence) {
    return res.status(400).json({ error: "Missing fields" });
  }

  billsStore.push({ name, amount, cadence });

  return res.json({ success: true, bills: billsStore });
});

router.get("/", (_req, res) => {
  return res.json({ bills: billsStore });
});

export default router;