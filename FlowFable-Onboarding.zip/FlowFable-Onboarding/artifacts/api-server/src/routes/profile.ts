import { Router } from "express";
import { profileStore } from "@/lib/profileStore";

const router = Router();

router.get("/", (_req, res) => {
  res.json(profileStore[0] ?? {});
});

router.put("/", (req, res) => {
  const body =
    req.body && typeof req.body === "object" && !Array.isArray(req.body)
      ? req.body
      : {};

  profileStore[0] = {
    ...profileStore[0],
    ...body
  };

  res.json(profileStore[0]);
});

export default router;