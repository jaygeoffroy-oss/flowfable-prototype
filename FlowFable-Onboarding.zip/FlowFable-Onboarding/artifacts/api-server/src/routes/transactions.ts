import { Router } from "express";
import { db } from "@workspace/db";
import { transactionsTable } from "@workspace/db/schema";
import { SaveTransactionsBody } from "@workspace/api-zod";

const router = Router();

router.post("/", async (req, res) => {
  const parsed = SaveTransactionsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid request body", details: parsed.error.flatten() });
    return;
  }

  const { userId, statementId, transactions } = parsed.data;

  let saved = 0;
  let skipped = 0;

  for (const tx of transactions) {
    try {
      await db.insert(transactionsTable).values({
        userId,
        statementId: statementId,
        date: tx.date,
        description: tx.description,
        amount: String(tx.amount),
        merchant: tx.merchant ?? null,
        category: tx.category ?? null,
        isIncome: tx.isIncome ?? false,
        isExpense: tx.isExpense ?? false,
      });
      saved++;
    } catch {
      skipped++;
    }
  }

  res.json({ saved, skipped });
});

export default router;
