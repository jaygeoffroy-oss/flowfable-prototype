import { Router } from "express";
import { budgetStore } from "@/lib/prototypeStores";

const router = Router();

router.post("/", (req, res) => {
  const { category, amount } = req.body;

  if (!category || !amount) {
    return res.status(400).json({ error: "Missing fields" });
  }

  budgetStore.push({ category, amount });

  return res.json({ success: true, budget: budgetStore });
});

router.get("/", (_req, res) => {
  return res.json({ budget: budgetStore });
});

export default router;