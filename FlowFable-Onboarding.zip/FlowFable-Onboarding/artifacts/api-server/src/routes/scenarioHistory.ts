import { Router } from "express";
import { scenarioHistoryStore } from "@/lib/scenarioHistoryStore";

const router = Router();

router.get("/", (_req, res) => {
  const history = [...scenarioHistoryStore].sort(
    (a, b) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  res.json(history);
});

router.post("/", (req, res) => {
  const body =
    req.body && typeof req.body === "object" && !Array.isArray(req.body)
      ? req.body
      : {};
  const nextId =
    scenarioHistoryStore.reduce((maxId, entry) => Math.max(maxId, entry.id), 0) +
    1;
  const created = {
    id: nextId,
    timestamp: new Date().toISOString(),
    ...body
  };

  scenarioHistoryStore.push(created);
  res.json(created);
});

export default router;