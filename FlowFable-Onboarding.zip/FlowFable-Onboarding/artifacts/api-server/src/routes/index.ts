import { Router } from "express";
import flowRoute from "./flowRoute";
import incomeRoute from "./incomeRoute";
import billsRoute from "./billsRoute";
import budgetRoute from "./budgetRoute";
import transactionsRoute from "./transactionsRoute";
import uploadRoute from "./upload";
import profileRoute from "./profile";
import scenarioHistoryRoute from "./scenarioHistory";
import historyRoute from "./history";

const router = Router();

router.use("/flow", flowRoute);
router.use("/income", incomeRoute);
router.use("/bills", billsRoute);
router.use("/budget", budgetRoute);
router.use("/transactions", transactionsRoute);
router.use("/upload", uploadRoute);
router.use("/profile", profileRoute);
router.use("/history", historyRoute);
router.use("/scenario-history", scenarioHistoryRoute);

export default router;
