---
name: Hyper-delta naming
description: Naming and compatibility guidance for the hyper-delta coaching module family.
---

When extending the hyper-delta coaching pipeline, search for the function implementation by its text/name before assuming the long-form function name maps to a same-named file. Preserve existing behavior with overloads when a later stage reuses an existing builder name for a new summary shape.

**Why:** Several long-form hyper-delta names map to shorter existing module names, and repeated builder names can represent different pipeline stages.

**How to apply:** Locate the current implementation first, then add the new input/output mode compatibly instead of creating a duplicate or replacing the earlier mode.