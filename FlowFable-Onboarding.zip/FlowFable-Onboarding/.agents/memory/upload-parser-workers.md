---
name: Upload parser workers
description: Runtime packaging constraints for PDF and OCR extraction in the bundled API server
---

Bundled API builds must resolve document-parser workers explicitly: PDF.js needs its worker asset available beside the server bundle, while Tesseract’s Node worker should resolve from the installed package so its nested CommonJS dependencies remain available.

**Why:** The API server is bundled as ESM, but both parser libraries use worker files and CommonJS-relative dependency resolution. Relying on library defaults caused startup or request-time worker crashes.

**How to apply:** When changing PDF/OCR dependencies or the API build, verify both worker resolution paths in a built server, not only with TypeScript compilation.